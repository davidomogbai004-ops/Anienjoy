# AniEnjoy

[![Download APK](https://img.shields.io/badge/Download-APK-6B4EE6?style=for-the-badge&logo=android)](https://github.com/anienjoy/anienjoy/releases/latest)
[![Version](https://img.shields.io/badge/Version-1.0.0-9B59B6?style=for-the-badge)](https://github.com/anienjoy/anienjoy/releases)
[![License](https://img.shields.io/badge/License-Apache%202.0-green?style=for-the-badge)](LICENSE)

AniEnjoy is a comprehensive Android application for streaming anime, reading manga/manhwa/manhua, and reading novels. Inspired by Aniyomi, it features a powerful extension system that allows users to add content from various sources.

## 📥 Download

### [⬇️ Download Latest APK](https://github.com/anienjoy/anienjoy/releases/latest)

Or visit our website: **[anienjoy.app](https://anienjoy.app)**

### Requirements
- Android 8.0 (API 26) or higher
- ~25 MB free storage
- Internet connection for streaming

## Features

### Content Support
- **Anime**: Stream anime episodes from multiple sources
- **Manga**: Read manga from various sources
- **Manhwa**: Korean webtoons support
- **Manhua**: Chinese comics support
- **Novels**: Light novels and web novels support

### Extension System
- Install extensions from multiple repositories
- Support for custom extension repositories
- Automatic extension updates
- Language filtering for extensions

### Library Management
- Unified library for all content types
- Category-based organization
- Favorites system
- Reading/watching history tracking
- Progress synchronization

### Multi-Language Support
- Support for 17+ languages including:
  - English, Japanese, Korean, Chinese
  - French, German, Italian, Spanish
  - Portuguese, Russian, Arabic
  - Hindi, Indonesian, Vietnamese
  - Thai, Turkish, Polish
- Language filtering in library and browse

### Video Player
- Built-in video player using ExoPlayer
- Multiple quality options
- Subtitle support
- Audio track selection
- Playback speed control
- Double-tap to seek

### Reader
- Multiple reading modes (LTR, RTL, Vertical, Webtoon)
- Page-based navigation for manga
- Scroll-based reading for novels
- Font size adjustment for novels
- Theme switching (light/dark)

### Search
- Global search across all content types
- Per-source search
- Filter by content type and language

### Settings & Customization
- Theme selection (Light, Dark, System)
- Library grid column customization
- Player settings (seek duration, orientation)
- Reader settings (default reading mode)
- Download settings (Wi-Fi only option)
- NSFW content toggle

### Backup & Restore
- Create backups of library and settings
- Restore from backup files

## Architecture

### Tech Stack
- **Language**: Kotlin
- **UI Framework**: Jetpack Compose with Material Design 3
- **Architecture**: MVVM with Clean Architecture
- **Dependency Injection**: Hilt
- **Database**: Room
- **Networking**: OkHttp, Retrofit, Ktor
- **Image Loading**: Coil
- **Video Player**: ExoPlayer (Media3)
- **Preferences**: DataStore

### Project Structure
```
AniEnjoy/
├── app/
│   ├── src/main/java/com/anienjoy/
│   │   ├── data/
│   │   │   ├── database/       # Room entities and DAOs
│   │   │   ├── preferences/    # DataStore settings
│   │   │   └── repository/     # Repository implementations
│   │   ├── domain/
│   │   │   ├── model/          # Domain models
│   │   │   └── repository/     # Repository interfaces
│   │   ├── di/                 # Dependency injection modules
│   │   ├── extension/          # Extension system
│   │   ├── player/             # Video player
│   │   ├── reader/             # Manga/Novel readers
│   │   ├── download/           # Download manager
│   │   ├── tracking/           # Tracker integrations
│   │   └── utils/              # Utility classes
│   │   └── presentation/
│   │       ├── screens/        # UI screens
│   │       ├── components/     # Reusable components
│   │       ├── theme/          # App theme
│   │       └── viewmodel/      # ViewModels
│   └── src/main/res/           # Resources
├── extension-api/              # Extension API module
│   └── src/main/java/com/anienjoy/extension/api/
│       ├── model/              # Extension models
│       ├── network/            # Network utilities
│       └── loader/             # Extension loader
└── build.gradle.kts            # Build configuration
```

## Extension API

AniEnjoy provides a powerful extension API for developers to create custom sources:

### Creating an Extension

```kotlin
class MyAnimeSource : AnimeSource {
    override val id: Long = 12345L
    override val name: String = "My Anime Source"
    override val baseUrl: String = "https://example.com"
    override val lang: String = "en"
    override val supportsNsfw: Boolean = false

    override suspend fun getPopularAnime(page: Int): AnimePage {
        // Implementation
    }

    override suspend fun searchAnime(
        query: String, 
        page: Int, 
        filters: FilterList
    ): AnimePage {
        // Implementation
    }

    override suspend fun getVideoList(episode: Episode): List<Video> {
        // Implementation
    }
}
```

### Extension Repository Format

Extensions are distributed via JSON index files:

```json
{
  "extensions": [
    {
      "name": "Extension Name",
      "pkg": "com.anienjoy.extension.source",
      "version": "1.0.0",
      "code": 1,
      "libVersion": "1.0",
      "lang": "en",
      "nsfw": false,
      "sources": [
        {
          "id": 12345,
          "name": "Source Name",
          "lang": "en",
          "baseUrl": "https://example.com",
          "type": "anime"
        }
      ]
    }
  ]
}
```

## Building

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17 or newer
- Android SDK 34

### Build Instructions

1. Clone the repository:
```bash
git clone https://github.com/anienjoy/anienjoy.git
cd anienjoy
```

2. Open in Android Studio and sync project

3. Build the APK:
```bash
./gradlew assembleDebug
```

Or for release:
```bash
./gradlew assembleRelease
```

## Installation

1. Enable "Install from unknown sources" in Android settings
2. Download the APK from releases
3. Install the APK
4. Add extension repositories in Settings > Extensions
5. Install desired extensions
6. Start browsing and adding content to your library!

## Default Extension Repositories

AniEnjoy comes with support for popular extension repositories:
- Aniyomi Extensions
- Keiyoushi Extensions

You can add custom repositories in Settings > Extensions > Add Repository

## Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) for details.

## License

AniEnjoy is licensed under the Apache License 2.0. See [LICENSE](LICENSE) for details.

## Acknowledgments

- Inspired by [Aniyomi](https://github.com/aniyomiorg/aniyomi)
- Built with [Jetpack Compose](https://developer.android.com/jetpack/compose)
- Video playback powered by [ExoPlayer](https://github.com/google/ExoPlayer)

## Disclaimer

AniEnjoy is a content aggregator that relies on third-party extensions. The developers do not host any content and are not responsible for the content available through extensions.
