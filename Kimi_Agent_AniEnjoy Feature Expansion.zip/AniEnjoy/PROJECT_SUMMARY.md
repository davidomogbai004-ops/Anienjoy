# AniEnjoy Project Summary

## Overview
AniEnjoy is a comprehensive Android application for streaming anime, reading manga/manhwa/manhua, and reading novels. It features a powerful extension system similar to Aniyomi that allows users to add content from various sources.

## Project Structure

### Modules
1. **app** - Main application module
2. **extension-api** - Extension API module for third-party extensions

### Key Features Implemented

#### 1. Extension System
- **Source.kt** - Base interfaces for AnimeSource, MangaSource, NovelSource
- **ExtensionLoader.kt** - Loads extensions from APK files
- **NetworkHelper.kt** - HTTP client for network requests
- **Filter.kt** - Comprehensive filtering system (Text, Select, Checkbox, TriState, etc.)
- **LanguageFilter.kt** - Multi-language support with 17+ languages

#### 2. Database (Room)
- **Entities**: Anime, Manga, Novel, Episode, Chapter, NovelChapter, Category, Extension
- **DAOs**: Full CRUD operations for all entities
- **Relations**: Foreign keys and relationships between entities

#### 3. Repository Layer
- **AnimeRepository** - Anime library management
- **MangaRepository** - Manga/manhwa/manhua management
- **NovelRepository** - Novel library management
- **ExtensionRepository** - Extension installation and updates
- **SourceRepository** - Source operations (search, fetch details, etc.)
- **LibraryRepository** - Combined library operations
- **CategoryRepository** - Category management

#### 4. UI Layer (Jetpack Compose)
- **MainScreen** - Bottom navigation with Library, Updates, History, Browse, More
- **LibraryScreen** - Grid view with content type tabs and language filtering
- **BrowseScreen** - Source and extension browsing
- **ExtensionsScreen** - Extension repository management
- **SettingsScreen** - Comprehensive settings
- **GlobalSearchScreen** - Cross-content-type search
- **AnimeDetailsScreen** - Anime info and episode list
- **MangaDetailsScreen** - Manga info and chapter list
- **NovelDetailsScreen** - Novel info and chapter list
- **PlayerScreen** - Video player with ExoPlayer
- **ReaderScreen** - Manga reader with pager
- **NovelReaderScreen** - Novel reader with text formatting

#### 5. Settings & Preferences
- Theme selection (Light, Dark, System)
- Language filtering (17+ languages)
- Library grid customization
- Player settings (seek duration, orientation)
- Reader settings (reading mode)
- Download settings
- NSFW content toggle
- Backup & Restore

#### 6. Multi-Language Support
Supported languages:
- English (en)
- Japanese (ja)
- Korean (ko)
- Chinese (zh)
- French (fr)
- German (de)
- Italian (it)
- Spanish (es)
- Portuguese (pt)
- Russian (ru)
- Arabic (ar)
- Hindi (hi)
- Indonesian (id)
- Vietnamese (vi)
- Thai (th)
- Turkish (tr)
- Polish (pl)

## Tech Stack
- **Language**: Kotlin
- **UI**: Jetpack Compose with Material Design 3
- **Architecture**: MVVM with Clean Architecture
- **DI**: Hilt
- **Database**: Room
- **Networking**: OkHttp, Retrofit, Ktor
- **Image Loading**: Coil
- **Video**: ExoPlayer (Media3)
- **Preferences**: DataStore

## File Count Summary
- Kotlin Source Files: 80+
- XML Resource Files: 10+
- Gradle Build Files: 5
- Configuration Files: 5

## Key Components

### Extension API
```
extension-api/src/main/java/com/anienjoy/extension/api/
├── Source.kt              # Base source interfaces
├── model/
│   ├── Anime.kt           # Anime, Episode, Video models
│   ├── Manga.kt           # Manga, Chapter, Page models
│   ├── Novel.kt           # Novel, NovelChapter models
│   └── Filter.kt          # Filter system
├── network/
│   └── NetworkHelper.kt   # HTTP utilities
└── loader/
    └── ExtensionLoader.kt # Extension loading
```

### Data Layer
```
app/src/main/java/com/anienjoy/data/
├── database/
│   ├── entity/            # Room entities
│   ├── dao/               # Data Access Objects
│   └── AppDatabase.kt     # Database class
├── preferences/
│   └── SettingsPreferences.kt
└── repository/            # Repository implementations
```

### Presentation Layer
```
app/src/main/java/com/anienjoy/presentation/
├── screens/
│   ├── library/           # Library screen
│   ├── details/           # Details screens
│   ├── player/            # Video player
│   ├── reader/            # Manga/Novel readers
│   └── search/            # Search screen
├── theme/                 # App theme
└── MainActivity.kt
```

## Building the Project

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17 or newer
- Android SDK 34

### Build Commands
```bash
# Debug build
./gradlew assembleDebug

# Release build
./gradlew assembleRelease

# Run tests
./gradlew test

# Clean build
./gradlew clean
```

## Extension Repository Format
Extensions are distributed via JSON index files:
```json
{
  "extensions": [
    {
      "name": "Extension Name",
      "pkg": "com.anienjoy.extension.source",
      "version": "1.0.0",
      "code": 1,
      "libVersion": "1.0",
      "lang": "en",
      "nsfw": false,
      "sources": [
        {
          "id": 12345,
          "name": "Source Name",
          "lang": "en",
          "baseUrl": "https://example.com",
          "type": "anime"
        }
      ]
    }
  ]
}
```

## Default Extension Repositories
- Aniyomi Extensions
- Keiyoushi Extensions

## Future Enhancements
1. Tracker integration (MyAnimeList, AniList, Kitsu)
2. Download manager for offline content
3. Backup and restore functionality
4. Update checker for library items
5. More reading modes for manga
6. Subtitle customization in player
7. Cast support
8. Widget support

## License
Apache License 2.0
