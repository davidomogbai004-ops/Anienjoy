#!/bin/bash

# AniEnjoy Download Script
# This script downloads the latest AniEnjoy APK

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}   AniEnjoy Downloader v1.0    ${NC}"
echo -e "${BLUE}================================${NC}"
echo ""

# Check if curl or wget is available
if command -v curl &> /dev/null; then
    DOWNLOADER="curl -L -o"
elif command -v wget &> /dev/null; then
    DOWNLOADER="wget -O"
else
    echo -e "${RED}Error: curl or wget is required${NC}"
    exit 1
fi

# Get the latest release URL
API_URL="https://api.github.com/repos/anienjoy/anienjoy/releases/latest"

echo -e "${YELLOW}Fetching latest release information...${NC}"

# Get download URL
if command -v curl &> /dev/null; then
    DOWNLOAD_URL=$(curl -s "$API_URL" | grep -o '"browser_download_url": "[^"]*release[^"]*\.apk"' | cut -d'"' -f4 | head -1)
    VERSION=$(curl -s "$API_URL" | grep -o '"tag_name": "[^"]*"' | cut -d'"' -f4)
else
    DOWNLOAD_URL=$(wget -qO- "$API_URL" | grep -o '"browser_download_url": "[^"]*release[^"]*\.apk"' | cut -d'"' -f4 | head -1)
    VERSION=$(wget -qO- "$API_URL" | grep -o '"tag_name": "[^"]*"' | cut -d'"' -f4)
fi

if [ -z "$DOWNLOAD_URL" ]; then
    echo -e "${RED}Error: Could not find download URL${NC}"
    echo -e "${YELLOW}Trying alternative download method...${NC}"
    DOWNLOAD_URL="https://github.com/anienjoy/anienjoy/releases/latest/download/app-release.apk"
fi

echo -e "${GREEN}Latest version: $VERSION${NC}"
echo ""

# Set output filename
OUTPUT_FILE="anienjoy-${VERSION}.apk"

# Download
echo -e "${YELLOW}Downloading AniEnjoy...${NC}"
echo -e "${BLUE}URL: $DOWNLOAD_URL${NC}"
echo ""

if $DOWNLOADER "$OUTPUT_FILE" "$DOWNLOAD_URL"; then
    echo ""
    echo -e "${GREEN}✓ Download complete!${NC}"
    echo -e "${GREEN}File saved as: $OUTPUT_FILE${NC}"
    echo ""
    
    # Check if adb is available and device is connected
    if command -v adb &> /dev/null; then
        if adb devices | grep -q "device$"; then
            echo -e "${YELLOW}Android device detected!${NC}"
            read -p "Would you like to install the APK now? (y/n) " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                echo -e "${YELLOW}Installing...${NC}"
                if adb install "$OUTPUT_FILE"; then
                    echo -e "${GREEN}✓ Installation complete!${NC}"
                    echo -e "${GREEN}AniEnjoy has been installed on your device.${NC}"
                else
                    echo -e "${RED}✗ Installation failed${NC}"
                    echo -e "${YELLOW}Please install manually: $OUTPUT_FILE${NC}"
                fi
            fi
        fi
    fi
    
    echo ""
    echo -e "${BLUE}================================${NC}"
    echo -e "${GREEN}  Thank you for using AniEnjoy! ${NC}"
    echo -e "${BLUE}================================${NC}"
    
else
    echo ""
    echo -e "${RED}✗ Download failed${NC}"
    echo -e "${YELLOW}Please try downloading manually from:${NC}"
    echo -e "${BLUE}https://github.com/anienjoy/anienjoy/releases/latest${NC}"
    exit 1
fi
