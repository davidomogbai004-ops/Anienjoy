package com.anienjoy.di

import android.app.Application
import androidx.room.Room
import com.anienjoy.data.database.AppDatabase
import com.anienjoy.data.preferences.SettingsPreferences
import com.anienjoy.data.repository.*
import com.anienjoy.domain.repository.*
import com.anienjoy.extension.api.network.NetworkHelper
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(app: Application): AppDatabase {
        return Room.databaseBuilder(
            app,
            AppDatabase::class.java,
            "anienjoy.db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideNetworkHelper(): NetworkHelper {
        return NetworkHelper()
    }

    @Provides
    @Singleton
    fun provideSettingsPreferences(app: Application): SettingsPreferences {
        return SettingsPreferences(app)
    }

    @Provides
    @Singleton
    fun provideAnimeRepository(
        db: AppDatabase,
        networkHelper: NetworkHelper
    ): AnimeRepository {
        return AnimeRepositoryImpl(db.animeDao(), db.episodeDao(), networkHelper)
    }

    @Provides
    @Singleton
    fun provideMangaRepository(
        db: AppDatabase,
        networkHelper: NetworkHelper
    ): MangaRepository {
        return MangaRepositoryImpl(db.mangaDao(), db.chapterDao(), networkHelper)
    }

    @Provides
    @Singleton
    fun provideNovelRepository(
        db: AppDatabase,
        networkHelper: NetworkHelper
    ): NovelRepository {
        return NovelRepositoryImpl(db.novelDao(), db.novelChapterDao(), networkHelper)
    }

    @Provides
    @Singleton
    fun provideCategoryRepository(db: AppDatabase): CategoryRepository {
        return CategoryRepositoryImpl(db.categoryDao())
    }

    @Provides
    @Singleton
    fun provideExtensionRepository(
        app: Application,
        db: AppDatabase
    ): ExtensionRepository {
        return ExtensionRepositoryImpl(app, db.extensionDao())
    }

    @Provides
    @Singleton
    fun provideSourceRepository(
        app: Application,
        extensionRepository: ExtensionRepository
    ): SourceRepository {
        return SourceRepositoryImpl(app, extensionRepository)
    }

    @Provides
    @Singleton
    fun provideLibraryRepository(
        db: AppDatabase
    ): LibraryRepository {
        return LibraryRepositoryImpl(
            db.animeDao(),
            db.mangaDao(),
            db.novelDao(),
            db.categoryDao()
        )
    }

    @Provides
    @Singleton
    fun provideUpdateRepository(db: AppDatabase): UpdateRepository {
        return UpdateRepositoryImpl(db.updateDao())
    }

    @Provides
    @Singleton
    fun provideDownloadRepository(db: AppDatabase): DownloadRepository {
        return DownloadRepositoryImpl(db.downloadDao())
    }

    @Provides
    @Singleton
    fun provideBackupManager(
        app: Application,
        db: AppDatabase,
        settingsPreferences: SettingsPreferences
    ): com.anienjoy.data.backup.BackupManager {
        return com.anienjoy.data.backup.BackupManager(app, db, settingsPreferences)
    }
}
