package com.anienjoy.presentation.screens.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import com.anienjoy.data.database.entity.NovelEntity
import com.anienjoy.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    navController: NavController,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("All", "Anime", "Manga", "Manhwa", "Manhua", "Novels")

    Column(modifier = Modifier.fillMaxSize()) {
        // Content type tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 16.dp
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title) }
                )
            }
        }

        // Filter chips for languages
        LanguageFilterChips(
            selectedLanguages = uiState.selectedLanguages,
            onLanguageToggle = viewModel::toggleLanguage
        )

        // Library content
        when (val state = uiState) {
            is LibraryUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            is LibraryUiState.Success -> {
                val items = when (selectedTab) {
                    0 -> state.items // All
                    1 -> state.anime // Anime
                    2 -> state.manga // Manga
                    3 -> state.manhwa // Manhwa
                    4 -> state.manhua // Manhua
                    5 -> state.novels // Novels
                    else -> state.items
                }

                if (items.isEmpty()) {
                    EmptyLibraryMessage(selectedTab)
                } else {
                    LibraryGrid(
                        items = items,
                        onItemClick = { item ->
                            when (item) {
                                is AnimeEntity -> navController.navigate("anime_details/${item.id}")
                                is MangaEntity -> navController.navigate("manga_details/${item.id}")
                                is NovelEntity -> navController.navigate("novel_details/${item.id}")
                            }
                        }
                    )
                }
            }
            is LibraryUiState.Error -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Error: ${state.message}")
                }
            }
        }
    }
}

@Composable
fun LanguageFilterChips(
    selectedLanguages: Set<String>,
    onLanguageToggle: (String) -> Unit
) {
    val languages = listOf(
        "en" to "English",
        "ja" to "Japanese",
        "ko" to "Korean",
        "zh" to "Chinese",
        "fr" to "French",
        "es" to "Spanish",
        "pt" to "Portuguese",
        "de" to "German",
        "it" to "Italian",
        "ru" to "Russian",
        "ar" to "Arabic",
        "hi" to "Hindi",
        "id" to "Indonesian",
        "vi" to "Vietnamese",
        "th" to "Thai",
        "tr" to "Turkish",
        "pl" to "Polish"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Show only selected languages or first few
        languages.filter { it.first in selectedLanguages || selectedLanguages.isEmpty() }
            .take(5)
            .forEach { (code, name) ->
                FilterChip(
                    selected = code in selectedLanguages,
                    onClick = { onLanguageToggle(code) },
                    label = { Text(name) }
                )
            }
        
        // More languages button
        if (languages.size > 5) {
            FilterChip(
                selected = false,
                onClick = { /* Show more languages dialog */ },
                label = { Text("+") }
            )
        }
    }
}

@Composable
fun LibraryGrid(
    items: List<Any>,
    onItemClick: (Any) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 120.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items) { item ->
            when (item) {
                is AnimeEntity -> AnimeLibraryItem(
                    anime = item,
                    onClick = { onItemClick(item) }
                )
                is MangaEntity -> MangaLibraryItem(
                    manga = item,
                    onClick = { onItemClick(item) }
                )
                is NovelEntity -> NovelLibraryItem(
                    novel = item,
                    onClick = { onItemClick(item) }
                )
            }
        }
    }
}

@Composable
fun AnimeLibraryItem(
    anime: AnimeEntity,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Box {
            AsyncImage(
                model = anime.thumbnailUrl,
                contentDescription = anime.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f / 3f),
                contentScale = ContentScale.Crop
            )
            // Type badge
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(4.dp),
                color = AnimeColor,
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = "ANIME",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
        Text(
            text = anime.title,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun MangaLibraryItem(
    manga: MangaEntity,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Box {
            AsyncImage(
                model = manga.thumbnailUrl,
                contentDescription = manga.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f / 3f),
                contentScale = ContentScale.Crop
            )
            // Type badge
            val badgeColor = when (manga.contentType) {
                "MANHWA" -> ManhwaColor
                "MANHUA" -> ManhuaColor
                else -> MangaColor
            }
            val typeText = when (manga.contentType) {
                "MANHWA" -> "MANHWA"
                "MANHUA" -> "MANHUA"
                else -> "MANGA"
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(4.dp),
                color = badgeColor,
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = typeText,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
        Text(
            text = manga.title,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun NovelLibraryItem(
    novel: NovelEntity,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Box {
            AsyncImage(
                model = novel.thumbnailUrl,
                contentDescription = novel.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f / 3f),
                contentScale = ContentScale.Crop
            )
            // Type badge
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(4.dp),
                color = NovelColor,
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = "NOVEL",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
        Text(
            text = novel.title,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun EmptyLibraryMessage(selectedTab: Int) {
    val message = when (selectedTab) {
        0 -> "Your library is empty.\nAdd items from Browse!"
        1 -> "No anime in your library.\nAdd anime from Browse!"
        2 -> "No manga in your library.\nAdd manga from Browse!"
        3 -> "No manhwa in your library.\nAdd manhwa from Browse!"
        4 -> "No manhua in your library.\nAdd manhua from Browse!"
        5 -> "No novels in your library.\nAdd novels from Browse!"
        else -> "Your library is empty."
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.CollectionsBookmark,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}
