package com.anienjoy.presentation.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.ExtensionEntity
import com.anienjoy.data.database.entity.ExtensionRepoEntity
import com.anienjoy.domain.repository.ExtensionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExtensionsViewModel @Inject constructor(
    private val extensionRepository: ExtensionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExtensionsUiState())
    val uiState: StateFlow<ExtensionsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            extensionRepository.getExtensionRepos()
                .collect { repos ->
                    _uiState.update { it.copy(repos = repos) }
                }
        }

        viewModelScope.launch {
            extensionRepository.getInstalledExtensions()
                .collect { extensions ->
                    _uiState.update { it.copy(installedExtensions = extensions) }
                }
        }
    }

    fun addRepo(name: String, url: String) {
        viewModelScope.launch {
            val repo = ExtensionRepoEntity(
                name = name,
                url = url,
                enabled = true
            )
            extensionRepository.addRepo(repo)
        }
    }

    fun deleteRepo(repo: ExtensionRepoEntity) {
        viewModelScope.launch {
            extensionRepository.removeRepo(repo)
        }
    }

    fun toggleRepoEnabled(repoId: Long, enabled: Boolean) {
        viewModelScope.launch {
            extensionRepository.setRepoEnabled(repoId, enabled)
        }
    }

    fun uninstallExtension(pkgName: String) {
        viewModelScope.launch {
            extensionRepository.uninstallExtension(pkgName)
        }
    }

    fun refreshExtensions() {
        viewModelScope.launch {
            extensionRepository.checkForUpdates()
        }
    }
}

data class ExtensionsUiState(
    val repos: List<ExtensionRepoEntity> = emptyList(),
    val installedExtensions: List<ExtensionEntity> = emptyList(),
    val isLoading: Boolean = false
)
