package com.anienjoy.presentation.screens.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.anienjoy.extension.api.model.Anime
import com.anienjoy.extension.api.model.Manga
import com.anienjoy.extension.api.model.Novel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(
    navController: NavController,
    viewModel: GlobalSearchViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { 
                            searchQuery = it
                            viewModel.search(it)
                        },
                        placeholder = { Text("Search anime, manga, novels...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { 
                                    searchQuery = ""
                                    viewModel.clearSearch()
                                }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = uiState) {
                is SearchUiState.Initial -> {
                    EmptySearchState()
                }
                is SearchUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is SearchUiState.Success -> {
                    SearchResults(
                        results = state.results,
                        onAnimeClick = { anime ->
                            navController.navigate("anime_details/${anime.id}")
                        },
                        onMangaClick = { manga ->
                            navController.navigate("manga_details/${manga.id}")
                        },
                        onNovelClick = { novel ->
                            navController.navigate("novel_details/${novel.id}")
                        }
                    )
                }
                is SearchUiState.Error -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Error: ${state.message}")
                    }
                }
            }
        }
    }
}

@Composable
fun EmptySearchState() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Search for anime, manga, manhwa, manhua, or novels",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun SearchResults(
    results: SearchResults,
    onAnimeClick: (Anime) -> Unit,
    onMangaClick: (Manga) -> Unit,
    onNovelClick: (Novel) -> Unit
) {
    LazyColumn {
        // Anime results
        if (results.anime.isNotEmpty()) {
            item {
                SearchSectionTitle("Anime (${results.anime.size})")
            }
            items(results.anime.take(5)) { anime ->
                AnimeSearchResultItem(
                    anime = anime,
                    onClick = { onAnimeClick(anime) }
                )
            }
        }

        // Manga results
        if (results.manga.isNotEmpty()) {
            item {
                SearchSectionTitle("Manga (${results.manga.size})")
            }
            items(results.manga.take(5)) { manga ->
                MangaSearchResultItem(
                    manga = manga,
                    onClick = { onMangaClick(manga) }
                )
            }
        }

        // Manhwa results
        if (results.manhwa.isNotEmpty()) {
            item {
                SearchSectionTitle("Manhwa (${results.manhwa.size})")
            }
            items(results.manhwa.take(5)) { manhwa ->
                MangaSearchResultItem(
                    manga = manhwa,
                    onClick = { onMangaClick(manhwa) }
                )
            }
        }

        // Manhua results
        if (results.manhua.isNotEmpty()) {
            item {
                SearchSectionTitle("Manhua (${results.manhua.size})")
            }
            items(results.manhua.take(5)) { manhua ->
                MangaSearchResultItem(
                    manga = manhua,
                    onClick = { onMangaClick(manhua) }
                )
            }
        }

        // Novel results
        if (results.novels.isNotEmpty()) {
            item {
                SearchSectionTitle("Novels (${results.novels.size})")
            }
            items(results.novels.take(5)) { novel ->
                NovelSearchResultItem(
                    novel = novel,
                    onClick = { onNovelClick(novel) }
                )
            }
        }

        if (results.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No results found",
                        modifier = Modifier.padding(32.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}

@Composable
fun SearchSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun AnimeSearchResultItem(
    anime: Anime,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(anime.title) },
        supportingContent = {
            Column {
                anime.description?.let { 
                    Text(
                        text = it,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    text = "Source: ${anime.source}",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        },
        leadingContent = {
            AsyncImage(
                model = anime.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier
                    .size(56.dp)
                    .aspectRatio(2f / 3f)
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
fun MangaSearchResultItem(
    manga: Manga,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(manga.title) },
        supportingContent = {
            Column {
                manga.description?.let { 
                    Text(
                        text = it,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    text = "Source: ${manga.source}",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        },
        leadingContent = {
            AsyncImage(
                model = manga.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier
                    .size(56.dp)
                    .aspectRatio(2f / 3f)
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
fun NovelSearchResultItem(
    novel: Novel,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(novel.title) },
        supportingContent = {
            Column {
                novel.description?.let { 
                    Text(
                        text = it,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    text = "Source: ${novel.source}",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        },
        leadingContent = {
            AsyncImage(
                model = novel.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier
                    .size(56.dp)
                    .aspectRatio(2f / 3f)
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
