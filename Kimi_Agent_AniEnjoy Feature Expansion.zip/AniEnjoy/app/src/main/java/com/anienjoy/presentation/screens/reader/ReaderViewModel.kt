package com.anienjoy.presentation.screens.reader

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.ChapterEntity
import com.anienjoy.domain.repository.MangaRepository
import com.anienjoy.domain.repository.SourceRepository
import com.anienjoy.extension.api.model.Page
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val mangaRepository: MangaRepository,
    private val sourceRepository: SourceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ReaderUiState>(ReaderUiState.Loading)
    val uiState: StateFlow<ReaderUiState> = _uiState.asStateFlow()

    private var currentChapterId: Long? = null

    fun loadChapter(chapterId: Long) {
        currentChapterId = chapterId
        viewModelScope.launch {
            _uiState.value = ReaderUiState.Loading

            try {
                val chapter = mangaRepository.getChapterById(chapterId)
                if (chapter != null) {
                    // Get pages from source
                    val source = sourceRepository.getMangaSourceById(chapter.mangaId)
                    val pages = source?.getPageList(
                        com.anienjoy.extension.api.model.Chapter(
                            id = chapter.id,
                            mangaId = chapter.mangaId,
                            url = chapter.url,
                            name = chapter.name
                        )
                    ) ?: emptyList()

                    _uiState.value = ReaderUiState.Success(
                        chapter = chapter,
                        pages = pages,
                        currentPage = chapter.lastPageRead
                    )
                } else {
                    _uiState.value = ReaderUiState.Error("Chapter not found")
                }
            } catch (e: Exception) {
                _uiState.value = ReaderUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun onPageChanged(page: Int) {
        viewModelScope.launch {
            currentChapterId?.let { chapterId ->
                mangaRepository.updateLastPageRead(chapterId, page)
                
                // Mark as read if on last page
                val state = _uiState.value as? ReaderUiState.Success
                state?.let {
                    if (page >= it.pages.size - 1) {
                        mangaRepository.updateChapterRead(chapterId, true)
                    }
                }
            }
        }
    }

    fun goToPage(page: Int) {
        val state = _uiState.value as? ReaderUiState.Success ?: return
        if (page in 0 until state.pages.size) {
            _uiState.value = state.copy(currentPage = page)
        }
    }

    fun toggleReadingMode() {
        // Toggle between different reading modes (LTR, RTL, Vertical, Webtoon)
    }
}

sealed class ReaderUiState {
    object Loading : ReaderUiState()
    data class Success(
        val chapter: ChapterEntity,
        val pages: List<Page>,
        val currentPage: Int
    ) : ReaderUiState()
    data class Error(val message: String) : ReaderUiState()
}
