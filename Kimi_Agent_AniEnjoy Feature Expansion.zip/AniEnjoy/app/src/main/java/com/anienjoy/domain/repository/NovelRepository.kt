package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.NovelChapterEntity
import com.anienjoy.data.database.entity.NovelEntity
import kotlinx.coroutines.flow.Flow

interface NovelRepository {
    fun getFavoriteNovels(): Flow<List<NovelEntity>>
    fun getFavoriteNovelsPaging(): androidx.paging.PagingSource<Int, NovelEntity>
    suspend fun getNovelById(id: Long): NovelEntity?
    suspend fun getNovelBySourceAndUrl(source: String, url: String): NovelEntity?
    suspend fun insertNovel(novel: NovelEntity): Long
    suspend fun updateNovel(novel: NovelEntity)
    suspend fun deleteNovel(novel: NovelEntity)
    suspend fun updateFavorite(novelId: Long, favorite: Boolean)
    suspend fun updateThumbnail(novelId: Long, thumbnailUrl: String?)
    suspend fun isNovelFavorite(source: String, url: String): Boolean
    fun searchFavoriteNovels(query: String): Flow<List<NovelEntity>>
    fun getFavoriteNovelsCount(): Flow<Int>

    // Chapter operations
    fun getChaptersByNovelId(novelId: Long): Flow<List<NovelChapterEntity>>
    suspend fun getChaptersByNovelIdSync(novelId: Long): List<NovelChapterEntity>
    suspend fun getChapterById(id: Long): NovelChapterEntity?
    suspend fun insertChapter(chapter: NovelChapterEntity): Long
    suspend fun insertChapters(chapters: List<NovelChapterEntity>)
    suspend fun updateChapter(chapter: NovelChapterEntity)
    suspend fun deleteChapter(chapter: NovelChapterEntity)
    suspend fun updateChapterRead(chapterId: Long, read: Boolean)
    suspend fun updateChapterBookmark(chapterId: Long, bookmark: Boolean)
    suspend fun updateLastReadPosition(chapterId: Long, position: Int)
    fun getReadChapterCount(novelId: Long): Flow<Int>
    fun getTotalChapterCount(novelId: Long): Flow<Int>
    suspend fun getNextUnreadChapter(novelId: Long): NovelChapterEntity?
    suspend fun deleteAllChaptersByNovelId(novelId: Long)
}
