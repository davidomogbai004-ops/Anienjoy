package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.ChapterEntity
import com.anienjoy.data.database.entity.MangaEntity
import kotlinx.coroutines.flow.Flow

interface MangaRepository {
    fun getFavoriteManga(): Flow<List<MangaEntity>>
    fun getFavoriteMangaPaging(): androidx.paging.PagingSource<Int, MangaEntity>
    fun getFavoriteByContentType(contentType: String): Flow<List<MangaEntity>>
    suspend fun getMangaById(id: Long): MangaEntity?
    suspend fun getMangaBySourceAndUrl(source: String, url: String): MangaEntity?
    suspend fun insertManga(manga: MangaEntity): Long
    suspend fun updateManga(manga: MangaEntity)
    suspend fun deleteManga(manga: MangaEntity)
    suspend fun updateFavorite(mangaId: Long, favorite: Boolean)
    suspend fun updateThumbnail(mangaId: Long, thumbnailUrl: String?)
    suspend fun isMangaFavorite(source: String, url: String): Boolean
    fun searchFavoriteManga(query: String): Flow<List<MangaEntity>>
    fun getFavoriteMangaCount(): Flow<Int>
    fun getFavoriteCountByType(contentType: String): Flow<Int>

    // Chapter operations
    fun getChaptersByMangaId(mangaId: Long): Flow<List<ChapterEntity>>
    suspend fun getChaptersByMangaIdSync(mangaId: Long): List<ChapterEntity>
    suspend fun getChapterById(id: Long): ChapterEntity?
    suspend fun insertChapter(chapter: ChapterEntity): Long
    suspend fun insertChapters(chapters: List<ChapterEntity>)
    suspend fun updateChapter(chapter: ChapterEntity)
    suspend fun deleteChapter(chapter: ChapterEntity)
    suspend fun updateChapterRead(chapterId: Long, read: Boolean)
    suspend fun updateChapterBookmark(chapterId: Long, bookmark: Boolean)
    suspend fun updateLastPageRead(chapterId: Long, lastPageRead: Int)
    fun getReadChapterCount(mangaId: Long): Flow<Int>
    fun getTotalChapterCount(mangaId: Long): Flow<Int>
    suspend fun getNextUnreadChapter(mangaId: Long): ChapterEntity?
    suspend fun deleteAllChaptersByMangaId(mangaId: Long)
}
