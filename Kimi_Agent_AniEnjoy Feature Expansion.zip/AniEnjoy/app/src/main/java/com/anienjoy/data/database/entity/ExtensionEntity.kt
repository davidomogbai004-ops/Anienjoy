package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "extensions",
    indices = [
        Index(value = ["pkgName"], unique = true)
    ]
)
data class ExtensionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val pkgName: String,
    val version: String,
    val versionCode: Int,
    val libVersion: String,
    val lang: String,
    val isNsfw: Boolean,
    val isInstalled: Boolean = false,
    val hasUpdate: Boolean = false,
    val repoUrl: String? = null,
    val iconUrl: String? = null,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "extension_repos",
    indices = [
        Index(value = ["url"], unique = true)
    ]
)
data class ExtensionRepoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val url: String,
    val enabled: Boolean = true,
    val lastUpdated: Long = 0
)
