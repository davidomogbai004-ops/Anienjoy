package com.anienjoy.data.repository

import androidx.paging.PagingSource
import com.anienjoy.data.database.dao.ChapterDao
import com.anienjoy.data.database.dao.MangaDao
import com.anienjoy.data.database.entity.ChapterEntity
import com.anienjoy.data.database.entity.MangaEntity
import com.anienjoy.domain.repository.MangaRepository
import com.anienjoy.extension.api.network.NetworkHelper
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MangaRepositoryImpl @Inject constructor(
    private val mangaDao: MangaDao,
    private val chapterDao: ChapterDao,
    private val networkHelper: NetworkHelper
) : MangaRepository {

    override fun getFavoriteManga(): Flow<List<MangaEntity>> {
        return mangaDao.getFavoriteManga()
    }

    override fun getFavoriteMangaPaging(): PagingSource<Int, MangaEntity> {
        return mangaDao.getFavoriteMangaPaging()
    }

    override fun getFavoriteByContentType(contentType: String): Flow<List<MangaEntity>> {
        return mangaDao.getFavoriteByContentType(contentType)
    }

    override suspend fun getMangaById(id: Long): MangaEntity? {
        return mangaDao.getMangaById(id)
    }

    override suspend fun getMangaBySourceAndUrl(source: String, url: String): MangaEntity? {
        return mangaDao.getMangaBySourceAndUrl(source, url)
    }

    override suspend fun insertManga(manga: MangaEntity): Long {
        return mangaDao.insert(manga)
    }

    override suspend fun updateManga(manga: MangaEntity) {
        mangaDao.update(manga)
    }

    override suspend fun deleteManga(manga: MangaEntity) {
        mangaDao.delete(manga)
    }

    override suspend fun updateFavorite(mangaId: Long, favorite: Boolean) {
        mangaDao.updateFavorite(mangaId, favorite)
    }

    override suspend fun updateThumbnail(mangaId: Long, thumbnailUrl: String?) {
        mangaDao.updateThumbnail(mangaId, thumbnailUrl)
    }

    override suspend fun isMangaFavorite(source: String, url: String): Boolean {
        return mangaDao.isMangaFavorite(source, url)
    }

    override fun searchFavoriteManga(query: String): Flow<List<MangaEntity>> {
        return mangaDao.searchFavoriteManga(query)
    }

    override fun getFavoriteMangaCount(): Flow<Int> {
        return mangaDao.getFavoriteMangaCount()
    }

    override fun getFavoriteCountByType(contentType: String): Flow<Int> {
        return mangaDao.getFavoriteCountByType(contentType)
    }

    // Chapter operations
    override fun getChaptersByMangaId(mangaId: Long): Flow<List<ChapterEntity>> {
        return chapterDao.getChaptersByMangaId(mangaId)
    }

    override suspend fun getChaptersByMangaIdSync(mangaId: Long): List<ChapterEntity> {
        return chapterDao.getChaptersByMangaIdSync(mangaId)
    }

    override suspend fun getChapterById(id: Long): ChapterEntity? {
        return chapterDao.getChapterById(id)
    }

    override suspend fun insertChapter(chapter: ChapterEntity): Long {
        return chapterDao.insert(chapter)
    }

    override suspend fun insertChapters(chapters: List<ChapterEntity>) {
        chapterDao.insertAll(chapters)
    }

    override suspend fun updateChapter(chapter: ChapterEntity) {
        chapterDao.update(chapter)
    }

    override suspend fun deleteChapter(chapter: ChapterEntity) {
        chapterDao.delete(chapter)
    }

    override suspend fun updateChapterRead(chapterId: Long, read: Boolean) {
        chapterDao.updateRead(chapterId, read)
    }

    override suspend fun updateChapterBookmark(chapterId: Long, bookmark: Boolean) {
        chapterDao.updateBookmark(chapterId, bookmark)
    }

    override suspend fun updateLastPageRead(chapterId: Long, lastPageRead: Int) {
        chapterDao.updateLastPageRead(chapterId, lastPageRead)
    }

    override fun getReadChapterCount(mangaId: Long): Flow<Int> {
        return chapterDao.getReadChapterCount(mangaId)
    }

    override fun getTotalChapterCount(mangaId: Long): Flow<Int> {
        return chapterDao.getTotalChapterCount(mangaId)
    }

    override suspend fun getNextUnreadChapter(mangaId: Long): ChapterEntity? {
        return chapterDao.getNextUnreadChapter(mangaId)
    }

    override suspend fun deleteAllChaptersByMangaId(mangaId: Long) {
        chapterDao.deleteAllByMangaId(mangaId)
    }
}
