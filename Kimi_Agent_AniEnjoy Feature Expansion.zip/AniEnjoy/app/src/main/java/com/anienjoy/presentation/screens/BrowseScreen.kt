package com.anienjoy.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.anienjoy.extension.api.AnimeSource
import com.anienjoy.extension.api.MangaSource
import com.anienjoy.extension.api.NovelSource
import com.anienjoy.extension.api.Source

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    navController: NavController,
    viewModel: BrowseViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Sources", "Extensions")

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title) }
                )
            }
        }

        when (selectedTab) {
            0 -> SourcesTab(
                sources = uiState.sources,
                selectedContentType = uiState.selectedContentType,
                onContentTypeChange = viewModel::setContentType,
                onSourceClick = { source ->
                    // Navigate to source catalog
                }
            )
            1 -> ExtensionsTab(
                extensions = uiState.extensions,
                onInstallClick = viewModel::installExtension,
                onUninstallClick = viewModel::uninstallExtension
            )
        }
    }
}

@Composable
fun SourcesTab(
    sources: List<Source>,
    selectedContentType: ContentTypeFilter,
    onContentTypeChange: (ContentTypeFilter) -> Unit,
    onSourceClick: (Source) -> Unit
) {
    Column {
        // Content type filter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedContentType == ContentTypeFilter.ALL,
                onClick = { onContentTypeChange(ContentTypeFilter.ALL) },
                label = { Text("All") }
            )
            FilterChip(
                selected = selectedContentType == ContentTypeFilter.ANIME,
                onClick = { onContentTypeChange(ContentTypeFilter.ANIME) },
                label = { Text("Anime") }
            )
            FilterChip(
                selected = selectedContentType == ContentTypeFilter.MANGA,
                onClick = { onContentTypeChange(ContentTypeFilter.MANGA) },
                label = { Text("Manga") }
            )
            FilterChip(
                selected = selectedContentType == ContentTypeFilter.NOVEL,
                onClick = { onContentTypeChange(ContentTypeFilter.NOVEL) },
                label = { Text("Novels") }
            )
        }

        // Language filter
        LanguageFilterSection()

        // Sources list
        LazyColumn {
            items(sources) { source ->
                SourceListItem(
                    source = source,
                    onClick = { onSourceClick(source) }
                )
            }
        }
    }
}

@Composable
fun LanguageFilterSection() {
    var expanded by remember { mutableStateOf(false) }
    val languages = listOf(
        "en" to "English",
        "ja" to "Japanese",
        "ko" to "Korean",
        "zh" to "Chinese"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        languages.forEach { (code, name) ->
            FilterChip(
                selected = true,
                onClick = { },
                label = { Text(name) }
            )
        }
    }
}

@Composable
fun SourceListItem(
    source: Source,
    onClick: () -> Unit
) {
    val icon = when (source) {
        is AnimeSource -> Icons.Default.PlayCircle
        is MangaSource -> Icons.Default.MenuBook
        is NovelSource -> Icons.Default.AutoStories
        else -> Icons.Default.Source
    }

    ListItem(
        headlineContent = { Text(source.name) },
        supportingContent = { Text("${source.lang.uppercase()} • ${source.baseUrl}") },
        leadingContent = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        trailingContent = {
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
fun ExtensionsTab(
    extensions: List<ExtensionInfo>,
    onInstallClick: (ExtensionInfo) -> Unit,
    onUninstallClick: (ExtensionInfo) -> Unit
) {
    LazyColumn {
        items(extensions) { extension ->
            ExtensionListItem(
                extension = extension,
                onInstallClick = { onInstallClick(extension) },
                onUninstallClick = { onUninstallClick(extension) }
            )
        }
    }
}

@Composable
fun ExtensionListItem(
    extension: ExtensionInfo,
    onInstallClick: () -> Unit,
    onUninstallClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(extension.name) },
        supportingContent = {
            Column {
                Text("Version: ${extension.version}")
                Text("Language: ${extension.lang.uppercase()}")
                if (extension.sources.isNotEmpty()) {
                    Text("Sources: ${extension.sources.size}")
                }
            }
        },
        leadingContent = {
            Icon(
                imageVector = Icons.Default.Extension,
                contentDescription = null
            )
        },
        trailingContent = {
            if (extension.isInstalled) {
                if (extension.hasUpdate) {
                    Button(onClick = onInstallClick) {
                        Text("Update")
                    }
                } else {
                    OutlinedButton(onClick = onUninstallClick) {
                        Text("Uninstall")
                    }
                }
            } else {
                Button(onClick = onInstallClick) {
                    Text("Install")
                }
            }
        }
    )
}

enum class ContentTypeFilter {
    ALL, ANIME, MANGA, MANHWA, MANHUA, NOVEL
}
