package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.CategoryEntity
import kotlinx.coroutines.flow.Flow

interface CategoryRepository {
    fun getAllCategories(): Flow<List<CategoryEntity>>
    suspend fun getAllCategoriesSync(): List<CategoryEntity>
    suspend fun getCategoryById(id: Int): CategoryEntity?
    suspend fun insertCategory(category: CategoryEntity): Long
    suspend fun updateCategory(category: CategoryEntity)
    suspend fun deleteCategory(category: CategoryEntity)
    suspend fun getMaxOrder(): Int

    // Anime categories
    suspend fun getAnimeCategoryIds(animeId: Long): List<Int>
    suspend fun addAnimeToCategory(animeId: Long, categoryId: Int)
    suspend fun removeAnimeFromCategory(animeId: Long, categoryId: Int)
    suspend fun removeAnimeFromAllCategories(animeId: Long)

    // Manga categories
    suspend fun getMangaCategoryIds(mangaId: Long): List<Int>
    suspend fun addMangaToCategory(mangaId: Long, categoryId: Int)
    suspend fun removeMangaFromCategory(mangaId: Long, categoryId: Int)
    suspend fun removeMangaFromAllCategories(mangaId: Long)

    // Novel categories
    suspend fun getNovelCategoryIds(novelId: Long): List<Int>
    suspend fun addNovelToCategory(novelId: Long, categoryId: Int)
    suspend fun removeNovelFromCategory(novelId: Long, categoryId: Int)
    suspend fun removeNovelFromAllCategories(novelId: Long)
}
