package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.DownloadEntity
import kotlinx.coroutines.flow.Flow

interface DownloadRepository {
    fun getAllDownloads(): Flow<List<DownloadEntity>>
    fun getDownloadsByStatus(status: Int): Flow<List<DownloadEntity>>
    fun getDownloadsByStatuses(statuses: List<Int>): Flow<List<DownloadEntity>>
    fun getDownloadsForContent(contentId: Long, contentType: String): Flow<List<DownloadEntity>>
    suspend fun getDownloadById(id: Long): DownloadEntity?
    suspend fun getNextPendingDownload(): DownloadEntity?
    fun getActiveDownloadCount(): Flow<Int>
    fun getPendingDownloadCount(): Flow<Int>
    fun getCompletedDownloadCount(): Flow<Int>
    suspend fun insertDownload(download: DownloadEntity): Long
    suspend fun insertDownloads(downloads: List<DownloadEntity>)
    suspend fun updateDownload(download: DownloadEntity)
    suspend fun updateStatus(downloadId: Long, status: Int)
    suspend fun updateProgress(downloadId: Long, bytes: Long, total: Long)
    suspend fun markAsCompleted(downloadId: Long, path: String, timestamp: Long)
    suspend fun markAsFailed(downloadId: Long, error: String)
    suspend fun deleteDownload(download: DownloadEntity)
    suspend fun deleteDownloadById(downloadId: Long)
    suspend fun deleteCompletedDownloads()
    suspend fun deleteAllDownloads()
    suspend fun isContentDownloading(contentId: Long, contentType: String, chapterId: Long?): Boolean
    suspend fun isContentDownloaded(contentId: Long, contentType: String, chapterId: Long?): Boolean
}
