package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import com.anienjoy.data.database.entity.NovelEntity
import kotlinx.coroutines.flow.Flow

interface LibraryRepository {
    // Combined library
    fun getAllLibraryItems(): Flow<LibraryItems>
    fun getLibraryCount(): Flow<LibraryCounts>

    // Anime library
    fun getAnimeLibrary(): Flow<List<AnimeEntity>>
    suspend fun addAnimeToLibrary(anime: AnimeEntity): Long
    suspend fun removeAnimeFromLibrary(animeId: Long)

    // Manga library
    fun getMangaLibrary(): Flow<List<MangaEntity>>
    suspend fun addMangaToLibrary(manga: MangaEntity): Long
    suspend fun removeMangaFromLibrary(mangaId: Long)

    // Manhwa library
    fun getManhwaLibrary(): Flow<List<MangaEntity>>

    // Manhua library
    fun getManhuaLibrary(): Flow<List<MangaEntity>>

    // Novel library
    fun getNovelLibrary(): Flow<List<NovelEntity>>
    suspend fun addNovelToLibrary(novel: NovelEntity): Long
    suspend fun removeNovelFromLibrary(novelId: Long)

    // Search
    fun searchLibrary(query: String): Flow<LibraryItems>

    // Update checking
    suspend fun checkForUpdates()
    suspend fun updateLibraryItem(item: Any)
}

data class LibraryItems(
    val anime: List<AnimeEntity> = emptyList(),
    val manga: List<MangaEntity> = emptyList(),
    val manhwa: List<MangaEntity> = emptyList(),
    val manhua: List<MangaEntity> = emptyList(),
    val novels: List<NovelEntity> = emptyList()
)

data class LibraryCounts(
    val animeCount: Int = 0,
    val mangaCount: Int = 0,
    val manhwaCount: Int = 0,
    val manhuaCount: Int = 0,
    val novelCount: Int = 0,
    val totalCount: Int = 0
)
