package com.anienjoy.data.tracker

import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TrackerManager @Inject constructor(
    val anilist: AniListTracker,
    val myanimelist: MyAnimeListTracker
) {
    private val _activeTrackers = MutableStateFlow<List<TrackerService>>(emptyList())
    val activeTrackers: StateFlow<List<TrackerService>> = _activeTrackers.asStateFlow()

    private val _syncEnabled = MutableStateFlow(true)
    val syncEnabled: StateFlow<Boolean> = _syncEnabled.asStateFlow()

    init {
        refreshActiveTrackers()
    }

    fun refreshActiveTrackers() {
        val trackers = mutableListOf<TrackerService>()
        if (anilist.isLoggedInBlocking()) trackers.add(anilist)
        if (myanimelist.isLoggedInBlocking()) trackers.add(myanimelist)
        _activeTrackers.value = trackers
    }

    fun setSyncEnabled(enabled: Boolean) {
        _syncEnabled.value = enabled
    }

    suspend fun syncAnimeProgress(anime: AnimeEntity, episodesWatched: Int) {
        if (!_syncEnabled.value) return

        val status = when {
            episodesWatched == 0 -> TrackerStatus.PLANNING
            anime.viewers > 0 && episodesWatched >= anime.viewers -> TrackerStatus.COMPLETED
            else -> TrackerStatus.CURRENT
        }

        activeTrackers.value.forEach { tracker ->
            try {
                tracker.syncAnime(anime, episodesWatched, status)
            } catch (e: Exception) {
                // Log error but continue with other trackers
            }
        }
    }

    suspend fun syncMangaProgress(manga: MangaEntity, chaptersRead: Int) {
        if (!_syncEnabled.value) return

        val status = when {
            chaptersRead == 0 -> TrackerStatus.PLANNING
            manga.viewers > 0 && chaptersRead >= manga.viewers -> TrackerStatus.COMPLETED
            else -> TrackerStatus.CURRENT
        }

        activeTrackers.value.forEach { tracker ->
            try {
                tracker.syncManga(manga, chaptersRead, status)
            } catch (e: Exception) {
                // Log error but continue with other trackers
            }
        }
    }

    fun getAllTrackers(): List<TrackerService> {
        return listOf(anilist, myanimelist)
    }

    suspend fun logoutAll() {
        anilist.logout()
        myanimelist.logout()
        refreshActiveTrackers()
    }

    private fun TrackerService.isLoggedInBlocking(): Boolean {
        return try {
            kotlinx.coroutines.runBlocking { isLoggedIn() }
        } catch (e: Exception) {
            false
        }
    }
}
