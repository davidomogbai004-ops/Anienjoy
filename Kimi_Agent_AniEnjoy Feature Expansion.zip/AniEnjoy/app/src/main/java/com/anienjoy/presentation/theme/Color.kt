package com.anienjoy.presentation.theme

import androidx.compose.ui.graphics.Color

// Primary colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// AniEnjoy brand colors
val AniEnjoyPrimary = Color(0xFF6B4EE6)
val AniEnjoyPrimaryDark = Color(0xFF4A3AA8)
val AniEnjoySecondary = Color(0xFF03DAC6)
val AniEnjoyBackground = Color(0xFF121212)
val AniEnjoySurface = Color(0xFF1E1E1E)
val AniEnjoyError = Color(0xFFCF6679)

// Content type colors
val AnimeColor = Color(0xFFFF6B6B)
val MangaColor = Color(0xFF4ECDC4)
val ManhwaColor = Color(0xFF95E1D3)
val ManhuaColor = Color(0xFFF38181)
val NovelColor = Color(0xFFAA96DA)

// Status colors
val StatusOngoing = Color(0xFF4CAF50)
val StatusCompleted = Color(0xFF2196F3)
val StatusHiatus = Color(0xFFFF9800)
val StatusCancelled = Color(0xFFF44336)
