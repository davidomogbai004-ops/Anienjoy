package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.ChapterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterDao {

    @Query("SELECT * FROM chapters WHERE mangaId = :mangaId ORDER BY sourceOrder ASC")
    fun getChaptersByMangaId(mangaId: Long): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE mangaId = :mangaId ORDER BY sourceOrder ASC")
    suspend fun getChaptersByMangaIdSync(mangaId: Long): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun getChapterById(id: Long): ChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(chapters: List<ChapterEntity>)

    @Update
    suspend fun update(chapter: ChapterEntity)

    @Delete
    suspend fun delete(chapter: ChapterEntity)

    @Query("UPDATE chapters SET read = :read WHERE id = :chapterId")
    suspend fun updateRead(chapterId: Long, read: Boolean)

    @Query("UPDATE chapters SET bookmark = :bookmark WHERE id = :chapterId")
    suspend fun updateBookmark(chapterId: Long, bookmark: Boolean)

    @Query("UPDATE chapters SET lastPageRead = :lastPageRead WHERE id = :chapterId")
    suspend fun updateLastPageRead(chapterId: Long, lastPageRead: Int)

    @Query("SELECT COUNT(*) FROM chapters WHERE mangaId = :mangaId AND read = 1")
    fun getReadChapterCount(mangaId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM chapters WHERE mangaId = :mangaId")
    fun getTotalChapterCount(mangaId: Long): Flow<Int>

    @Query("SELECT * FROM chapters WHERE mangaId = :mangaId AND read = 0 ORDER BY sourceOrder ASC LIMIT 1")
    suspend fun getNextUnreadChapter(mangaId: Long): ChapterEntity?

    @Query("DELETE FROM chapters WHERE mangaId = :mangaId")
    suspend fun deleteAllByMangaId(mangaId: Long)
}
