package com.anienjoy.data.tracker

import android.content.Context
import android.content.SharedPreferences
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AniListTracker @Inject constructor(
    private val context: Context
) : TrackerService {

    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }
    private val prefs: SharedPreferences = context.getSharedPreferences("anilist_tracker", Context.MODE_PRIVATE)

    override val name: String = "AniList"
    override val iconUrl: String = "https://anilist.co/img/icons/icon.svg"

    private val clientId = "YOUR_ANILIST_CLIENT_ID" // Replace with actual client ID
    private val clientSecret = "YOUR_ANILIST_CLIENT_SECRET" // Replace with actual client secret
    private val redirectUri = "anienjoy://anilist/callback"
    private val baseUrl = "https://graphql.anilist.co"

    override suspend fun login(username: String, password: String?, authCode: String?): Result<String> {
        return try {
            // AniList uses OAuth2, so we need an auth code
            authCode?.let { code ->
                val token = exchangeCodeForToken(code)
                saveToken(token)
                Result.success("Logged in successfully")
            } ?: Result.failure(Exception("Auth code required"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun logout() {
        prefs.edit().remove("access_token").remove("refresh_token").apply()
    }

    override suspend fun isLoggedIn(): Boolean {
        return getAccessToken() != null
    }

    override suspend fun searchAnime(query: String): List<TrackerSearchResult> {
        return searchMedia(query, "ANIME")
    }

    override suspend fun searchManga(query: String): List<TrackerSearchResult> {
        return searchMedia(query, "MANGA")
    }

    private suspend fun searchMedia(query: String, type: String): List<TrackerSearchResult> {
        val graphqlQuery = """
            query SearchMedia(${'$'}search: String, ${'$'}type: MediaType) {
                Page(page: 1, perPage: 10) {
                    media(search: ${'$'}search, type: ${'$'}type) {
                        id
                        title {
                            romaji
                            english
                            native
                        }
                        coverImage {
                            large
                        }
                        description
                        episodes
                        chapters
                        startDate {
                            year
                            month
                            day
                        }
                        status
                    }
                }
            }
        """.trimIndent()

        val variables = buildJsonObject {
            put("search", query)
            put("type", type)
        }

        val requestBody = buildJsonObject {
            put("query", graphqlQuery)
            put("variables", variables)
        }.toString()

        val request = Request.Builder()
            .url(baseUrl)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return emptyList()
            val result = json.decodeFromString<AniListSearchResponse>(responseBody)

            result.data.Page.media.map { media ->
                TrackerSearchResult(
                    id = media.id.toString(),
                    title = media.title.english ?: media.title.romaji ?: media.title.native ?: "Unknown",
                    coverImage = media.coverImage?.large,
                    description = media.description,
                    type = type,
                    totalEpisodes = media.episodes,
                    totalChapters = media.chapters,
                    startDate = media.startDate?.let { "${it.year}-${it.month}-${it.day}" },
                    status = media.status
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override suspend fun getAnimeList(): List<TrackerAnimeEntry> {
        return getUserList("ANIME") { entry ->
            TrackerAnimeEntry(
                id = entry.id.toString(),
                mediaId = entry.mediaId.toString(),
                title = entry.media.title.english ?: entry.media.title.romaji ?: "Unknown",
                coverImage = entry.media.coverImage?.large,
                status = TrackerStatus.fromValue(entry.status ?: "CURRENT"),
                score = entry.score?.toFloat() ?: 0f,
                episodesWatched = entry.progress ?: 0,
                totalEpisodes = entry.media.episodes,
                startDate = entry.startedAt?.let { "${it.year}-${it.month}-${it.day}" },
                finishDate = entry.completedAt?.let { "${it.year}-${it.month}-${it.day}" },
                rewatchCount = entry.repeat ?: 0,
                notes = entry.notes
            )
        }
    }

    override suspend fun getMangaList(): List<TrackerMangaEntry> {
        return getUserList("MANGA") { entry ->
            TrackerMangaEntry(
                id = entry.id.toString(),
                mediaId = entry.mediaId.toString(),
                title = entry.media.title.english ?: entry.media.title.romaji ?: "Unknown",
                coverImage = entry.media.coverImage?.large,
                status = TrackerStatus.fromValue(entry.status ?: "CURRENT"),
                score = entry.score?.toFloat() ?: 0f,
                chaptersRead = entry.progress ?: 0,
                totalChapters = entry.media.chapters,
                volumesRead = entry.progressVolumes ?: 0,
                totalVolumes = entry.media.volumes,
                startDate = entry.startedAt?.let { "${it.year}-${it.month}-${it.day}" },
                finishDate = entry.completedAt?.let { "${it.year}-${it.month}-${it.day}" },
                rereadCount = entry.repeat ?: 0,
                notes = entry.notes
            )
        }
    }

    private suspend fun <T> getUserList(type: String, mapper: (AniListListEntry) -> T): List<T> {
        val token = getAccessToken() ?: return emptyList()

        val graphqlQuery = """
            query GetUserList(${'$'}type: MediaType) {
                MediaListCollection(userId: @viewer, type: ${'$'}type) {
                    lists {
                        entries {
                            id
                            mediaId
                            status
                            score
                            progress
                            progressVolumes
                            repeat
                            startedAt {
                                year
                                month
                                day
                            }
                            completedAt {
                                year
                                month
                                day
                            }
                            notes
                            media {
                                title {
                                    romaji
                                    english
                                    native
                                }
                                coverImage {
                                    large
                                }
                                episodes
                                chapters
                                volumes
                            }
                        }
                    }
                }
            }
        """.trimIndent()

        val variables = buildJsonObject {
            put("type", type)
        }

        val requestBody = buildJsonObject {
            put("query", graphqlQuery)
            put("variables", variables)
        }.toString()

        val request = Request.Builder()
            .url(baseUrl)
            .header("Authorization", "Bearer $token")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return emptyList()
            val result = json.decodeFromString<AniListCollectionResponse>(responseBody)

            result.data.MediaListCollection.lists.flatMap { list ->
                list.entries.map(mapper)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override suspend fun addAnime(entry: TrackerAnimeEntry): Result<Unit> {
        return saveMediaListEntry(
            mediaId = entry.mediaId,
            status = entry.status.value,
            score = entry.score,
            progress = entry.episodesWatched
        )
    }

    override suspend fun updateAnime(entry: TrackerAnimeEntry): Result<Unit> {
        return entry.id?.let { id ->
            saveMediaListEntry(
                id = id,
                mediaId = entry.mediaId,
                status = entry.status.value,
                score = entry.score,
                progress = entry.episodesWatched
            )
        } ?: Result.failure(Exception("Entry ID required for update"))
    }

    override suspend fun addManga(entry: TrackerMangaEntry): Result<Unit> {
        return saveMediaListEntry(
            mediaId = entry.mediaId,
            status = entry.status.value,
            score = entry.score,
            progress = entry.chaptersRead,
            progressVolumes = entry.volumesRead
        )
    }

    override suspend fun updateManga(entry: TrackerMangaEntry): Result<Unit> {
        return entry.id?.let { id ->
            saveMediaListEntry(
                id = id,
                mediaId = entry.mediaId,
                status = entry.status.value,
                score = entry.score,
                progress = entry.chaptersRead,
                progressVolumes = entry.volumesRead
            )
        } ?: Result.failure(Exception("Entry ID required for update"))
    }

    private suspend fun saveMediaListEntry(
        id: String? = null,
        mediaId: String,
        status: String,
        score: Float,
        progress: Int,
        progressVolumes: Int? = null
    ): Result<Unit> {
        val token = getAccessToken() ?: return Result.failure(Exception("Not logged in"))

        val mutation = """
            mutation SaveMediaListEntry(${'$'}id: Int, ${'$'}mediaId: Int, ${'$'}status: MediaListStatus, ${'$'}score: Float, ${'$'}progress: Int, ${'$'}progressVolumes: Int) {
                SaveMediaListEntry(id: ${'$'}id, mediaId: ${'$'}mediaId, status: ${'$'}status, score: ${'$'}score, progress: ${'$'}progress, progressVolumes: ${'$'}progressVolumes) {
                    id
                }
            }
        """.trimIndent()

        val variables = buildJsonObject {
            id?.let { put("id", it.toInt()) }
            put("mediaId", mediaId.toInt())
            put("status", status.uppercase())
            put("score", score)
            put("progress", progress)
            progressVolumes?.let { put("progressVolumes", it) }
        }

        val requestBody = buildJsonObject {
            put("query", mutation)
            put("variables", variables)
        }.toString()

        val request = Request.Builder()
            .url(baseUrl)
            .header("Authorization", "Bearer $token")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to save entry: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteAnime(id: String): Result<Unit> {
        return deleteMediaListEntry(id)
    }

    override suspend fun deleteManga(id: String): Result<Unit> {
        return deleteMediaListEntry(id)
    }

    private suspend fun deleteMediaListEntry(id: String): Result<Unit> {
        val token = getAccessToken() ?: return Result.failure(Exception("Not logged in"))

        val mutation = """
            mutation DeleteMediaListEntry(${'$'}id: Int) {
                DeleteMediaListEntry(id: ${'$'}id) {
                    deleted
                }
            }
        """.trimIndent()

        val variables = buildJsonObject {
            put("id", id.toInt())
        }

        val requestBody = buildJsonObject {
            put("query", mutation)
            put("variables", variables)
        }.toString()

        val request = Request.Builder()
            .url(baseUrl)
            .header("Authorization", "Bearer $token")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to delete entry: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncAnime(anime: AnimeEntity, episodesWatched: Int, status: TrackerStatus) {
        // Search for anime on AniList
        val results = searchAnime(anime.title)
        val match = results.firstOrNull { it.title.equals(anime.title, ignoreCase = true) }
            ?: results.firstOrNull()

        match?.let {
            val entry = TrackerAnimeEntry(
                mediaId = it.id,
                title = it.title,
                coverImage = it.coverImage,
                status = status,
                episodesWatched = episodesWatched,
                totalEpisodes = it.totalEpisodes
            )
            addAnime(entry)
        }
    }

    override suspend fun syncManga(manga: MangaEntity, chaptersRead: Int, status: TrackerStatus) {
        // Search for manga on AniList
        val results = searchManga(manga.title)
        val match = results.firstOrNull { it.title.equals(manga.title, ignoreCase = true) }
            ?: results.firstOrNull()

        match?.let {
            val entry = TrackerMangaEntry(
                mediaId = it.id,
                title = it.title,
                coverImage = it.coverImage,
                status = status,
                chaptersRead = chaptersRead,
                totalChapters = it.totalChapters
            )
            addManga(entry)
        }
    }

    private suspend fun exchangeCodeForToken(code: String): String {
        // Implementation for OAuth2 token exchange
        // This would make a POST request to AniList's token endpoint
        return ""
    }

    private fun saveToken(token: String) {
        prefs.edit().putString("access_token", token).apply()
    }

    private fun getAccessToken(): String? {
        return prefs.getString("access_token", null)
    }

    fun getAuthUrl(): String {
        return "https://anilist.co/api/v2/oauth/authorize?client_id=$clientId&response_type=code&redirect_uri=$redirectUri"
    }
}

// Data classes for AniList API responses
@Serializable
data class AniListSearchResponse(
    val data: AniListSearchData
)

@Serializable
data class AniListSearchData(
    val Page: AniListPage
)

@Serializable
data class AniListPage(
    val media: List<AniListMedia>
)

@Serializable
data class AniListMedia(
    val id: Int,
    val title: AniListTitle,
    val coverImage: AniListCoverImage? = null,
    val description: String? = null,
    val episodes: Int? = null,
    val chapters: Int? = null,
    val volumes: Int? = null,
    val startDate: AniListDate? = null,
    val status: String? = null
)

@Serializable
data class AniListTitle(
    val romaji: String? = null,
    val english: String? = null,
    val native: String? = null
)

@Serializable
data class AniListCoverImage(
    val large: String? = null
)

@Serializable
data class AniListDate(
    val year: Int? = null,
    val month: Int? = null,
    val day: Int? = null
)

@Serializable
data class AniListCollectionResponse(
    val data: AniListCollectionData
)

@Serializable
data class AniListCollectionData(
    val MediaListCollection: AniListMediaListCollection
)

@Serializable
data class AniListMediaListCollection(
    val lists: List<AniListList>
)

@Serializable
data class AniListList(
    val entries: List<AniListListEntry>
)

@Serializable
data class AniListListEntry(
    val id: Int,
    val mediaId: Int,
    val status: String? = null,
    val score: Double? = null,
    val progress: Int? = null,
    val progressVolumes: Int? = null,
    val repeat: Int? = null,
    val startedAt: AniListDate? = null,
    val completedAt: AniListDate? = null,
    val notes: String? = null,
    val media: AniListMedia
)
