package com.anienjoy.presentation.screens.details

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.anienjoy.data.database.entity.ChapterEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaDetailsScreen(
    navController: NavController,
    mangaId: Long?,
    viewModel: MangaDetailsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(mangaId) {
        mangaId?.let { viewModel.loadManga(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = (uiState as? MangaDetailsUiState.Success)?.manga?.title ?: "Manga Details",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    val state = uiState as? MangaDetailsUiState.Success
                    state?.let {
                        IconButton(onClick = { viewModel.toggleFavorite() }) {
                            Icon(
                                imageVector = if (it.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite"
                            )
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = uiState) {
                is MangaDetailsUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is MangaDetailsUiState.Success -> {
                    MangaDetailsContent(
                        state = state,
                        onChapterClick = { chapter ->
                            navController.navigate("reader/${chapter.id}")
                        },
                        onRefresh = { viewModel.refreshChapters() }
                    )
                }
                is MangaDetailsUiState.Error -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Error: ${state.message}")
                    }
                }
            }
        }
    }
}

@Composable
fun MangaDetailsContent(
    state: MangaDetailsUiState.Success,
    onChapterClick: (ChapterEntity) -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn {
        // Header with cover and info
        item {
            MangaHeader(state)
        }

        // Description
        item {
            state.manga.description?.let { description ->
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        // Genres
        item {
            if (state.manga.genre.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    state.manga.genre.split(",").forEach { genre ->
                        AssistChip(
                            onClick = { },
                            label = { Text(genre.trim()) }
                        )
                    }
                }
            }
        }

        // Chapters section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Chapters (${state.chapters.size})",
                    style = MaterialTheme.typography.titleMedium
                )
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                }
            }
        }

        items(state.chapters) { chapter ->
            ChapterListItem(
                chapter = chapter,
                onClick = { onChapterClick(chapter) }
            )
        }
    }
}

@Composable
fun MangaHeader(state: MangaDetailsUiState.Success) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Cover image
        AsyncImage(
            model = state.manga.thumbnailUrl,
            contentDescription = null,
            modifier = Modifier
                .width(120.dp)
                .aspectRatio(2f / 3f),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.width(16.dp))

        // Info
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = state.manga.title,
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Status
            val statusText = when (state.manga.status) {
                1 -> "Ongoing"
                2 -> "Completed"
                3 -> "Licensed"
                4 -> "Publishing Finished"
                5 -> "Cancelled"
                6 -> "On Hiatus"
                else -> "Unknown"
            }
            Text(
                text = "Status: $statusText",
                style = MaterialTheme.typography.bodyMedium
            )

            // Author
            state.manga.author?.let {
                Text(
                    text = "Author: $it",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Artist
            state.manga.artist?.let {
                Text(
                    text = "Artist: $it",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Source
            Text(
                text = "Source: ${state.manga.source}",
                style = MaterialTheme.typography.bodyMedium
            )

            // Chapter count
            Text(
                text = "Chapters: ${state.chapters.size}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun ChapterListItem(
    chapter: ChapterEntity,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(chapter.name) },
        supportingContent = {
            Row {
                if (chapter.read) {
                    Text(
                        text = "Read",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (chapter.bookmark) {
                    Text(
                        text = if (chapter.read) " • Bookmarked" else "Bookmarked",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                if (chapter.scanlator != null) {
                    Text(
                        text = " • ${chapter.scanlator}",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        },
        leadingContent = {
            Icon(
                imageVector = if (chapter.read) Icons.Default.CheckCircle else Icons.Default.Circle,
                contentDescription = null,
                tint = if (chapter.read) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
        },
        trailingContent = {
            if (chapter.lastPageRead > 0) {
                Text("Page ${chapter.lastPageRead}")
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
