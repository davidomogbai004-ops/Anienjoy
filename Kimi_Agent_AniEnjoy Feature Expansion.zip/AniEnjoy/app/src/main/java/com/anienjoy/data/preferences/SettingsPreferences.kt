package com.anienjoy.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

@Singleton
class SettingsPreferences @Inject constructor(
    private val context: Context
) {
    private val dataStore = context.dataStore

    // Theme settings
    val themeMode: Flow<ThemeMode> = dataStore.data.map { preferences ->
        ThemeMode.valueOf(
            preferences[THEME_MODE] ?: ThemeMode.SYSTEM.name
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { preferences ->
            preferences[THEME_MODE] = mode.name
        }
    }

    // Language filter settings
    val enabledLanguages: Flow<Set<String>> = dataStore.data.map { preferences ->
        preferences[ENABLED_LANGUAGES] ?: setOf("en", "ja")
    }

    suspend fun setEnabledLanguages(languages: Set<String>) {
        dataStore.edit { preferences ->
            preferences[ENABLED_LANGUAGES] = languages
        }
    }

    // Library settings
    val libraryColumnsPortrait: Flow<Int> = dataStore.data.map { preferences ->
        preferences[LIBRARY_COLUMNS_PORTRAIT] ?: 3
    }

    suspend fun setLibraryColumnsPortrait(columns: Int) {
        dataStore.edit { preferences ->
            preferences[LIBRARY_COLUMNS_PORTRAIT] = columns
        }
    }

    val libraryColumnsLandscape: Flow<Int> = dataStore.data.map { preferences ->
        preferences[LIBRARY_COLUMNS_LANDSCAPE] ?: 5
    }

    suspend fun setLibraryColumnsLandscape(columns: Int) {
        dataStore.edit { preferences ->
            preferences[LIBRARY_COLUMNS_LANDSCAPE] = columns
        }
    }

    // Download settings
    val downloadOnlyOverWifi: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[DOWNLOAD_ONLY_WIFI] ?: true
    }

    suspend fun setDownloadOnlyOverWifi(onlyWifi: Boolean) {
        dataStore.edit { preferences ->
            preferences[DOWNLOAD_ONLY_WIFI] = onlyWifi
        }
    }

    // Player settings
    val defaultPlayerOrientation: Flow<Int> = dataStore.data.map { preferences ->
        preferences[PLAYER_ORIENTATION] ?: 0
    }

    suspend fun setDefaultPlayerOrientation(orientation: Int) {
        dataStore.edit { preferences ->
            preferences[PLAYER_ORIENTATION] = orientation
        }
    }

    val doubleTapSeekDuration: Flow<Int> = dataStore.data.map { preferences ->
        preferences[DOUBLE_TAP_SEEK] ?: 10
    }

    suspend fun setDoubleTapSeekDuration(seconds: Int) {
        dataStore.edit { preferences ->
            preferences[DOUBLE_TAP_SEEK] = seconds
        }
    }

    // Reader settings
    val defaultReadingMode: Flow<Int> = dataStore.data.map { preferences ->
        preferences[READING_MODE] ?: 0
    }

    suspend fun setDefaultReadingMode(mode: Int) {
        dataStore.edit { preferences ->
            preferences[READING_MODE] = mode
        }
    }

    // NSFW settings
    val showNsfw: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[SHOW_NSFW] ?: false
    }

    suspend fun setShowNsfw(show: Boolean) {
        dataStore.edit { preferences ->
            preferences[SHOW_NSFW] = show
        }
    }

    // Extension repos
    val extensionRepos: Flow<Set<String>> = dataStore.data.map { preferences ->
        preferences[EXTENSION_REPOS] ?: DEFAULT_REPOS
    }

    suspend fun setExtensionRepos(repos: Set<String>) {
        dataStore.edit { preferences ->
            preferences[EXTENSION_REPOS] = repos
        }
    }

    companion object {
        private val THEME_MODE = stringPreferencesKey("theme_mode")
        private val ENABLED_LANGUAGES = stringSetPreferencesKey("enabled_languages")
        private val LIBRARY_COLUMNS_PORTRAIT = intPreferencesKey("library_columns_portrait")
        private val LIBRARY_COLUMNS_LANDSCAPE = intPreferencesKey("library_columns_landscape")
        private val DOWNLOAD_ONLY_WIFI = booleanPreferencesKey("download_only_wifi")
        private val PLAYER_ORIENTATION = intPreferencesKey("player_orientation")
        private val DOUBLE_TAP_SEEK = intPreferencesKey("double_tap_seek")
        private val READING_MODE = intPreferencesKey("reading_mode")
        private val SHOW_NSFW = booleanPreferencesKey("show_nsfw")
        private val EXTENSION_REPOS = stringSetPreferencesKey("extension_repos")

        private val DEFAULT_REPOS = setOf(
            "https://raw.githubusercontent.com/aniyomiorg/aniyomi-extensions/repo/index.min.json",
            "https://raw.githubusercontent.com/keiyoushi/extensions/repo/index.min.json"
        )
    }
}

enum class ThemeMode {
    LIGHT,
    DARK,
    SYSTEM
}
