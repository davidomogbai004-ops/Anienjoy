package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.NovelChapterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NovelChapterDao {

    @Query("SELECT * FROM novel_chapters WHERE novelId = :novelId ORDER BY sourceOrder ASC")
    fun getChaptersByNovelId(novelId: Long): Flow<List<NovelChapterEntity>>

    @Query("SELECT * FROM novel_chapters WHERE novelId = :novelId ORDER BY sourceOrder ASC")
    suspend fun getChaptersByNovelIdSync(novelId: Long): List<NovelChapterEntity>

    @Query("SELECT * FROM novel_chapters WHERE id = :id")
    suspend fun getChapterById(id: Long): NovelChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(chapter: NovelChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(chapters: List<NovelChapterEntity>)

    @Update
    suspend fun update(chapter: NovelChapterEntity)

    @Delete
    suspend fun delete(chapter: NovelChapterEntity)

    @Query("UPDATE novel_chapters SET read = :read WHERE id = :chapterId")
    suspend fun updateRead(chapterId: Long, read: Boolean)

    @Query("UPDATE novel_chapters SET bookmark = :bookmark WHERE id = :chapterId")
    suspend fun updateBookmark(chapterId: Long, bookmark: Boolean)

    @Query("UPDATE novel_chapters SET lastReadPosition = :position WHERE id = :chapterId")
    suspend fun updateLastReadPosition(chapterId: Long, position: Int)

    @Query("SELECT COUNT(*) FROM novel_chapters WHERE novelId = :novelId AND read = 1")
    fun getReadChapterCount(novelId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM novel_chapters WHERE novelId = :novelId")
    fun getTotalChapterCount(novelId: Long): Flow<Int>

    @Query("SELECT * FROM novel_chapters WHERE novelId = :novelId AND read = 0 ORDER BY sourceOrder ASC LIMIT 1")
    suspend fun getNextUnreadChapter(novelId: Long): NovelChapterEntity?

    @Query("DELETE FROM novel_chapters WHERE novelId = :novelId")
    suspend fun deleteAllByNovelId(novelId: Long)
}
