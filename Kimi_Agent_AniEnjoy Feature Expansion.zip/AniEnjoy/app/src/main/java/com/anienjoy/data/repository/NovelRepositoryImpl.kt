package com.anienjoy.data.repository

import androidx.paging.PagingSource
import com.anienjoy.data.database.dao.NovelChapterDao
import com.anienjoy.data.database.dao.NovelDao
import com.anienjoy.data.database.entity.NovelChapterEntity
import com.anienjoy.data.database.entity.NovelEntity
import com.anienjoy.domain.repository.NovelRepository
import com.anienjoy.extension.api.network.NetworkHelper
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NovelRepositoryImpl @Inject constructor(
    private val novelDao: NovelDao,
    private val novelChapterDao: NovelChapterDao,
    private val networkHelper: NetworkHelper
) : NovelRepository {

    override fun getFavoriteNovels(): Flow<List<NovelEntity>> {
        return novelDao.getFavoriteNovels()
    }

    override fun getFavoriteNovelsPaging(): PagingSource<Int, NovelEntity> {
        return novelDao.getFavoriteNovelsPaging()
    }

    override suspend fun getNovelById(id: Long): NovelEntity? {
        return novelDao.getNovelById(id)
    }

    override suspend fun getNovelBySourceAndUrl(source: String, url: String): NovelEntity? {
        return novelDao.getNovelBySourceAndUrl(source, url)
    }

    override suspend fun insertNovel(novel: NovelEntity): Long {
        return novelDao.insert(novel)
    }

    override suspend fun updateNovel(novel: NovelEntity) {
        novelDao.update(novel)
    }

    override suspend fun deleteNovel(novel: NovelEntity) {
        novelDao.delete(novel)
    }

    override suspend fun updateFavorite(novelId: Long, favorite: Boolean) {
        novelDao.updateFavorite(novelId, favorite)
    }

    override suspend fun updateThumbnail(novelId: Long, thumbnailUrl: String?) {
        novelDao.updateThumbnail(novelId, thumbnailUrl)
    }

    override suspend fun isNovelFavorite(source: String, url: String): Boolean {
        return novelDao.isNovelFavorite(source, url)
    }

    override fun searchFavoriteNovels(query: String): Flow<List<NovelEntity>> {
        return novelDao.searchFavoriteNovels(query)
    }

    override fun getFavoriteNovelsCount(): Flow<Int> {
        return novelDao.getFavoriteNovelsCount()
    }

    // Chapter operations
    override fun getChaptersByNovelId(novelId: Long): Flow<List<NovelChapterEntity>> {
        return novelChapterDao.getChaptersByNovelId(novelId)
    }

    override suspend fun getChaptersByNovelIdSync(novelId: Long): List<NovelChapterEntity> {
        return novelChapterDao.getChaptersByNovelIdSync(novelId)
    }

    override suspend fun getChapterById(id: Long): NovelChapterEntity? {
        return novelChapterDao.getChapterById(id)
    }

    override suspend fun insertChapter(chapter: NovelChapterEntity): Long {
        return novelChapterDao.insert(chapter)
    }

    override suspend fun insertChapters(chapters: List<NovelChapterEntity>) {
        novelChapterDao.insertAll(chapters)
    }

    override suspend fun updateChapter(chapter: NovelChapterEntity) {
        novelChapterDao.update(chapter)
    }

    override suspend fun deleteChapter(chapter: NovelChapterEntity) {
        novelChapterDao.delete(chapter)
    }

    override suspend fun updateChapterRead(chapterId: Long, read: Boolean) {
        novelChapterDao.updateRead(chapterId, read)
    }

    override suspend fun updateChapterBookmark(chapterId: Long, bookmark: Boolean) {
        novelChapterDao.updateBookmark(chapterId, bookmark)
    }

    override suspend fun updateLastReadPosition(chapterId: Long, position: Int) {
        novelChapterDao.updateLastReadPosition(chapterId, position)
    }

    override fun getReadChapterCount(novelId: Long): Flow<Int> {
        return novelChapterDao.getReadChapterCount(novelId)
    }

    override fun getTotalChapterCount(novelId: Long): Flow<Int> {
        return novelChapterDao.getTotalChapterCount(novelId)
    }

    override suspend fun getNextUnreadChapter(novelId: Long): NovelChapterEntity? {
        return novelChapterDao.getNextUnreadChapter(novelId)
    }

    override suspend fun deleteAllChaptersByNovelId(novelId: Long) {
        novelChapterDao.deleteAllByNovelId(novelId)
    }
}
