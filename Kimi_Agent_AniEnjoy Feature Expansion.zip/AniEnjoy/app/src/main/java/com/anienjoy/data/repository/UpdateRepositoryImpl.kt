package com.anienjoy.data.repository

import com.anienjoy.data.database.dao.UpdateDao
import com.anienjoy.data.database.entity.UpdateEntity
import com.anienjoy.domain.repository.UpdateRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UpdateRepositoryImpl @Inject constructor(
    private val updateDao: UpdateDao
) : UpdateRepository {

    override fun getAllUpdates(): Flow<List<UpdateEntity>> {
        return updateDao.getAllUpdates()
    }

    override fun getUnreadUpdates(): Flow<List<UpdateEntity>> {
        return updateDao.getUnreadUpdates()
    }

    override fun getUpdatesByType(contentType: String): Flow<List<UpdateEntity>> {
        return updateDao.getUpdatesByType(contentType)
    }

    override fun getUnreadUpdateCount(): Flow<Int> {
        return updateDao.getUnreadUpdateCount()
    }

    override suspend fun getUpdateForContent(contentId: Long, contentType: String): UpdateEntity? {
        return updateDao.getUpdateForContent(contentId, contentType)
    }

    override suspend fun insertUpdate(update: UpdateEntity): Long {
        return updateDao.insertUpdate(update)
    }

    override suspend fun insertUpdates(updates: List<UpdateEntity>) {
        updateDao.insertUpdates(updates)
    }

    override suspend fun updateUpdate(update: UpdateEntity) {
        updateDao.updateUpdate(update)
    }

    override suspend fun markAsRead(updateId: Long) {
        updateDao.markAsRead(updateId)
    }

    override suspend fun markAllAsRead() {
        updateDao.markAllAsRead()
    }

    override suspend fun deleteUpdate(update: UpdateEntity) {
        updateDao.deleteUpdate(update)
    }

    override suspend fun deleteOldUpdates(timestamp: Long) {
        updateDao.deleteOldUpdates(timestamp)
    }

    override suspend fun deleteAllUpdates() {
        updateDao.deleteAllUpdates()
    }
}
