package com.anienjoy.data.database.dao

import androidx.paging.PagingSource
import androidx.room.*
import com.anienjoy.data.database.entity.MangaEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MangaDao {

    @Query("SELECT * FROM manga WHERE favorite = 1 ORDER BY dateAdded DESC")
    fun getFavoriteManga(): Flow<List<MangaEntity>>

    @Query("SELECT * FROM manga WHERE favorite = 1 ORDER BY dateAdded DESC")
    fun getFavoriteMangaPaging(): PagingSource<Int, MangaEntity>

    @Query("SELECT * FROM manga WHERE favorite = 1 AND contentType = :contentType ORDER BY dateAdded DESC")
    fun getFavoriteByContentType(contentType: String): Flow<List<MangaEntity>>

    @Query("SELECT * FROM manga WHERE id = :id")
    suspend fun getMangaById(id: Long): MangaEntity?

    @Query("SELECT * FROM manga WHERE source = :source AND url = :url")
    suspend fun getMangaBySourceAndUrl(source: String, url: String): MangaEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(manga: MangaEntity): Long

    @Update
    suspend fun update(manga: MangaEntity)

    @Delete
    suspend fun delete(manga: MangaEntity)

    @Query("UPDATE manga SET favorite = :favorite WHERE id = :mangaId")
    suspend fun updateFavorite(mangaId: Long, favorite: Boolean)

    @Query("UPDATE manga SET thumbnailUrl = :thumbnailUrl WHERE id = :mangaId")
    suspend fun updateThumbnail(mangaId: Long, thumbnailUrl: String?)

    @Query("SELECT EXISTS(SELECT 1 FROM manga WHERE source = :source AND url = :url AND favorite = 1)")
    suspend fun isMangaFavorite(source: String, url: String): Boolean

    @Query("SELECT * FROM manga WHERE favorite = 1 AND title LIKE '%' || :query || '%'")
    fun searchFavoriteManga(query: String): Flow<List<MangaEntity>>

    @Query("SELECT COUNT(*) FROM manga WHERE favorite = 1")
    fun getFavoriteMangaCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM manga WHERE favorite = 1 AND contentType = :contentType")
    fun getFavoriteCountByType(contentType: String): Flow<Int>
}
