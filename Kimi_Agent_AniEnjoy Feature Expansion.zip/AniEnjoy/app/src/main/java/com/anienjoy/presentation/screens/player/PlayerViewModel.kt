package com.anienjoy.presentation.screens.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.EpisodeEntity
import com.anienjoy.domain.repository.AnimeRepository
import com.anienjoy.domain.repository.SourceRepository
import com.anienjoy.extension.api.model.Video
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val animeRepository: AnimeRepository,
    private val sourceRepository: SourceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<PlayerUiState>(PlayerUiState.Loading)
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var currentEpisodeId: Long? = null

    fun loadEpisode(episodeId: Long) {
        currentEpisodeId = episodeId
        viewModelScope.launch {
            _uiState.value = PlayerUiState.Loading

            try {
                val episode = animeRepository.getEpisodeById(episodeId)
                if (episode != null) {
                    // Get video list from source
                    val source = sourceRepository.getAnimeSourceById(episode.animeId)
                    val videos = source?.getVideoList(
                        com.anienjoy.extension.api.model.Episode(
                            id = episode.id,
                            animeId = episode.animeId,
                            url = episode.url,
                            name = episode.name
                        )
                    ) ?: emptyList()

                    _uiState.value = PlayerUiState.Success(
                        episode = episode,
                        videos = videos,
                        videoUrl = videos.firstOrNull()?.videoUrl ?: "",
                        selectedQuality = videos.firstOrNull()?.quality ?: "Auto"
                    )
                } else {
                    _uiState.value = PlayerUiState.Error("Episode not found")
                }
            } catch (e: Exception) {
                _uiState.value = PlayerUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun selectQuality(quality: String) {
        val state = _uiState.value as? PlayerUiState.Success ?: return
        val video = state.videos.find { it.quality == quality } ?: return
        
        _uiState.value = state.copy(
            videoUrl = video.videoUrl,
            selectedQuality = quality
        )
    }

    fun updateProgress(currentPosition: Long, duration: Long) {
        viewModelScope.launch {
            currentEpisodeId?.let { episodeId ->
                animeRepository.updateEpisodeProgress(episodeId, currentPosition, duration)
                
                // Mark as seen if watched more than 80%
                if (duration > 0 && currentPosition > duration * 0.8) {
                    animeRepository.updateEpisodeSeen(episodeId, true)
                }
            }
        }
    }
}

sealed class PlayerUiState {
    object Loading : PlayerUiState()
    data class Success(
        val episode: EpisodeEntity,
        val videos: List<Video>,
        val videoUrl: String,
        val selectedQuality: String
    ) : PlayerUiState()
    data class Error(val message: String) : PlayerUiState()
}
