package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.ExtensionEntity
import com.anienjoy.data.database.entity.ExtensionRepoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExtensionDao {

    @Query("SELECT * FROM extensions ORDER BY name ASC")
    fun getAllExtensions(): Flow<List<ExtensionEntity>>

    @Query("SELECT * FROM extensions WHERE isInstalled = 1 ORDER BY name ASC")
    fun getInstalledExtensions(): Flow<List<ExtensionEntity>>

    @Query("SELECT * FROM extensions WHERE hasUpdate = 1 ORDER BY name ASC")
    fun getExtensionsWithUpdate(): Flow<List<ExtensionEntity>>

    @Query("SELECT * FROM extensions WHERE id = :id")
    suspend fun getExtensionById(id: Long): ExtensionEntity?

    @Query("SELECT * FROM extensions WHERE pkgName = :pkgName")
    suspend fun getExtensionByPkgName(pkgName: String): ExtensionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(extension: ExtensionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(extensions: List<ExtensionEntity>)

    @Update
    suspend fun update(extension: ExtensionEntity)

    @Delete
    suspend fun delete(extension: ExtensionEntity)

    @Query("UPDATE extensions SET hasUpdate = :hasUpdate WHERE id = :extensionId")
    suspend fun updateHasUpdate(extensionId: Long, hasUpdate: Boolean)

    @Query("UPDATE extensions SET isInstalled = :isInstalled WHERE id = :extensionId")
    suspend fun updateInstalled(extensionId: Long, isInstalled: Boolean)

    @Query("DELETE FROM extensions WHERE pkgName = :pkgName")
    suspend fun deleteByPkgName(pkgName: String)

    // Extension Repos
    @Query("SELECT * FROM extension_repos WHERE enabled = 1 ORDER BY name ASC")
    fun getEnabledRepos(): Flow<List<ExtensionRepoEntity>>

    @Query("SELECT * FROM extension_repos ORDER BY name ASC")
    fun getAllRepos(): Flow<List<ExtensionRepoEntity>>

    @Query("SELECT * FROM extension_repos WHERE id = :id")
    suspend fun getRepoById(id: Long): ExtensionRepoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepo(repo: ExtensionRepoEntity): Long

    @Update
    suspend fun updateRepo(repo: ExtensionRepoEntity)

    @Delete
    suspend fun deleteRepo(repo: ExtensionRepoEntity)

    @Query("UPDATE extension_repos SET enabled = :enabled WHERE id = :repoId")
    suspend fun setRepoEnabled(repoId: Long, enabled: Boolean)
}
