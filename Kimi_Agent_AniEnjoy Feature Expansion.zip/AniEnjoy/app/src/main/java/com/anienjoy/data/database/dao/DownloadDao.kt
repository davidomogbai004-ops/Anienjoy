package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.DownloadEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY dateAdded DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status = :status ORDER BY priority DESC, dateAdded ASC")
    fun getDownloadsByStatus(status: Int): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN (:statuses) ORDER BY priority DESC, dateAdded ASC")
    fun getDownloadsByStatuses(statuses: List<Int>): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE contentId = :contentId AND contentType = :contentType")
    fun getDownloadsForContent(contentId: Long, contentType: String): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status = ${DownloadEntity.STATUS_PENDING} OR status = ${DownloadEntity.STATUS_QUEUED} ORDER BY priority DESC, dateAdded ASC LIMIT 1")
    suspend fun getNextPendingDownload(): DownloadEntity?

    @Query("SELECT COUNT(*) FROM downloads WHERE status = ${DownloadEntity.STATUS_DOWNLOADING}")
    fun getActiveDownloadCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM downloads WHERE status = ${DownloadEntity.STATUS_PENDING} OR status = ${DownloadEntity.STATUS_QUEUED}")
    fun getPendingDownloadCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM downloads WHERE status = ${DownloadEntity.STATUS_COMPLETED}")
    fun getCompletedDownloadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloads(downloads: List<DownloadEntity>)

    @Update
    suspend fun updateDownload(download: DownloadEntity)

    @Query("UPDATE downloads SET status = :status WHERE id = :downloadId")
    suspend fun updateStatus(downloadId: Long, status: Int)

    @Query("UPDATE downloads SET downloadedBytes = :bytes, totalBytes = :total WHERE id = :downloadId")
    suspend fun updateProgress(downloadId: Long, bytes: Long, total: Long)

    @Query("UPDATE downloads SET localPath = :path, status = ${DownloadEntity.STATUS_COMPLETED}, dateCompleted = :timestamp WHERE id = :downloadId")
    suspend fun markAsCompleted(downloadId: Long, path: String, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE downloads SET status = ${DownloadEntity.STATUS_FAILED}, errorMessage = :error WHERE id = :downloadId")
    suspend fun markAsFailed(downloadId: Long, error: String)

    @Delete
    suspend fun deleteDownload(download: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :downloadId")
    suspend fun deleteDownloadById(downloadId: Long)

    @Query("DELETE FROM downloads WHERE status = ${DownloadEntity.STATUS_COMPLETED}")
    suspend fun deleteCompletedDownloads()

    @Query("DELETE FROM downloads")
    suspend fun deleteAllDownloads()

    @Query("SELECT EXISTS(SELECT 1 FROM downloads WHERE contentId = :contentId AND contentType = :contentType AND chapterId = :chapterId AND status IN (${DownloadEntity.STATUS_PENDING}, ${DownloadEntity.STATUS_QUEUED}, ${DownloadEntity.STATUS_DOWNLOADING}, ${DownloadEntity.STATUS_PAUSED}))")
    suspend fun isContentDownloading(contentId: Long, contentType: String, chapterId: Long?): Boolean

    @Query("SELECT EXISTS(SELECT 1 FROM downloads WHERE contentId = :contentId AND contentType = :contentType AND chapterId = :chapterId AND status = ${DownloadEntity.STATUS_COMPLETED})")
    suspend fun isContentDownloaded(contentId: Long, contentType: String, chapterId: Long?): Boolean
}
