package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "anime",
    indices = [
        Index(value = ["source", "url"], unique = true),
        Index(value = ["favorite"])
    ]
)
data class AnimeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val source: String,
    val url: String,
    val title: String,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val genre: String = "", // Comma-separated
    val status: Int = 0,
    val author: String? = null,
    val artist: String? = null,
    val favorite: Boolean = false,
    val lastUpdate: Long = 0,
    val nextUpdate: Long = 0,
    val dateAdded: Long = System.currentTimeMillis(),
    val viewers: Int = 0,
    val episodeFlags: Int = 0,
    val coverLastModified: Long = 0,
    val updateStrategy: String = "ALWAYS_UPDATE"
)
