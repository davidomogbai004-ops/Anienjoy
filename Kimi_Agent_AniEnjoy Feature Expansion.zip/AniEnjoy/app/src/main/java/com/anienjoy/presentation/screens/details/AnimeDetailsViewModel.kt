package com.anienjoy.presentation.screens.details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.EpisodeEntity
import com.anienjoy.domain.repository.AnimeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AnimeDetailsViewModel @Inject constructor(
    private val animeRepository: AnimeRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AnimeDetailsUiState>(AnimeDetailsUiState.Loading)
    val uiState: StateFlow<AnimeDetailsUiState> = _uiState.asStateFlow()

    private var currentAnimeId: Long? = null

    fun loadAnime(animeId: Long) {
        currentAnimeId = animeId
        viewModelScope.launch {
            _uiState.value = AnimeDetailsUiState.Loading

            try {
                val anime = animeRepository.getAnimeById(animeId)
                if (anime != null) {
                    animeRepository.getEpisodesByAnimeId(animeId)
                        .collect { episodes ->
                            _uiState.value = AnimeDetailsUiState.Success(
                                anime = anime,
                                episodes = episodes,
                                isFavorite = anime.favorite
                            )
                        }
                } else {
                    _uiState.value = AnimeDetailsUiState.Error("Anime not found")
                }
            } catch (e: Exception) {
                _uiState.value = AnimeDetailsUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            val state = _uiState.value as? AnimeDetailsUiState.Success ?: return@launch
            val newFavoriteState = !state.isFavorite
            animeRepository.updateFavorite(state.anime.id, newFavoriteState)
            _uiState.value = state.copy(isFavorite = newFavoriteState)
        }
    }

    fun refreshEpisodes() {
        viewModelScope.launch {
            // Implementation to refresh episodes from source
        }
    }

    fun updateEpisodeProgress(episodeId: Long, lastSecondSeen: Long, totalSeconds: Long) {
        viewModelScope.launch {
            animeRepository.updateEpisodeProgress(episodeId, lastSecondSeen, totalSeconds)
        }
    }
}

sealed class AnimeDetailsUiState {
    object Loading : AnimeDetailsUiState()
    data class Success(
        val anime: AnimeEntity,
        val episodes: List<EpisodeEntity>,
        val isFavorite: Boolean
    ) : AnimeDetailsUiState()
    data class Error(val message: String) : AnimeDetailsUiState()
}
