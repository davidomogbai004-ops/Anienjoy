package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val order: Int,
    val flags: Int = 0
)

@Entity(
    tableName = "anime_categories",
    primaryKeys = ["animeId", "categoryId"]
)
data class AnimeCategoryEntity(
    val animeId: Long,
    val categoryId: Int
)

@Entity(
    tableName = "manga_categories",
    primaryKeys = ["mangaId", "categoryId"]
)
data class MangaCategoryEntity(
    val mangaId: Long,
    val categoryId: Int
)

@Entity(
    tableName = "novel_categories",
    primaryKeys = ["novelId", "categoryId"]
)
data class NovelCategoryEntity(
    val novelId: Long,
    val categoryId: Int
)
