package com.anienjoy.data.backup

import android.content.Context
import android.net.Uri
import com.anienjoy.data.database.AppDatabase
import com.anienjoy.data.preferences.SettingsPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BackupManager @Inject constructor(
    private val context: Context,
    private val database: AppDatabase,
    private val settingsPreferences: SettingsPreferences
) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    suspend fun createBackup(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val backup = BackupData(
                version = BACKUP_VERSION,
                timestamp = System.currentTimeMillis(),
                anime = database.animeDao().getFavoriteAnime().first(),
                manga = database.mangaDao().getFavoriteManga().first(),
                novels = database.novelDao().getFavoriteNovels().first(),
                episodes = getAllEpisodes(),
                chapters = getAllChapters(),
                novelChapters = getAllNovelChapters(),
                categories = database.categoryDao().getAllCategoriesSync(),
                animeCategories = getAllAnimeCategories(),
                mangaCategories = getAllMangaCategories(),
                novelCategories = getAllNovelCategories(),
                settings = getSettings(),
                extensionRepos = database.extensionDao().getAllRepos().first()
            )

            // Write to zip file
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                ZipOutputStream(BufferedOutputStream(outputStream)).use { zipOut ->
                    // Add backup.json
                    zipOut.putNextEntry(ZipEntry("backup.json"))
                    zipOut.write(json.encodeToString(backup).toByteArray())
                    zipOut.closeEntry()

                    // Add database file
                    val dbFile = context.getDatabasePath("anienjoy.db")
                    if (dbFile.exists()) {
                        zipOut.putNextEntry(ZipEntry("anienjoy.db"))
                        dbFile.inputStream().use { it.copyTo(zipOut) }
                        zipOut.closeEntry()
                    }
                }
            }

            Result.success("Backup created successfully")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreBackup(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                ZipInputStream(BufferedInputStream(inputStream)).use { zipIn ->
                    var entry: ZipEntry?
                    var backupData: BackupData? = null

                    while (zipIn.nextEntry.also { entry = it } != null) {
                        when (entry?.name) {
                            "backup.json" -> {
                                val content = zipIn.readBytes().toString(Charsets.UTF_8)
                                backupData = json.decodeFromString(content)
                            }
                            "anienjoy.db" -> {
                                // Restore database file
                                val dbFile = context.getDatabasePath("anienjoy.db")
                                dbFile.parentFile?.mkdirs()
                                dbFile.outputStream().use { output ->
                                    zipIn.copyTo(output)
                                }
                            }
                        }
                        zipIn.closeEntry()
                    }

                    // Restore settings from backup data
                    backupData?.let { restoreSettings(it.settings) }
                }
            }

            Result.success("Backup restored successfully")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun getAllEpisodes(): List<EpisodeBackup> {
        val animeList = database.animeDao().getFavoriteAnime().first()
        return animeList.flatMap { anime ->
            database.episodeDao().getEpisodesByAnimeIdSync(anime.id)
                .map { episode ->
                    EpisodeBackup(
                        animeUrl = anime.url,
                        animeSource = anime.source,
                        url = episode.url,
                        name = episode.name,
                        scanlator = episode.scanlator,
                        seen = episode.seen,
                        bookmark = episode.bookmark,
                        episodeNumber = episode.episodeNumber,
                        lastSecondSeen = episode.lastSecondSeen,
                        totalSeconds = episode.totalSeconds
                    )
                }
        }
    }

    private suspend fun getAllChapters(): List<ChapterBackup> {
        val mangaList = database.mangaDao().getFavoriteManga().first()
        return mangaList.flatMap { manga ->
            database.chapterDao().getChaptersByMangaIdSync(manga.id)
                .map { chapter ->
                    ChapterBackup(
                        mangaUrl = manga.url,
                        mangaSource = manga.source,
                        url = chapter.url,
                        name = chapter.name,
                        scanlator = chapter.scanlator,
                        read = chapter.read,
                        bookmark = chapter.bookmark,
                        chapterNumber = chapter.chapterNumber,
                        lastPageRead = chapter.lastPageRead
                    )
                }
        }
    }

    private suspend fun getAllNovelChapters(): List<NovelChapterBackup> {
        val novelList = database.novelDao().getFavoriteNovels().first()
        return novelList.flatMap { novel ->
            database.novelChapterDao().getChaptersByNovelIdSync(novel.id)
                .map { chapter ->
                    NovelChapterBackup(
                        novelUrl = novel.url,
                        novelSource = novel.source,
                        url = chapter.url,
                        name = chapter.name,
                        scanlator = chapter.scanlator,
                        read = chapter.read,
                        bookmark = chapter.bookmark,
                        chapterNumber = chapter.chapterNumber,
                        lastReadPosition = chapter.lastReadPosition
                    )
                }
        }
    }

    private suspend fun getAllAnimeCategories(): List<AnimeCategoryBackup> {
        val animeList = database.animeDao().getFavoriteAnime().first()
        return animeList.flatMap { anime ->
            database.categoryDao().getAnimeCategoryIds(anime.id)
                .map { categoryId ->
                    AnimeCategoryBackup(
                        animeUrl = anime.url,
                        animeSource = anime.source,
                        categoryId = categoryId
                    )
                }
        }
    }

    private suspend fun getAllMangaCategories(): List<MangaCategoryBackup> {
        val mangaList = database.mangaDao().getFavoriteManga().first()
        return mangaList.flatMap { manga ->
            database.categoryDao().getMangaCategoryIds(manga.id)
                .map { categoryId ->
                    MangaCategoryBackup(
                        mangaUrl = manga.url,
                        mangaSource = manga.source,
                        categoryId = categoryId
                    )
                }
        }
    }

    private suspend fun getAllNovelCategories(): List<NovelCategoryBackup> {
        val novelList = database.novelDao().getFavoriteNovels().first()
        return novelList.flatMap { novel ->
            database.categoryDao().getNovelCategoryIds(novel.id)
                .map { categoryId ->
                    NovelCategoryBackup(
                        novelUrl = novel.url,
                        novelSource = novel.source,
                        categoryId = categoryId
                    )
                }
        }
    }

    private suspend fun getSettings(): SettingsBackup {
        return SettingsBackup(
            themeMode = settingsPreferences.themeMode.first().name,
            enabledLanguages = settingsPreferences.enabledLanguages.first().toList(),
            libraryColumnsPortrait = settingsPreferences.libraryColumnsPortrait.first(),
            libraryColumnsLandscape = settingsPreferences.libraryColumnsLandscape.first(),
            doubleTapSeekDuration = settingsPreferences.doubleTapSeekDuration.first(),
            defaultReadingMode = settingsPreferences.defaultReadingMode.first(),
            downloadOnlyOverWifi = settingsPreferences.downloadOnlyOverWifi.first(),
            showNsfw = settingsPreferences.showNsfw.first()
        )
    }

    private suspend fun restoreSettings(settings: SettingsBackup) {
        settingsPreferences.setThemeMode(
            com.anienjoy.data.preferences.ThemeMode.valueOf(settings.themeMode)
        )
        settingsPreferences.setEnabledLanguages(settings.enabledLanguages.toSet())
        settingsPreferences.setLibraryColumnsPortrait(settings.libraryColumnsPortrait)
        settingsPreferences.setLibraryColumnsLandscape(settings.libraryColumnsLandscape)
        settingsPreferences.setDoubleTapSeekDuration(settings.doubleTapSeekDuration)
        settingsPreferences.setDefaultReadingMode(settings.defaultReadingMode)
        settingsPreferences.setDownloadOnlyOverWifi(settings.downloadOnlyOverWifi)
        settingsPreferences.setShowNsfw(settings.showNsfw)
    }

    companion object {
        const val BACKUP_VERSION = 1
        const val BACKUP_MIME_TYPE = "application/zip"
        const val BACKUP_FILE_EXTENSION = "anienjoy"
    }
}

@Serializable
data class BackupData(
    val version: Int,
    val timestamp: Long,
    val anime: List<com.anienjoy.data.database.entity.AnimeEntity>,
    val manga: List<com.anienjoy.data.database.entity.MangaEntity>,
    val novels: List<com.anienjoy.data.database.entity.NovelEntity>,
    val episodes: List<EpisodeBackup>,
    val chapters: List<ChapterBackup>,
    val novelChapters: List<NovelChapterBackup>,
    val categories: List<com.anienjoy.data.database.entity.CategoryEntity>,
    val animeCategories: List<AnimeCategoryBackup>,
    val mangaCategories: List<MangaCategoryBackup>,
    val novelCategories: List<NovelCategoryBackup>,
    val settings: SettingsBackup,
    val extensionRepos: List<com.anienjoy.data.database.entity.ExtensionRepoEntity>
)

@Serializable
data class EpisodeBackup(
    val animeUrl: String,
    val animeSource: String,
    val url: String,
    val name: String,
    val scanlator: String?,
    val seen: Boolean,
    val bookmark: Boolean,
    val episodeNumber: Float,
    val lastSecondSeen: Long,
    val totalSeconds: Long
)

@Serializable
data class ChapterBackup(
    val mangaUrl: String,
    val mangaSource: String,
    val url: String,
    val name: String,
    val scanlator: String?,
    val read: Boolean,
    val bookmark: Boolean,
    val chapterNumber: Float,
    val lastPageRead: Int
)

@Serializable
data class NovelChapterBackup(
    val novelUrl: String,
    val novelSource: String,
    val url: String,
    val name: String,
    val scanlator: String?,
    val read: Boolean,
    val bookmark: Boolean,
    val chapterNumber: Float,
    val lastReadPosition: Int
)

@Serializable
data class AnimeCategoryBackup(
    val animeUrl: String,
    val animeSource: String,
    val categoryId: Int
)

@Serializable
data class MangaCategoryBackup(
    val mangaUrl: String,
    val mangaSource: String,
    val categoryId: Int
)

@Serializable
data class NovelCategoryBackup(
    val novelUrl: String,
    val novelSource: String,
    val categoryId: Int
)

@Serializable
data class SettingsBackup(
    val themeMode: String,
    val enabledLanguages: List<String>,
    val libraryColumnsPortrait: Int,
    val libraryColumnsLandscape: Int,
    val doubleTapSeekDuration: Int,
    val defaultReadingMode: Int,
    val downloadOnlyOverWifi: Boolean,
    val showNsfw: Boolean
)
