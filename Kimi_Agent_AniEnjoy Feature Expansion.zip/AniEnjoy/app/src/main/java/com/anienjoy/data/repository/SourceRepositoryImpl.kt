package com.anienjoy.data.repository

import android.app.Application
import com.anienjoy.domain.repository.ExtensionRepository
import com.anienjoy.domain.repository.SourceRepository
import com.anienjoy.extension.api.*
import com.anienjoy.extension.api.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SourceRepositoryImpl @Inject constructor(
    private val app: Application,
    private val extensionRepository: ExtensionRepository
) : SourceRepository {

    private val _animeSources = MutableStateFlow<List<AnimeSource>>(emptyList())
    override val animeSources: StateFlow<List<AnimeSource>> = _animeSources.asStateFlow()

    private val _mangaSources = MutableStateFlow<List<MangaSource>>(emptyList())
    override val mangaSources: StateFlow<List<MangaSource>> = _mangaSources.asStateFlow()

    private val _manhwaSources = MutableStateFlow<List<MangaSource>>(emptyList())
    override val manhwaSources: StateFlow<List<MangaSource>> = _manhwaSources.asStateFlow()

    private val _manhuaSources = MutableStateFlow<List<MangaSource>>(emptyList())
    override val manhuaSources: StateFlow<List<MangaSource>> = _manhuaSources.asStateFlow()

    private val _novelSources = MutableStateFlow<List<NovelSource>>(emptyList())
    override val novelSources: StateFlow<List<NovelSource>> = _novelSources.asStateFlow()

    init {
        loadSources()
    }

    override fun loadSources() {
        val results = extensionRepository.loadInstalledExtensions()
        
        val animeList = mutableListOf<AnimeSource>()
        val mangaList = mutableListOf<MangaSource>()
        val manhwaList = mutableListOf<MangaSource>()
        val manhuaList = mutableListOf<MangaSource>()
        val novelList = mutableListOf<NovelSource>()

        results.forEach { result ->
            if (result is ExtensionLoader.LoadResult.Success) {
                result.sources.forEach { source ->
                    when (source) {
                        is AnimeSource -> animeList.add(source)
                        is MangaSource -> {
                            // Determine if it's manga, manhwa, or manhua based on language or source properties
                            when {
                                source.lang == "ko" || source.name.contains("Manhwa", true) -> 
                                    manhwaList.add(source)
                                source.lang == "zh" || source.name.contains("Manhua", true) -> 
                                    manhuaList.add(source)
                                else -> mangaList.add(source)
                            }
                        }
                        is NovelSource -> novelList.add(source)
                    }
                }
            }
        }

        _animeSources.value = animeList
        _mangaSources.value = mangaList
        _manhwaSources.value = manhwaList
        _manhuaSources.value = manhuaList
        _novelSources.value = novelList
    }

    override fun getAnimeSourceById(id: Long): AnimeSource? {
        return _animeSources.value.find { it.id == id }
    }

    override fun getMangaSourceById(id: Long): MangaSource? {
        return _mangaSources.value.find { it.id == id }
    }

    override fun getManhwaSourceById(id: Long): MangaSource? {
        return _manhwaSources.value.find { it.id == id }
    }

    override fun getManhuaSourceById(id: Long): MangaSource? {
        return _manhuaSources.value.find { it.id == id }
    }

    override fun getNovelSourceById(id: Long): NovelSource? {
        return _novelSources.value.find { it.id == id }
    }

    override fun getSourcesByLanguage(language: String): List<Source> {
        val allSources = mutableListOf<Source>()
        allSources.addAll(_animeSources.value.filter { it.lang == language })
        allSources.addAll(_mangaSources.value.filter { it.lang == language })
        allSources.addAll(_manhwaSources.value.filter { it.lang == language })
        allSources.addAll(_manhuaSources.value.filter { it.lang == language })
        allSources.addAll(_novelSources.value.filter { it.lang == language })
        return allSources
    }

    override fun getAllSources(): List<Source> {
        val allSources = mutableListOf<Source>()
        allSources.addAll(_animeSources.value)
        allSources.addAll(_mangaSources.value)
        allSources.addAll(_manhwaSources.value)
        allSources.addAll(_manhuaSources.value)
        allSources.addAll(_novelSources.value)
        return allSources
    }

    override suspend fun getPopularAnime(sourceId: Long, page: Int): AnimePage {
        return withContext(Dispatchers.IO) {
            val source = getAnimeSourceById(sourceId)
                ?: throw IllegalArgumentException("Anime source not found: $sourceId")
            source.getPopularAnime(page)
        }
    }

    override suspend fun getLatestAnime(sourceId: Long, page: Int): AnimePage {
        return withContext(Dispatchers.IO) {
            val source = getAnimeSourceById(sourceId)
                ?: throw IllegalArgumentException("Anime source not found: $sourceId")
            source.getLatestUpdates(page)
        }
    }

    override suspend fun searchAnime(
        sourceId: Long,
        query: String,
        page: Int,
        filters: FilterList
    ): AnimePage {
        return withContext(Dispatchers.IO) {
            val source = getAnimeSourceById(sourceId)
                ?: throw IllegalArgumentException("Anime source not found: $sourceId")
            source.searchAnime(query, page, filters)
        }
    }

    override suspend fun getAnimeDetails(sourceId: Long, anime: com.anienjoy.extension.api.model.Anime): com.anienjoy.extension.api.model.Anime {
        return withContext(Dispatchers.IO) {
            val source = getAnimeSourceById(sourceId)
                ?: throw IllegalArgumentException("Anime source not found: $sourceId")
            source.getAnimeDetails(anime)
        }
    }

    override suspend fun getEpisodeList(sourceId: Long, anime: com.anienjoy.extension.api.model.Anime): List<Episode> {
        return withContext(Dispatchers.IO) {
            val source = getAnimeSourceById(sourceId)
                ?: throw IllegalArgumentException("Anime source not found: $sourceId")
            source.getEpisodeList(anime)
        }
    }

    override suspend fun getVideoList(sourceId: Long, episode: Episode): List<Video> {
        return withContext(Dispatchers.IO) {
            val source = getAnimeSourceById(sourceId)
                ?: throw IllegalArgumentException("Anime source not found: $sourceId")
            source.getVideoList(episode)
        }
    }

    override suspend fun getPopularManga(sourceId: Long, page: Int): MangaPage {
        return withContext(Dispatchers.IO) {
            val source = getMangaSourceById(sourceId)
                ?: throw IllegalArgumentException("Manga source not found: $sourceId")
            source.getPopularManga(page)
        }
    }

    override suspend fun getLatestManga(sourceId: Long, page: Int): MangaPage {
        return withContext(Dispatchers.IO) {
            val source = getMangaSourceById(sourceId)
                ?: throw IllegalArgumentException("Manga source not found: $sourceId")
            source.getLatestUpdates(page)
        }
    }

    override suspend fun searchManga(
        sourceId: Long,
        query: String,
        page: Int,
        filters: FilterList
    ): MangaPage {
        return withContext(Dispatchers.IO) {
            val source = getMangaSourceById(sourceId)
                ?: throw IllegalArgumentException("Manga source not found: $sourceId")
            source.searchManga(query, page, filters)
        }
    }

    override suspend fun getMangaDetails(sourceId: Long, manga: com.anienjoy.extension.api.model.Manga): com.anienjoy.extension.api.model.Manga {
        return withContext(Dispatchers.IO) {
            val source = getMangaSourceById(sourceId)
                ?: throw IllegalArgumentException("Manga source not found: $sourceId")
            source.getMangaDetails(manga)
        }
    }

    override suspend fun getChapterList(sourceId: Long, manga: com.anienjoy.extension.api.model.Manga): List<Chapter> {
        return withContext(Dispatchers.IO) {
            val source = getMangaSourceById(sourceId)
                ?: throw IllegalArgumentException("Manga source not found: $sourceId")
            source.getChapterList(manga)
        }
    }

    override suspend fun getPageList(sourceId: Long, chapter: Chapter): List<Page> {
        return withContext(Dispatchers.IO) {
            val source = getMangaSourceById(sourceId)
                ?: throw IllegalArgumentException("Manga source not found: $sourceId")
            source.getPageList(chapter)
        }
    }

    override suspend fun getPopularNovels(sourceId: Long, page: Int): NovelPage {
        return withContext(Dispatchers.IO) {
            val source = getNovelSourceById(sourceId)
                ?: throw IllegalArgumentException("Novel source not found: $sourceId")
            source.getPopularNovels(page)
        }
    }

    override suspend fun getLatestNovels(sourceId: Long, page: Int): NovelPage {
        return withContext(Dispatchers.IO) {
            val source = getNovelSourceById(sourceId)
                ?: throw IllegalArgumentException("Novel source not found: $sourceId")
            source.getLatestUpdates(page)
        }
    }

    override suspend fun searchNovels(
        sourceId: Long,
        query: String,
        page: Int,
        filters: FilterList
    ): NovelPage {
        return withContext(Dispatchers.IO) {
            val source = getNovelSourceById(sourceId)
                ?: throw IllegalArgumentException("Novel source not found: $sourceId")
            source.searchNovels(query, page, filters)
        }
    }

    override suspend fun getNovelDetails(sourceId: Long, novel: com.anienjoy.extension.api.model.Novel): com.anienjoy.extension.api.model.Novel {
        return withContext(Dispatchers.IO) {
            val source = getNovelSourceById(sourceId)
                ?: throw IllegalArgumentException("Novel source not found: $sourceId")
            source.getNovelDetails(novel)
        }
    }

    override suspend fun getNovelChapterList(sourceId: Long, novel: com.anienjoy.extension.api.model.Novel): List<NovelChapter> {
        return withContext(Dispatchers.IO) {
            val source = getNovelSourceById(sourceId)
                ?: throw IllegalArgumentException("Novel source not found: $sourceId")
            source.getChapterList(novel)
        }
    }

    override suspend fun getNovelChapterContent(sourceId: Long, chapter: NovelChapter): String {
        return withContext(Dispatchers.IO) {
            val source = getNovelSourceById(sourceId)
                ?: throw IllegalArgumentException("Novel source not found: $sourceId")
            source.getChapterContent(chapter)
        }
    }
}
