package com.anienjoy.presentation.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.UpdateEntity
import com.anienjoy.data.worker.UpdateCheckerWorker
import com.anienjoy.domain.repository.UpdateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UpdatesViewModel @Inject constructor(
    application: Application,
    private val updateRepository: UpdateRepository
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(UpdatesUiState())
    val uiState: StateFlow<UpdatesUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                updateRepository.getAllUpdates(),
                updateRepository.getUnreadUpdateCount()
            ) { updates, unreadCount ->
                UpdatesUiState(
                    updates = updates,
                    unreadCount = unreadCount
                )
            }.collect { state ->
                _uiState.value = state
            }
        }

        // Schedule periodic update checks
        UpdateCheckerWorker.schedule(application)
    }

    fun checkForUpdates() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            UpdateCheckerWorker.runImmediate(getApplication())
            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    fun markAsRead(updateId: Long) {
        viewModelScope.launch {
            updateRepository.markAsRead(updateId)
        }
    }

    fun markAllAsRead() {
        viewModelScope.launch {
            updateRepository.markAllAsRead()
        }
    }

    fun deleteOldUpdates(daysToKeep: Int = 30) {
        viewModelScope.launch {
            val cutoffTime = System.currentTimeMillis() - (daysToKeep * 24 * 60 * 60 * 1000)
            updateRepository.deleteOldUpdates(cutoffTime)
        }
    }

    fun clearAllUpdates() {
        viewModelScope.launch {
            updateRepository.deleteAllUpdates()
        }
    }
}

data class UpdatesUiState(
    val updates: List<UpdateEntity> = emptyList(),
    val unreadCount: Int = 0,
    val isLoading: Boolean = false
)
