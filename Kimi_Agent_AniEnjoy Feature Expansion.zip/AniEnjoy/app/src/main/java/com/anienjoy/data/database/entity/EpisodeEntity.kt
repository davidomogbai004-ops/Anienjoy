package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "episodes",
    foreignKeys = [
        ForeignKey(
            entity = AnimeEntity::class,
            parentColumns = ["id"],
            childColumns = ["animeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["animeId", "url"], unique = true),
        Index(value = ["animeId"])
    ]
)
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val animeId: Long,
    val url: String,
    val name: String,
    val scanlator: String? = null,
    val seen: Boolean = false,
    val bookmark: Boolean = false,
    val episodeNumber: Float = -1f,
    val sourceOrder: Int = -1,
    val dateUpload: Long = 0,
    val dateFetch: Long = 0,
    val lastSecondSeen: Long = 0,
    val totalSeconds: Long = 0
)
