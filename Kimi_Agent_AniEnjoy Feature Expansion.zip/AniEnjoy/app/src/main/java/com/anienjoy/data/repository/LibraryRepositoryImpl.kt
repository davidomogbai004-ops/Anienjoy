package com.anienjoy.data.repository

import com.anienjoy.data.database.dao.*
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import com.anienjoy.data.database.entity.NovelEntity
import com.anienjoy.domain.repository.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LibraryRepositoryImpl @Inject constructor(
    private val animeDao: AnimeDao,
    private val mangaDao: MangaDao,
    private val novelDao: NovelDao,
    private val categoryDao: CategoryDao
) : LibraryRepository {

    override fun getAllLibraryItems(): Flow<LibraryItems> {
        return combine(
            animeDao.getFavoriteAnime(),
            mangaDao.getFavoriteManga(),
            mangaDao.getFavoriteByContentType("MANHWA"),
            mangaDao.getFavoriteByContentType("MANHUA"),
            novelDao.getFavoriteNovels()
        ) { anime, manga, manhwa, manhua, novels ->
            LibraryItems(
                anime = anime,
                manga = manga.filter { it.contentType == "MANGA" },
                manhwa = manhwa,
                manhua = manhua,
                novels = novels
            )
        }
    }

    override fun getLibraryCount(): Flow<LibraryCounts> {
        return combine(
            animeDao.getFavoriteAnimeCount(),
            mangaDao.getFavoriteCountByType("MANGA"),
            mangaDao.getFavoriteCountByType("MANHWA"),
            mangaDao.getFavoriteCountByType("MANHUA"),
            novelDao.getFavoriteNovelsCount()
        ) { anime, manga, manhwa, manhua, novels ->
            LibraryCounts(
                animeCount = anime,
                mangaCount = manga,
                manhwaCount = manhwa,
                manhuaCount = manhua,
                novelCount = novels,
                totalCount = anime + manga + manhwa + manhua + novels
            )
        }
    }

    override fun getAnimeLibrary(): Flow<List<AnimeEntity>> {
        return animeDao.getFavoriteAnime()
    }

    override suspend fun addAnimeToLibrary(anime: AnimeEntity): Long {
        return animeDao.insert(anime.copy(favorite = true))
    }

    override suspend fun removeAnimeFromLibrary(animeId: Long) {
        animeDao.updateFavorite(animeId, false)
    }

    override fun getMangaLibrary(): Flow<List<MangaEntity>> {
        return mangaDao.getFavoriteByContentType("MANGA")
    }

    override suspend fun addMangaToLibrary(manga: MangaEntity): Long {
        return mangaDao.insert(manga.copy(favorite = true))
    }

    override suspend fun removeMangaFromLibrary(mangaId: Long) {
        mangaDao.updateFavorite(mangaId, false)
    }

    override fun getManhwaLibrary(): Flow<List<MangaEntity>> {
        return mangaDao.getFavoriteByContentType("MANHWA")
    }

    override fun getManhuaLibrary(): Flow<List<MangaEntity>> {
        return mangaDao.getFavoriteByContentType("MANHUA")
    }

    override fun getNovelLibrary(): Flow<List<NovelEntity>> {
        return novelDao.getFavoriteNovels()
    }

    override suspend fun addNovelToLibrary(novel: NovelEntity): Long {
        return novelDao.insert(novel.copy(favorite = true))
    }

    override suspend fun removeNovelFromLibrary(novelId: Long) {
        novelDao.updateFavorite(novelId, false)
    }

    override fun searchLibrary(query: String): Flow<LibraryItems> {
        return combine(
            animeDao.searchFavoriteAnime(query),
            mangaDao.searchFavoriteManga(query),
            novelDao.searchFavoriteNovels(query)
        ) { anime, manga, novels ->
            LibraryItems(
                anime = anime,
                manga = manga.filter { it.contentType == "MANGA" },
                manhwa = manga.filter { it.contentType == "MANHWA" },
                manhua = manga.filter { it.contentType == "MANHUA" },
                novels = novels
            )
        }
    }

    override suspend fun checkForUpdates() {
        // Implementation for checking updates across all library items
        // This would fetch updates from sources for each item
    }

    override suspend fun updateLibraryItem(item: Any) {
        when (item) {
            is AnimeEntity -> animeDao.update(item)
            is MangaEntity -> mangaDao.update(item)
            is NovelEntity -> novelDao.update(item)
        }
    }
}
