package com.anienjoy.presentation.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.domain.repository.ExtensionRepository
import com.anienjoy.domain.repository.SourceRepository
import com.anienjoy.extension.api.ExtensionInfo
import com.anienjoy.extension.api.Source
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BrowseViewModel @Inject constructor(
    private val sourceRepository: SourceRepository,
    private val extensionRepository: ExtensionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(BrowseUiState())
    val uiState: StateFlow<BrowseUiState> = _uiState.asStateFlow()

    private val _selectedContentType = MutableStateFlow(ContentTypeFilter.ALL)

    init {
        viewModelScope.launch {
            combine(
                sourceRepository.animeSources,
                sourceRepository.mangaSources,
                sourceRepository.manhwaSources,
                sourceRepository.manhuaSources,
                sourceRepository.novelSources,
                _selectedContentType
            ) { anime, manga, manhwa, manhua, novels, filter ->
                val filteredSources = when (filter) {
                    ContentTypeFilter.ALL -> anime + manga + manhwa + manhua + novels
                    ContentTypeFilter.ANIME -> anime
                    ContentTypeFilter.MANGA -> manga
                    ContentTypeFilter.MANHWA -> manhwa
                    ContentTypeFilter.MANHUA -> manhua
                    ContentTypeFilter.NOVEL -> novels
                }
                filteredSources
            }.collect { sources ->
                _uiState.update { it.copy(sources = sources) }
            }
        }

        viewModelScope.launch {
            // Load extensions from repos
            val repos = extensionRepository.getEnabledRepos().first()
            val allExtensions = mutableListOf<ExtensionInfo>()
            
            repos.forEach { repo ->
                val extensions = extensionRepository.fetchExtensionsFromRepo(repo.url)
                allExtensions.addAll(extensions)
            }
            
            _uiState.update { it.copy(extensions = allExtensions) }
        }
    }

    fun setContentType(type: ContentTypeFilter) {
        _selectedContentType.value = type
        _uiState.update { it.copy(selectedContentType = type) }
    }

    fun installExtension(extension: ExtensionInfo) {
        viewModelScope.launch {
            extensionRepository.installExtension(extension)
        }
    }

    fun uninstallExtension(extension: ExtensionInfo) {
        viewModelScope.launch {
            extensionRepository.uninstallExtension(extension.pkgName)
        }
    }

    fun refreshExtensions() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            
            val repos = extensionRepository.getEnabledRepos().first()
            val allExtensions = mutableListOf<ExtensionInfo>()
            
            repos.forEach { repo ->
                val extensions = extensionRepository.fetchExtensionsFromRepo(repo.url)
                allExtensions.addAll(extensions)
            }
            
            _uiState.update { 
                it.copy(
                    extensions = allExtensions,
                    isLoading = false
                )
            }
        }
    }
}

data class BrowseUiState(
    val sources: List<Source> = emptyList(),
    val extensions: List<ExtensionInfo> = emptyList(),
    val selectedContentType: ContentTypeFilter = ContentTypeFilter.ALL,
    val isLoading: Boolean = false
)
