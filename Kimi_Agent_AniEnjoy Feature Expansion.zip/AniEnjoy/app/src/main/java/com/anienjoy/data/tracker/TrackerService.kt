package com.anienjoy.data.tracker

import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity

interface TrackerService {
    val name: String
    val iconUrl: String
    
    suspend fun login(username: String, password: String? = null, authCode: String? = null): Result<String>
    suspend fun logout()
    suspend fun isLoggedIn(): Boolean
    
    // Search for anime/manga on tracker
    suspend fun searchAnime(query: String): List<TrackerSearchResult>
    suspend fun searchManga(query: String): List<TrackerSearchResult>
    
    // Get user's list
    suspend fun getAnimeList(): List<TrackerAnimeEntry>
    suspend fun getMangaList(): List<TrackerMangaEntry>
    
    // Add/update entries
    suspend fun addAnime(entry: TrackerAnimeEntry): Result<Unit>
    suspend fun updateAnime(entry: TrackerAnimeEntry): Result<Unit>
    suspend fun addManga(entry: TrackerMangaEntry): Result<Unit>
    suspend fun updateManga(entry: TrackerMangaEntry): Result<Unit>
    
    // Delete entries
    suspend fun deleteAnime(id: String): Result<Unit>
    suspend fun deleteManga(id: String): Result<Unit>
    
    // Sync with local library
    suspend fun syncAnime(anime: AnimeEntity, episodesWatched: Int, status: TrackerStatus)
    suspend fun syncManga(manga: MangaEntity, chaptersRead: Int, status: TrackerStatus)
}

data class TrackerSearchResult(
    val id: String,
    val title: String,
    val coverImage: String?,
    val description: String?,
    val type: String, // ANIME or MANGA
    val totalEpisodes: Int?,
    val totalChapters: Int?,
    val startDate: String?,
    val status: String?
)

data class TrackerAnimeEntry(
    val id: String? = null,
    val mediaId: String,
    val title: String,
    val coverImage: String? = null,
    val status: TrackerStatus = TrackerStatus.CURRENT,
    val score: Float = 0f,
    val episodesWatched: Int = 0,
    val totalEpisodes: Int? = null,
    val startDate: String? = null,
    val finishDate: String? = null,
    val rewatchCount: Int = 0,
    val notes: String? = null
)

data class TrackerMangaEntry(
    val id: String? = null,
    val mediaId: String,
    val title: String,
    val coverImage: String? = null,
    val status: TrackerStatus = TrackerStatus.CURRENT,
    val score: Float = 0f,
    val chaptersRead: Int = 0,
    val totalChapters: Int? = null,
    val volumesRead: Int = 0,
    val totalVolumes: Int? = null,
    val startDate: String? = null,
    val finishDate: String? = null,
    val rereadCount: Int = 0,
    val notes: String? = null
)

enum class TrackerStatus(val value: String) {
    CURRENT("current"),
    PLANNING("planning"),
    COMPLETED("completed"),
    DROPPED("dropped"),
    PAUSED("paused"),
    REPEATING("repeating");
    
    companion object {
        fun fromValue(value: String): TrackerStatus {
            return values().find { it.value == value } ?: CURRENT
        }
    }
}
