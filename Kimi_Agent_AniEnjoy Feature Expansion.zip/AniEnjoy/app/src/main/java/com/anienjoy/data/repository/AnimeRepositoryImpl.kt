package com.anienjoy.data.repository

import androidx.paging.PagingSource
import com.anienjoy.data.database.dao.AnimeDao
import com.anienjoy.data.database.dao.EpisodeDao
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.EpisodeEntity
import com.anienjoy.domain.repository.AnimeRepository
import com.anienjoy.extension.api.network.NetworkHelper
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AnimeRepositoryImpl @Inject constructor(
    private val animeDao: AnimeDao,
    private val episodeDao: EpisodeDao,
    private val networkHelper: NetworkHelper
) : AnimeRepository {

    override fun getFavoriteAnime(): Flow<List<AnimeEntity>> {
        return animeDao.getFavoriteAnime()
    }

    override fun getFavoriteAnimePaging(): PagingSource<Int, AnimeEntity> {
        return animeDao.getFavoriteAnimePaging()
    }

    override suspend fun getAnimeById(id: Long): AnimeEntity? {
        return animeDao.getAnimeById(id)
    }

    override suspend fun getAnimeBySourceAndUrl(source: String, url: String): AnimeEntity? {
        return animeDao.getAnimeBySourceAndUrl(source, url)
    }

    override suspend fun insertAnime(anime: AnimeEntity): Long {
        return animeDao.insert(anime)
    }

    override suspend fun updateAnime(anime: AnimeEntity) {
        animeDao.update(anime)
    }

    override suspend fun deleteAnime(anime: AnimeEntity) {
        animeDao.delete(anime)
    }

    override suspend fun updateFavorite(animeId: Long, favorite: Boolean) {
        animeDao.updateFavorite(animeId, favorite)
    }

    override suspend fun updateThumbnail(animeId: Long, thumbnailUrl: String?) {
        animeDao.updateThumbnail(animeId, thumbnailUrl)
    }

    override suspend fun isAnimeFavorite(source: String, url: String): Boolean {
        return animeDao.isAnimeFavorite(source, url)
    }

    override fun searchFavoriteAnime(query: String): Flow<List<AnimeEntity>> {
        return animeDao.searchFavoriteAnime(query)
    }

    override fun getFavoriteAnimeCount(): Flow<Int> {
        return animeDao.getFavoriteAnimeCount()
    }

    // Episode operations
    override fun getEpisodesByAnimeId(animeId: Long): Flow<List<EpisodeEntity>> {
        return episodeDao.getEpisodesByAnimeId(animeId)
    }

    override suspend fun getEpisodesByAnimeIdSync(animeId: Long): List<EpisodeEntity> {
        return episodeDao.getEpisodesByAnimeIdSync(animeId)
    }

    override suspend fun getEpisodeById(id: Long): EpisodeEntity? {
        return episodeDao.getEpisodeById(id)
    }

    override suspend fun insertEpisode(episode: EpisodeEntity): Long {
        return episodeDao.insert(episode)
    }

    override suspend fun insertEpisodes(episodes: List<EpisodeEntity>) {
        episodeDao.insertAll(episodes)
    }

    override suspend fun updateEpisode(episode: EpisodeEntity) {
        episodeDao.update(episode)
    }

    override suspend fun deleteEpisode(episode: EpisodeEntity) {
        episodeDao.delete(episode)
    }

    override suspend fun updateEpisodeSeen(episodeId: Long, seen: Boolean) {
        episodeDao.updateSeen(episodeId, seen)
    }

    override suspend fun updateEpisodeBookmark(episodeId: Long, bookmark: Boolean) {
        episodeDao.updateBookmark(episodeId, bookmark)
    }

    override suspend fun updateEpisodeProgress(episodeId: Long, lastSecondSeen: Long, totalSeconds: Long) {
        episodeDao.updateProgress(episodeId, lastSecondSeen, totalSeconds)
    }

    override fun getSeenEpisodeCount(animeId: Long): Flow<Int> {
        return episodeDao.getSeenEpisodeCount(animeId)
    }

    override fun getTotalEpisodeCount(animeId: Long): Flow<Int> {
        return episodeDao.getTotalEpisodeCount(animeId)
    }

    override suspend fun getNextUnseenEpisode(animeId: Long): EpisodeEntity? {
        return episodeDao.getNextUnseenEpisode(animeId)
    }

    override suspend fun deleteAllEpisodesByAnimeId(animeId: Long) {
        episodeDao.deleteAllByAnimeId(animeId)
    }
}
