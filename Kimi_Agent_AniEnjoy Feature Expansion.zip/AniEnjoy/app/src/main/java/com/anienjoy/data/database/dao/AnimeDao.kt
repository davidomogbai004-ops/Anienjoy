package com.anienjoy.data.database.dao

import androidx.paging.PagingSource
import androidx.room.*
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.AnimeWithEpisodes
import kotlinx.coroutines.flow.Flow

@Dao
interface AnimeDao {

    @Query("SELECT * FROM anime WHERE favorite = 1 ORDER BY dateAdded DESC")
    fun getFavoriteAnime(): Flow<List<AnimeEntity>>

    @Query("SELECT * FROM anime WHERE favorite = 1 ORDER BY dateAdded DESC")
    fun getFavoriteAnimePaging(): PagingSource<Int, AnimeEntity>

    @Query("SELECT * FROM anime WHERE id = :id")
    suspend fun getAnimeById(id: Long): AnimeEntity?

    @Query("SELECT * FROM anime WHERE source = :source AND url = :url")
    suspend fun getAnimeBySourceAndUrl(source: String, url: String): AnimeEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(anime: AnimeEntity): Long

    @Update
    suspend fun update(anime: AnimeEntity)

    @Delete
    suspend fun delete(anime: AnimeEntity)

    @Query("UPDATE anime SET favorite = :favorite WHERE id = :animeId")
    suspend fun updateFavorite(animeId: Long, favorite: Boolean)

    @Query("UPDATE anime SET thumbnailUrl = :thumbnailUrl WHERE id = :animeId")
    suspend fun updateThumbnail(animeId: Long, thumbnailUrl: String?)

    @Query("SELECT EXISTS(SELECT 1 FROM anime WHERE source = :source AND url = :url AND favorite = 1)")
    suspend fun isAnimeFavorite(source: String, url: String): Boolean

    @Query("SELECT * FROM anime WHERE favorite = 1 AND title LIKE '%' || :query || '%'")
    fun searchFavoriteAnime(query: String): Flow<List<AnimeEntity>>

    @Query("SELECT COUNT(*) FROM anime WHERE favorite = 1")
    fun getFavoriteAnimeCount(): Flow<Int>

    @Transaction
    @Query("SELECT * FROM anime WHERE id = :animeId")
    suspend fun getAnimeWithEpisodes(animeId: Long): AnimeWithEpisodes?
}

// Extension entity with episodes
data class AnimeWithEpisodes(
    @Embedded val anime: AnimeEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "animeId"
    )
    val episodes: List<EpisodeEntity>
)
