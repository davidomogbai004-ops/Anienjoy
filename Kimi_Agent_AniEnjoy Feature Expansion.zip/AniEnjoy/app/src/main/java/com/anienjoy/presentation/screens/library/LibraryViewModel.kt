package com.anienjoy.presentation.screens.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import com.anienjoy.data.database.entity.NovelEntity
import com.anienjoy.data.preferences.SettingsPreferences
import com.anienjoy.domain.repository.LibraryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val libraryRepository: LibraryRepository,
    private val settingsPreferences: SettingsPreferences
) : ViewModel() {

    private val _uiState = MutableStateFlow<LibraryUiState>(LibraryUiState.Loading)
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    private val _selectedLanguages = MutableStateFlow<Set<String>>(emptySet())
    val selectedLanguages: StateFlow<Set<String>> = _selectedLanguages.asStateFlow()

    init {
        viewModelScope.launch {
            // Load saved language preferences
            settingsPreferences.enabledLanguages.collect { languages ->
                _selectedLanguages.value = languages
            }
        }

        viewModelScope.launch {
            libraryRepository.getAllLibraryItems()
                .combine(_selectedLanguages) { items, languages ->
                    if (languages.isEmpty()) {
                        items
                    } else {
                        LibraryItems(
                            anime = items.anime.filter { it.source in languages },
                            manga = items.manga.filter { it.source in languages },
                            manhwa = items.manhwa.filter { it.source in languages },
                            manhua = items.manhua.filter { it.source in languages },
                            novels = items.novels.filter { it.source in languages }
                        )
                    }
                }
                .collect { items ->
                    _uiState.value = LibraryUiState.Success(
                        items = items.anime + items.manga + items.manhwa + items.manhua + items.novels,
                        anime = items.anime,
                        manga = items.manga,
                        manhwa = items.manhwa,
                        manhua = items.manhua,
                        novels = items.novels,
                        selectedLanguages = _selectedLanguages.value
                    )
                }
        }
    }

    fun toggleLanguage(language: String) {
        viewModelScope.launch {
            val current = _selectedLanguages.value.toMutableSet()
            if (language in current) {
                current.remove(language)
            } else {
                current.add(language)
            }
            _selectedLanguages.value = current
            settingsPreferences.setEnabledLanguages(current)
        }
    }

    fun refreshLibrary() {
        viewModelScope.launch {
            libraryRepository.checkForUpdates()
        }
    }
}

sealed class LibraryUiState {
    object Loading : LibraryUiState()
    data class Success(
        val items: List<Any>,
        val anime: List<AnimeEntity>,
        val manga: List<MangaEntity>,
        val manhwa: List<MangaEntity>,
        val manhua: List<MangaEntity>,
        val novels: List<NovelEntity>,
        val selectedLanguages: Set<String>
    ) : LibraryUiState()
    data class Error(val message: String) : LibraryUiState()
}
