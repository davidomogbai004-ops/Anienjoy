package com.anienjoy.data.repository

import android.app.Application
import android.content.pm.PackageInfo
nimport com.anienjoy.data.database.dao.ExtensionDao
import com.anienjoy.data.database.entity.ExtensionEntity
import com.anienjoy.data.database.entity.ExtensionRepoEntity
import com.anienjoy.domain.repository.ExtensionRepository
import com.anienjoy.extension.api.Extension
import com.anienjoy.extension.api.ExtensionInfo
import com.anienjoy.extension.api.SourceInfo
import com.anienjoy.extension.api.ContentType
import com.anienjoy.extension.api.loader.ExtensionLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ExtensionRepositoryImpl @Inject constructor(
    private val app: Application,
    private val extensionDao: ExtensionDao
) : ExtensionRepository {

    private val extensionLoader = ExtensionLoader(app)
    private val httpClient = OkHttpClient()

    override fun getInstalledExtensions(): Flow<List<ExtensionEntity>> {
        return extensionDao.getInstalledExtensions()
    }

    override fun getExtensionsWithUpdate(): Flow<List<ExtensionEntity>> {
        return extensionDao.getExtensionsWithUpdate()
    }

    override fun getExtensionRepos(): Flow<List<ExtensionRepoEntity>> {
        return extensionDao.getAllRepos()
    }

    override fun getEnabledRepos(): Flow<List<ExtensionRepoEntity>> {
        return extensionDao.getEnabledRepos()
    }

    override suspend fun addRepo(repo: ExtensionRepoEntity) {
        extensionDao.insertRepo(repo)
    }

    override suspend fun removeRepo(repo: ExtensionRepoEntity) {
        extensionDao.deleteRepo(repo)
    }

    override suspend fun setRepoEnabled(repoId: Long, enabled: Boolean) {
        extensionDao.setRepoEnabled(repoId, enabled)
    }

    override suspend fun loadInstalledExtensions(): List<ExtensionLoader.LoadResult> {
        return withContext(Dispatchers.IO) {
            extensionLoader.loadExtensions()
        }
    }

    override suspend fun fetchExtensionsFromRepo(repoUrl: String): List<ExtensionInfo> {
        return withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url(repoUrl)
                    .build()

                val response = httpClient.newCall(request).execute()
                val jsonString = response.body?.string() ?: return@withContext emptyList()

                parseExtensionJson(jsonString)
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }
        }
    }

    private fun parseExtensionJson(jsonString: String): List<ExtensionInfo> {
        val extensions = mutableListOf<ExtensionInfo>()
        
        try {
            val json = JSONObject(jsonString)
            val extensionsArray = json.getJSONArray("extensions")

            for (i in 0 until extensionsArray.length()) {
                val extObj = extensionsArray.getJSONObject(i)
                val sourcesArray = extObj.optJSONArray("sources") ?: JSONArray()
                val sources = mutableListOf<SourceInfo>()

                for (j in 0 until sourcesArray.length()) {
                    val srcObj = sourcesArray.getJSONObject(j)
                    sources.add(
                        SourceInfo(
                            id = srcObj.getLong("id"),
                            name = srcObj.getString("name"),
                            baseUrl = srcObj.optString("baseUrl", ""),
                            lang = srcObj.getString("lang"),
                            contentType = parseContentType(srcObj.optString("type", "manga"))
                        )
                    )
                }

                extensions.add(
                    ExtensionInfo(
                        name = extObj.getString("name"),
                        pkgName = extObj.getString("pkg"),
                        version = extObj.getString("version"),
                        versionCode = extObj.getInt("code"),
                        libVersion = extObj.optString("libVersion", "1.0"),
                        lang = extObj.getString("lang"),
                        isNsfw = extObj.optBoolean("nsfw", false),
                        sources = sources
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return extensions
    }

    private fun parseContentType(type: String): ContentType {
        return when (type.lowercase()) {
            "anime" -> ContentType.ANIME
            "manga" -> ContentType.MANGA
            "manhwa" -> ContentType.MANHWA
            "manhua" -> ContentType.MANHUA
            "novel" -> ContentType.NOVEL
            else -> ContentType.MANGA
        }
    }

    override suspend fun installExtension(extensionInfo: ExtensionInfo): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // Download APK from repo
                val apkUrl = extensionInfo.repoUrl?.replace(
                    "index.min.json",
                    "apk/${extensionInfo.pkgName}-${extensionInfo.versionCode}.apk"
                ) ?: return@withContext false

                val request = Request.Builder()
                    .url(apkUrl)
                    .build()

                val response = httpClient.newCall(request).execute()
                val apkFile = File(app.cacheDir, "${extensionInfo.pkgName}.apk")
                
                response.body?.byteStream()?.use { input ->
                    apkFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }

                // Install APK (requires system permission or user interaction)
                // This is a simplified version - actual implementation would use PackageInstaller
                val entity = ExtensionEntity(
                    name = extensionInfo.name,
                    pkgName = extensionInfo.pkgName,
                    version = extensionInfo.version,
                    versionCode = extensionInfo.versionCode,
                    libVersion = extensionInfo.libVersion,
                    lang = extensionInfo.lang,
                    isNsfw = extensionInfo.isNsfw,
                    isInstalled = true,
                    repoUrl = extensionInfo.repoUrl
                )
                extensionDao.insert(entity)
                
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }

    override suspend fun uninstallExtension(pkgName: String) {
        extensionDao.deleteByPkgName(pkgName)
    }

    override suspend fun checkForUpdates() {
        val repos = extensionDao.getEnabledRepos().first()
        val installedExtensions = extensionDao.getInstalledExtensions().first()

        repos.forEach { repo ->
            val remoteExtensions = fetchExtensionsFromRepo(repo.url)
            
            remoteExtensions.forEach { remote ->
                val local = installedExtensions.find { it.pkgName == remote.pkgName }
                if (local != null && remote.versionCode > local.versionCode) {
                    extensionDao.updateHasUpdate(local.id, true)
                }
            }
        }
    }

    override suspend fun saveExtensionEntity(extension: ExtensionEntity) {
        extensionDao.insert(extension)
    }

    override suspend fun getExtensionByPkgName(pkgName: String): ExtensionEntity? {
        return extensionDao.getExtensionByPkgName(pkgName)
    }
}
