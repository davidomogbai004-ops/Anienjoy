package com.anienjoy.data.download

import android.app.DownloadManager as AndroidDownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.anienjoy.data.database.entity.DownloadEntity
import com.anienjoy.domain.repository.DownloadRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val downloadRepository: DownloadRepository
) {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    
    private val _downloadProgress = MutableSharedFlow<DownloadProgress>()
    val downloadProgress: SharedFlow<DownloadProgress> = _downloadProgress.asSharedFlow()

    private var activeDownloads = mutableMapOf<Long, Job>()
    private val maxConcurrentDownloads = 3

    init {
        createNotificationChannel()
        startDownloadQueue()
    }

    fun enqueueDownload(
        contentId: Long,
        contentType: String,
        chapterId: Long?,
        title: String,
        chapterName: String?,
        thumbnailUrl: String?,
        source: String,
        url: String,
        priority: Int = 0
    ): Long {
        val download = DownloadEntity(
            contentId = contentId,
            contentType = contentType,
            chapterId = chapterId,
            title = title,
            chapterName = chapterName,
            thumbnailUrl = thumbnailUrl,
            source = source,
            url = url,
            status = DownloadEntity.STATUS_QUEUED,
            priority = priority
        )

        var downloadId: Long = 0
        scope.launch {
            downloadId = downloadRepository.insertDownload(download)
            processDownloadQueue()
        }

        return downloadId
    }

    fun enqueueMultipleDownloads(downloads: List<DownloadRequest>) {
        scope.launch {
            val entities = downloads.map { request ->
                DownloadEntity(
                    contentId = request.contentId,
                    contentType = request.contentType,
                    chapterId = request.chapterId,
                    title = request.title,
                    chapterName = request.chapterName,
                    thumbnailUrl = request.thumbnailUrl,
                    source = request.source,
                    url = request.url,
                    status = DownloadEntity.STATUS_QUEUED,
                    priority = request.priority
                )
            }
            downloadRepository.insertDownloads(entities)
            processDownloadQueue()
        }
    }

    fun pauseDownload(downloadId: Long) {
        activeDownloads[downloadId]?.cancel()
        activeDownloads.remove(downloadId)
        scope.launch {
            downloadRepository.updateStatus(downloadId, DownloadEntity.STATUS_PAUSED)
        }
    }

    fun resumeDownload(downloadId: Long) {
        scope.launch {
            downloadRepository.updateStatus(downloadId, DownloadEntity.STATUS_QUEUED)
            processDownloadQueue()
        }
    }

    fun cancelDownload(downloadId: Long) {
        activeDownloads[downloadId]?.cancel()
        activeDownloads.remove(downloadId)
        scope.launch {
            downloadRepository.updateStatus(downloadId, DownloadEntity.STATUS_CANCELLED)
        }
    }

    fun retryDownload(downloadId: Long) {
        scope.launch {
            downloadRepository.updateStatus(downloadId, DownloadEntity.STATUS_QUEUED)
            processDownloadQueue()
        }
    }

    fun deleteDownload(downloadId: Long) {
        scope.launch {
            val download = downloadRepository.getDownloadById(downloadId)
            download?.let {
                // Delete local file if exists
                it.localPath?.let { path ->
                    File(path).delete()
                }
                downloadRepository.deleteDownload(it)
            }
        }
    }

    private fun startDownloadQueue() {
        scope.launch {
            processDownloadQueue()
        }
    }

    private suspend fun processDownloadQueue() {
        while (activeDownloads.size < maxConcurrentDownloads) {
            val download = downloadRepository.getNextPendingDownload() ?: break
            
            val job = scope.launch {
                downloadRepository.updateStatus(download.id, DownloadEntity.STATUS_DOWNLOADING)
                performDownload(download)
            }
            
            activeDownloads[download.id] = job
            
            job.invokeOnCompletion {
                activeDownloads.remove(download.id)
                scope.launch { processDownloadQueue() }
            }
        }
    }

    private suspend fun performDownload(download: DownloadEntity) {
        try {
            val request = Request.Builder()
                .url(download.url)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw Exception("Download failed: ${response.code}")
                }

                val totalBytes = response.body?.contentLength() ?: 0
                downloadRepository.updateProgress(download.id, 0, totalBytes)

                // Create download directory
                val downloadDir = when (download.contentType) {
                    "ANIME" -> File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AniEnjoy/Anime/${download.title}")
                    "MANGA", "MANHWA", "MANHUA" -> File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AniEnjoy/Manga/${download.title}")
                    "NOVEL" -> File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "AniEnjoy/Novels/${download.title}")
                    else -> File(context.getExternalFilesDir(null), "AniEnjoy/Downloads")
                }
                downloadDir.mkdirs()

                // Create file
                val fileName = when (download.contentType) {
                    "ANIME" -> "${download.chapterName?.replace(" ", "_") ?: "episode"}.mp4"
                    "MANGA", "MANHWA", "MANHUA" -> "${download.chapterName?.replace(" ", "_") ?: "chapter"}_${System.currentTimeMillis()}.jpg"
                    "NOVEL" -> "${download.chapterName?.replace(" ", "_") ?: "chapter"}.txt"
                    else -> "download_${System.currentTimeMillis()}"
                }
                val file = File(downloadDir, fileName)

                // Download file
                response.body?.byteStream()?.use { input ->
                    FileOutputStream(file).use { output ->
                        val buffer = ByteArray(8192)
                        var downloadedBytes = 0L
                        var read: Int

                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                            downloadedBytes += read
                            
                            downloadRepository.updateProgress(download.id, downloadedBytes, totalBytes)
                            _downloadProgress.emit(
                                DownloadProgress(
                                    downloadId = download.id,
                                    downloadedBytes = downloadedBytes,
                                    totalBytes = totalBytes,
                                    progress = if (totalBytes > 0) downloadedBytes.toFloat() / totalBytes else 0f
                                )
                            )
                        }
                    }
                }

                // Mark as completed
                downloadRepository.markAsCompleted(download.id, file.absolutePath)
                showDownloadCompleteNotification(download)
            }
        } catch (e: Exception) {
            downloadRepository.markAsFailed(download.id, e.message ?: "Unknown error")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Download progress notifications"
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun showDownloadCompleteNotification(download: DownloadEntity) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_download_done)
            .setContentTitle("Download Complete")
            .setContentText("${download.title} - ${download.chapterName ?: ""}")
            .setAutoCancel(true)
            .build()

        notificationManager.notify(download.id.toInt(), notification)
    }

    companion object {
        const val CHANNEL_ID = "downloads_channel"
    }
}

data class DownloadRequest(
    val contentId: Long,
    val contentType: String,
    val chapterId: Long?,
    val title: String,
    val chapterName: String?,
    val thumbnailUrl: String?,
    val source: String,
    val url: String,
    val priority: Int = 0
)

data class DownloadProgress(
    val downloadId: Long,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val progress: Float
)
