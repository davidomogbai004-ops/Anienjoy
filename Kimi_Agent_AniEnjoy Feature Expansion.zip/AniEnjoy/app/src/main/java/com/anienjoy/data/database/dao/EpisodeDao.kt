package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.EpisodeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EpisodeDao {

    @Query("SELECT * FROM episodes WHERE animeId = :animeId ORDER BY sourceOrder ASC")
    fun getEpisodesByAnimeId(animeId: Long): Flow<List<EpisodeEntity>>

    @Query("SELECT * FROM episodes WHERE animeId = :animeId ORDER BY sourceOrder ASC")
    suspend fun getEpisodesByAnimeIdSync(animeId: Long): List<EpisodeEntity>

    @Query("SELECT * FROM episodes WHERE id = :id")
    suspend fun getEpisodeById(id: Long): EpisodeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(episode: EpisodeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(episodes: List<EpisodeEntity>)

    @Update
    suspend fun update(episode: EpisodeEntity)

    @Delete
    suspend fun delete(episode: EpisodeEntity)

    @Query("UPDATE episodes SET seen = :seen WHERE id = :episodeId")
    suspend fun updateSeen(episodeId: Long, seen: Boolean)

    @Query("UPDATE episodes SET bookmark = :bookmark WHERE id = :episodeId")
    suspend fun updateBookmark(episodeId: Long, bookmark: Boolean)

    @Query("UPDATE episodes SET lastSecondSeen = :lastSecondSeen, totalSeconds = :totalSeconds WHERE id = :episodeId")
    suspend fun updateProgress(episodeId: Long, lastSecondSeen: Long, totalSeconds: Long)

    @Query("SELECT COUNT(*) FROM episodes WHERE animeId = :animeId AND seen = 1")
    fun getSeenEpisodeCount(animeId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM episodes WHERE animeId = :animeId")
    fun getTotalEpisodeCount(animeId: Long): Flow<Int>

    @Query("SELECT * FROM episodes WHERE animeId = :animeId AND seen = 0 ORDER BY sourceOrder ASC LIMIT 1")
    suspend fun getNextUnseenEpisode(animeId: Long): EpisodeEntity?

    @Query("DELETE FROM episodes WHERE animeId = :animeId")
    suspend fun deleteAllByAnimeId(animeId: Long)
}
