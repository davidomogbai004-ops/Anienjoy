package com.anienjoy.data.repository

import com.anienjoy.data.database.dao.DownloadDao
import com.anienjoy.data.database.entity.DownloadEntity
import com.anienjoy.domain.repository.DownloadRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadRepositoryImpl @Inject constructor(
    private val downloadDao: DownloadDao
) : DownloadRepository {

    override fun getAllDownloads(): Flow<List<DownloadEntity>> {
        return downloadDao.getAllDownloads()
    }

    override fun getDownloadsByStatus(status: Int): Flow<List<DownloadEntity>> {
        return downloadDao.getDownloadsByStatus(status)
    }

    override fun getDownloadsByStatuses(statuses: List<Int>): Flow<List<DownloadEntity>> {
        return downloadDao.getDownloadsByStatuses(statuses)
    }

    override fun getDownloadsForContent(contentId: Long, contentType: String): Flow<List<DownloadEntity>> {
        return downloadDao.getDownloadsForContent(contentId, contentType)
    }

    override suspend fun getDownloadById(id: Long): DownloadEntity? {
        return downloadDao.getDownloadById(id)
    }

    override suspend fun getNextPendingDownload(): DownloadEntity? {
        return downloadDao.getNextPendingDownload()
    }

    override fun getActiveDownloadCount(): Flow<Int> {
        return downloadDao.getActiveDownloadCount()
    }

    override fun getPendingDownloadCount(): Flow<Int> {
        return downloadDao.getPendingDownloadCount()
    }

    override fun getCompletedDownloadCount(): Flow<Int> {
        return downloadDao.getCompletedDownloadCount()
    }

    override suspend fun insertDownload(download: DownloadEntity): Long {
        return downloadDao.insertDownload(download)
    }

    override suspend fun insertDownloads(downloads: List<DownloadEntity>) {
        downloadDao.insertDownloads(downloads)
    }

    override suspend fun updateDownload(download: DownloadEntity) {
        downloadDao.updateDownload(download)
    }

    override suspend fun updateStatus(downloadId: Long, status: Int) {
        downloadDao.updateStatus(downloadId, status)
    }

    override suspend fun updateProgress(downloadId: Long, bytes: Long, total: Long) {
        downloadDao.updateProgress(downloadId, bytes, total)
    }

    override suspend fun markAsCompleted(downloadId: Long, path: String, timestamp: Long) {
        downloadDao.markAsCompleted(downloadId, path, timestamp)
    }

    override suspend fun markAsFailed(downloadId: Long, error: String) {
        downloadDao.markAsFailed(downloadId, error)
    }

    override suspend fun deleteDownload(download: DownloadEntity) {
        downloadDao.deleteDownload(download)
    }

    override suspend fun deleteDownloadById(downloadId: Long) {
        downloadDao.deleteDownloadById(downloadId)
    }

    override suspend fun deleteCompletedDownloads() {
        downloadDao.deleteCompletedDownloads()
    }

    override suspend fun deleteAllDownloads() {
        downloadDao.deleteAllDownloads()
    }

    override suspend fun isContentDownloading(contentId: Long, contentType: String, chapterId: Long?): Boolean {
        return downloadDao.isContentDownloading(contentId, contentType, chapterId)
    }

    override suspend fun isContentDownloaded(contentId: Long, contentType: String, chapterId: Long?): Boolean {
        return downloadDao.isContentDownloaded(contentId, contentType, chapterId)
    }
}
