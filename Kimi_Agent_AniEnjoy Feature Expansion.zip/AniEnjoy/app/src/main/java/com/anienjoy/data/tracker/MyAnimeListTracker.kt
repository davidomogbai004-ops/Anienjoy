package com.anienjoy.data.tracker

import android.content.Context
import android.content.SharedPreferences
import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.MangaEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MyAnimeListTracker @Inject constructor(
    private val context: Context
) : TrackerService {

    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }
    private val prefs: SharedPreferences = context.getSharedPreferences("mal_tracker", Context.MODE_PRIVATE)

    override val name: String = "MyAnimeList"
    override val iconUrl: String = "https://cdn.myanimelist.net/img/sp/icon/apple-touch-icon-256.png"

    private val clientId = "YOUR_MAL_CLIENT_ID" // Replace with actual client ID
    private val baseUrl = "https://api.myanimelist.net/v2"

    override suspend fun login(username: String, password: String?, authCode: String?): Result<String> {
        return try {
            authCode?.let { code ->
                val token = exchangeCodeForToken(code)
                saveToken(token)
                Result.success("Logged in successfully")
            } ?: Result.failure(Exception("Auth code required"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun logout() {
        prefs.edit().remove("access_token").remove("refresh_token").apply()
    }

    override suspend fun isLoggedIn(): Boolean {
        return getAccessToken() != null
    }

    override suspend fun searchAnime(query: String): List<TrackerSearchResult> {
        return searchMedia(query, "anime")
    }

    override suspend fun searchManga(query: String): List<TrackerSearchResult> {
        return searchMedia(query, "manga")
    }

    private suspend fun searchMedia(query: String, type: String): List<TrackerSearchResult> {
        val token = getAccessToken() ?: return emptyList()

        val request = Request.Builder()
            .url("$baseUrl/$type?q=$query&limit=10&fields=id,title,main_picture,synopsis,num_episodes,num_chapters,start_date,status")
            .header("Authorization", "Bearer $token")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return emptyList()
            val result = json.decodeFromString<MALSearchResponse>(responseBody)

            result.data.map { node ->
                TrackerSearchResult(
                    id = node.node.id.toString(),
                    title = node.node.title,
                    coverImage = node.node.main_picture?.medium,
                    description = node.node.synopsis,
                    type = type.uppercase(),
                    totalEpisodes = node.node.num_episodes,
                    totalChapters = node.node.num_chapters,
                    startDate = node.node.start_date,
                    status = node.node.status
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override suspend fun getAnimeList(): List<TrackerAnimeEntry> {
        val token = getAccessToken() ?: return emptyList()

        val request = Request.Builder()
            .url("$baseUrl/users/@me/animelist?fields=list_status{status,score,num_episodes_watched,is_rewatching,start_date,finish_date,num_times_rewatched,comments},id,title,main_picture,num_episodes&limit=1000")
            .header("Authorization", "Bearer $token")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return emptyList()
            val result = json.decodeFromString<MALAnimeListResponse>(responseBody)

            result.data.map { item ->
                TrackerAnimeEntry(
                    id = item.node.id.toString(),
                    mediaId = item.node.id.toString(),
                    title = item.node.title,
                    coverImage = item.node.main_picture?.medium,
                    status = mapMALStatusToTracker(item.list_status?.status ?: "watching"),
                    score = item.list_status?.score?.toFloat() ?: 0f,
                    episodesWatched = item.list_status?.num_episodes_watched ?: 0,
                    totalEpisodes = item.node.num_episodes,
                    startDate = item.list_status?.start_date,
                    finishDate = item.list_status?.finish_date,
                    rewatchCount = item.list_status?.num_times_rewatched ?: 0,
                    notes = item.list_status?.comments
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override suspend fun getMangaList(): List<TrackerMangaEntry> {
        val token = getAccessToken() ?: return emptyList()

        val request = Request.Builder()
            .url("$baseUrl/users/@me/mangalist?fields=list_status{status,score,num_chapters_read,num_volumes_read,is_rereading,start_date,finish_date,num_times_reread,comments},id,title,main_picture,num_chapters,num_volumes&limit=1000")
            .header("Authorization", "Bearer $token")
            .build()

        return try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return emptyList()
            val result = json.decodeFromString<MALMangaListResponse>(responseBody)

            result.data.map { item ->
                TrackerMangaEntry(
                    id = item.node.id.toString(),
                    mediaId = item.node.id.toString(),
                    title = item.node.title,
                    coverImage = item.node.main_picture?.medium,
                    status = mapMALStatusToTracker(item.list_status?.status ?: "reading"),
                    score = item.list_status?.score?.toFloat() ?: 0f,
                    chaptersRead = item.list_status?.num_chapters_read ?: 0,
                    totalChapters = item.node.num_chapters,
                    volumesRead = item.list_status?.num_volumes_read ?: 0,
                    totalVolumes = item.node.num_volumes,
                    startDate = item.list_status?.start_date,
                    finishDate = item.list_status?.finish_date,
                    rereadCount = item.list_status?.num_times_reread ?: 0,
                    notes = item.list_status?.comments
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override suspend fun addAnime(entry: TrackerAnimeEntry): Result<Unit> {
        return updateAnimeListEntry(
            animeId = entry.mediaId,
            status = mapTrackerStatusToMAL(entry.status),
            score = entry.score.toInt(),
            numWatchedEpisodes = entry.episodesWatched
        )
    }

    override suspend fun updateAnime(entry: TrackerAnimeEntry): Result<Unit> {
        return updateAnimeListEntry(
            animeId = entry.mediaId,
            status = mapTrackerStatusToMAL(entry.status),
            score = entry.score.toInt(),
            numWatchedEpisodes = entry.episodesWatched
        )
    }

    override suspend fun addManga(entry: TrackerMangaEntry): Result<Unit> {
        return updateMangaListEntry(
            mangaId = entry.mediaId,
            status = mapTrackerStatusToMAL(entry.status),
            score = entry.score.toInt(),
            numReadChapters = entry.chaptersRead,
            numReadVolumes = entry.volumesRead
        )
    }

    override suspend fun updateManga(entry: TrackerMangaEntry): Result<Unit> {
        return updateMangaListEntry(
            mangaId = entry.mediaId,
            status = mapTrackerStatusToMAL(entry.status),
            score = entry.score.toInt(),
            numReadChapters = entry.chaptersRead,
            numReadVolumes = entry.volumesRead
        )
    }

    private suspend fun updateAnimeListEntry(
        animeId: String,
        status: String,
        score: Int,
        numWatchedEpisodes: Int
    ): Result<Unit> {
        val token = getAccessToken() ?: return Result.failure(Exception("Not logged in"))

        val formBody = FormBody.Builder()
            .add("status", status)
            .add("score", score.toString())
            .add("num_watched_episodes", numWatchedEpisodes.toString())
            .build()

        val request = Request.Builder()
            .url("$baseUrl/anime/$anId/my_list_status")
            .header("Authorization", "Bearer $token")
            .patch(formBody)
            .build()

        return try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to update: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun updateMangaListEntry(
        mangaId: String,
        status: String,
        score: Int,
        numReadChapters: Int,
        numReadVolumes: Int
    ): Result<Unit> {
        val token = getAccessToken() ?: return Result.failure(Exception("Not logged in"))

        val formBody = FormBody.Builder()
            .add("status", status)
            .add("score", score.toString())
            .add("num_chapters_read", numReadChapters.toString())
            .add("num_volumes_read", numReadVolumes.toString())
            .build()

        val request = Request.Builder()
            .url("$baseUrl/manga/$mangaId/my_list_status")
            .header("Authorization", "Bearer $token")
            .patch(formBody)
            .build()

        return try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to update: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteAnime(id: String): Result<Unit> {
        val token = getAccessToken() ?: return Result.failure(Exception("Not logged in"))

        val request = Request.Builder()
            .url("$baseUrl/anime/$id/my_list_status")
            .header("Authorization", "Bearer $token")
            .delete()
            .build()

        return try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to delete: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteManga(id: String): Result<Unit> {
        val token = getAccessToken() ?: return Result.failure(Exception("Not logged in"))

        val request = Request.Builder()
            .url("$baseUrl/manga/$id/my_list_status")
            .header("Authorization", "Bearer $token")
            .delete()
            .build()

        return try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to delete: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncAnime(anime: AnimeEntity, episodesWatched: Int, status: TrackerStatus) {
        val results = searchAnime(anime.title)
        val match = results.firstOrNull { it.title.equals(anime.title, ignoreCase = true) }
            ?: results.firstOrNull()

        match?.let {
            val entry = TrackerAnimeEntry(
                mediaId = it.id,
                title = it.title,
                coverImage = it.coverImage,
                status = status,
                episodesWatched = episodesWatched,
                totalEpisodes = it.totalEpisodes
            )
            addAnime(entry)
        }
    }

    override suspend fun syncManga(manga: MangaEntity, chaptersRead: Int, status: TrackerStatus) {
        val results = searchManga(manga.title)
        val match = results.firstOrNull { it.title.equals(manga.title, ignoreCase = true) }
            ?: results.firstOrNull()

        match?.let {
            val entry = TrackerMangaEntry(
                mediaId = it.id,
                title = it.title,
                coverImage = it.coverImage,
                status = status,
                chaptersRead = chaptersRead,
                totalChapters = it.totalChapters
            )
            addManga(entry)
        }
    }

    private fun mapMALStatusToTracker(malStatus: String): TrackerStatus {
        return when (malStatus) {
            "watching", "reading" -> TrackerStatus.CURRENT
            "completed" -> TrackerStatus.COMPLETED
            "on_hold" -> TrackerStatus.PAUSED
            "dropped" -> TrackerStatus.DROPPED
            "plan_to_watch", "plan_to_read" -> TrackerStatus.PLANNING
            else -> TrackerStatus.CURRENT
        }
    }

    private fun mapTrackerStatusToMAL(status: TrackerStatus): String {
        return when (status) {
            TrackerStatus.CURRENT -> "watching"
            TrackerStatus.PLANNING -> "plan_to_watch"
            TrackerStatus.COMPLETED -> "completed"
            TrackerStatus.DROPPED -> "dropped"
            TrackerStatus.PAUSED -> "on_hold"
            TrackerStatus.REPEATING -> "watching"
        }
    }

    private suspend fun exchangeCodeForToken(code: String): String {
        // OAuth2 token exchange implementation
        return ""
    }

    private fun saveToken(token: String) {
        prefs.edit().putString("access_token", token).apply()
    }

    private fun getAccessToken(): String? {
        return prefs.getString("access_token", null)
    }

    fun getAuthUrl(): String {
        return "https://myanimelist.net/v1/oauth2/authorize?response_type=code&client_id=$clientId&code_challenge=YOUR_CODE_CHALLENGE&code_challenge_method=plain"
    }
}

// Data classes for MAL API responses
@Serializable
data class MALSearchResponse(
    val data: List<MALNode>
)

@Serializable
data class MALNode(
    val node: MALMedia
)

@Serializable
data class MALMedia(
    val id: Int,
    val title: String,
    val main_picture: MALPicture? = null,
    val synopsis: String? = null,
    val num_episodes: Int? = null,
    val num_chapters: Int? = null,
    val num_volumes: Int? = null,
    val start_date: String? = null,
    val status: String? = null
)

@Serializable
data class MALPicture(
    val medium: String? = null,
    val large: String? = null
)

@Serializable
data class MALAnimeListResponse(
    val data: List<MALAnimeListItem>
)

@Serializable
data class MALAnimeListItem(
    val node: MALMedia,
    val list_status: MALAnimeListStatus? = null
)

@Serializable
data class MALAnimeListStatus(
    val status: String? = null,
    val score: Int? = null,
    val num_episodes_watched: Int? = null,
    val is_rewatching: Boolean? = null,
    val start_date: String? = null,
    val finish_date: String? = null,
    val num_times_rewatched: Int? = null,
    val comments: String? = null
)

@Serializable
data class MALMangaListResponse(
    val data: List<MALMangaListItem>
)

@Serializable
data class MALMangaListItem(
    val node: MALMedia,
    val list_status: MALMangaListStatus? = null
)

@Serializable
data class MALMangaListStatus(
    val status: String? = null,
    val score: Int? = null,
    val num_chapters_read: Int? = null,
    val num_volumes_read: Int? = null,
    val is_rereading: Boolean? = null,
    val start_date: String? = null,
    val finish_date: String? = null,
    val num_times_reread: Int? = null,
    val comments: String? = null
)
