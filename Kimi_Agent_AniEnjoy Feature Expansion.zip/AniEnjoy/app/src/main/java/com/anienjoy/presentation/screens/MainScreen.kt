package com.anienjoy.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import com.anienjoy.presentation.screens.library.LibraryScreen

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Library : BottomNavItem(
        "library",
        "Library",
        Icons.Filled.CollectionsBookmark,
        Icons.Outlined.CollectionsBookmark
    )
    object Updates : BottomNavItem(
        "updates",
        "Updates",
        Icons.Filled.NewReleases,
        Icons.Outlined.NewReleases
    )
    object History : BottomNavItem(
        "history",
        "History",
        Icons.Filled.History,
        Icons.Outlined.History
    )
    object Browse : BottomNavItem(
        "browse",
        "Browse",
        Icons.Filled.Explore,
        Icons.Outlined.Explore
    )
    object More : BottomNavItem(
        "more",
        "More",
        Icons.Filled.MoreHoriz,
        Icons.Outlined.MoreHoriz
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavController) {
    var selectedItem by remember { mutableIntStateOf(0) }
    val items = listOf(
        BottomNavItem.Library,
        BottomNavItem.Updates,
        BottomNavItem.History,
        BottomNavItem.Browse,
        BottomNavItem.More
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(items[selectedItem].title) },
                actions = {
                    IconButton(onClick = { navController.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = {
                            Icon(
                                if (selectedItem == index) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.title
                            )
                        },
                        label = { Text(item.title) },
                        selected = selectedItem == index,
                        onClick = { selectedItem = index }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedItem) {
                0 -> LibraryScreen(navController = navController)
                1 -> UpdatesScreen(navController = navController)
                2 -> HistoryScreen(navController = navController)
                3 -> BrowseScreen(navController = navController)
                4 -> MoreScreen(navController = navController)
            }
        }
    }
}

@Composable
fun HistoryScreen(navController: NavController) {
    // History screen implementation
    Box(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "History",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Composable
fun MoreScreen(navController: NavController) {
    Column(modifier = Modifier.fillMaxSize()) {
        ListItem(
            headlineContent = { Text("Extensions") },
            leadingContent = { Icon(Icons.Default.Extension, contentDescription = null) },
            modifier = Modifier.clickable { navController.navigate("extensions") }
        )
        ListItem(
            headlineContent = { Text("Downloads") },
            leadingContent = { Icon(Icons.Default.Download, contentDescription = null) },
            modifier = Modifier.clickable { navController.navigate("downloads") }
        )
        ListItem(
            headlineContent = { Text("Settings") },
            leadingContent = { Icon(Icons.Default.Settings, contentDescription = null) },
            modifier = Modifier.clickable { navController.navigate("settings") }
        )
        ListItem(
            headlineContent = { Text("About") },
            leadingContent = { Icon(Icons.Default.Info, contentDescription = null) },
            modifier = Modifier.clickable { /* Navigate to About */ }
        )
    }
}
