package com.anienjoy.data.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.anienjoy.data.database.entity.UpdateEntity
import com.anienjoy.domain.repository.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

@HiltWorker
class UpdateCheckerWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val libraryRepository: LibraryRepository,
    private val animeRepository: AnimeRepository,
    private val mangaRepository: MangaRepository,
    private val novelRepository: NovelRepository,
    private val sourceRepository: SourceRepository,
    private val updateRepository: UpdateRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            checkForUpdates()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private suspend fun checkForUpdates() {
        val context = applicationContext

        // Check anime updates
        val animeList = libraryRepository.getAnimeLibrary().first()
        var newAnimeUpdates = 0

        animeList.forEach { anime ->
            try {
                val source = sourceRepository.getAnimeSourceById(anime.source.toLongOrNull() ?: 0L)
                source?.let {
                    val remoteEpisodes = it.getEpisodeList(
                        com.anienjoy.extension.api.model.Anime(
                            source = anime.source,
                            url = anime.url,
                            title = anime.title
                        )
                    )
                    val localEpisodes = animeRepository.getEpisodesByAnimeIdSync(anime.id)

                    if (remoteEpisodes.size > localEpisodes.size) {
                        val newEpisodes = remoteEpisodes.size - localEpisodes.size
                        newAnimeUpdates += newEpisodes

                        // Save update notification
                        val latestEpisode = remoteEpisodes.lastOrNull()
                        latestEpisode?.let { episode ->
                            updateRepository.insertUpdate(
                                UpdateEntity(
                                    contentId = anime.id,
                                    contentType = "ANIME",
                                    title = anime.title,
                                    thumbnailUrl = anime.thumbnailUrl,
                                    updateType = "NEW_EPISODE",
                                    updateInfo = "${newEpisodes} new episode(s) - Latest: ${episode.name}",
                                    source = anime.source
                                )
                            )
                        }

                        // Update episodes in database
                        val newEpisodeEntities = remoteEpisodes.drop(localEpisodes.size).map { episode ->
                            com.anienjoy.data.database.entity.EpisodeEntity(
                                animeId = anime.id,
                                url = episode.url,
                                name = episode.name,
                                scanlator = episode.scanlator,
                                episodeNumber = episode.episodeNumber,
                                sourceOrder = episode.sourceOrder,
                                dateUpload = episode.dateUpload
                            )
                        }
                        animeRepository.insertEpisodes(newEpisodeEntities)
                    }
                }
            } catch (e: Exception) {
                // Continue checking other anime
            }
        }

        // Check manga updates
        val mangaList = libraryRepository.getMangaLibrary().first()
        var newMangaUpdates = 0

        mangaList.forEach { manga ->
            try {
                val source = sourceRepository.getMangaSourceById(manga.source.toLongOrNull() ?: 0L)
                source?.let {
                    val remoteChapters = it.getChapterList(
                        com.anienjoy.extension.api.model.Manga(
                            source = manga.source,
                            url = manga.url,
                            title = manga.title
                        )
                    )
                    val localChapters = mangaRepository.getChaptersByMangaIdSync(manga.id)

                    if (remoteChapters.size > localChapters.size) {
                        val newChapters = remoteChapters.size - localChapters.size
                        newMangaUpdates += newChapters

                        // Save update notification
                        val latestChapter = remoteChapters.lastOrNull()
                        latestChapter?.let { chapter ->
                            updateRepository.insertUpdate(
                                UpdateEntity(
                                    contentId = manga.id,
                                    contentType = "MANGA",
                                    title = manga.title,
                                    thumbnailUrl = manga.thumbnailUrl,
                                    updateType = "NEW_CHAPTER",
                                    updateInfo = "${newChapters} new chapter(s) - Latest: ${chapter.name}",
                                    source = manga.source
                                )
                            )
                        }

                        // Update chapters in database
                        val newChapterEntities = remoteChapters.drop(localChapters.size).map { chapter ->
                            com.anienjoy.data.database.entity.ChapterEntity(
                                mangaId = manga.id,
                                url = chapter.url,
                                name = chapter.name,
                                scanlator = chapter.scanlator,
                                chapterNumber = chapter.chapterNumber,
                                sourceOrder = chapter.sourceOrder,
                                dateUpload = chapter.dateUpload
                            )
                        }
                        mangaRepository.insertChapters(newChapterEntities)
                    }
                }
            } catch (e: Exception) {
                // Continue checking other manga
            }
        }

        // Check novel updates
        val novelList = libraryRepository.getNovelLibrary().first()
        var newNovelUpdates = 0

        novelList.forEach { novel ->
            try {
                val source = sourceRepository.getNovelSourceById(novel.source.toLongOrNull() ?: 0L)
                source?.let {
                    val remoteChapters = it.getChapterList(
                        com.anienjoy.extension.api.model.Novel(
                            source = novel.source,
                            url = novel.url,
                            title = novel.title
                        )
                    )
                    val localChapters = novelRepository.getChaptersByNovelIdSync(novel.id)

                    if (remoteChapters.size > localChapters.size) {
                        val newChapters = remoteChapters.size - localChapters.size
                        newNovelUpdates += newChapters

                        // Save update notification
                        val latestChapter = remoteChapters.lastOrNull()
                        latestChapter?.let { chapter ->
                            updateRepository.insertUpdate(
                                UpdateEntity(
                                    contentId = novel.id,
                                    contentType = "NOVEL",
                                    title = novel.title,
                                    thumbnailUrl = novel.thumbnailUrl,
                                    updateType = "NEW_CHAPTER",
                                    updateInfo = "${newChapters} new chapter(s) - Latest: ${chapter.name}",
                                    source = novel.source
                                )
                            )
                        }

                        // Update chapters in database
                        val newChapterEntities = remoteChapters.drop(localChapters.size).map { chapter ->
                            com.anienjoy.data.database.entity.NovelChapterEntity(
                                novelId = novel.id,
                                url = chapter.url,
                                name = chapter.name,
                                scanlator = chapter.scanlator,
                                chapterNumber = chapter.chapterNumber,
                                sourceOrder = chapter.sourceOrder,
                                dateUpload = chapter.dateUpload
                            )
                        }
                        novelRepository.insertChapters(newChapterEntities)
                    }
                }
            } catch (e: Exception) {
                // Continue checking other novels
            }
        }

        // Show notification if there are updates
        val totalUpdates = newAnimeUpdates + newMangaUpdates + newNovelUpdates
        if (totalUpdates > 0) {
            showUpdateNotification(totalUpdates, newAnimeUpdates, newMangaUpdates, newNovelUpdates)
        }
    }

    private fun showUpdateNotification(
        totalUpdates: Int,
        animeUpdates: Int,
        mangaUpdates: Int,
        novelUpdates: Int
    ) {
        val context = applicationContext
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Library Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for new episodes and chapters"
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Build notification
        val notificationBuilder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Library Updates Available")
            .setContentText("$totalUpdates new update(s) found")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText(buildString {
                    if (animeUpdates > 0) append("$animeUpdates new episode(s)\n")
                    if (mangaUpdates > 0) append("$mangaUpdates new chapter(s) in manga\n")
                    if (novelUpdates > 0) append("$novelUpdates new chapter(s) in novels")
                }))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build())
    }

    companion object {
        const val WORK_NAME = "library_update_checker"
        const val CHANNEL_ID = "library_updates"
        const val NOTIFICATION_ID = 1001

        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val updateWorkRequest = PeriodicWorkRequestBuilder<UpdateCheckerWorker>(
                1, TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                updateWorkRequest
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }

        fun runImmediate(context: Context) {
            val workRequest = OneTimeWorkRequestBuilder<UpdateCheckerWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueue(workRequest)
        }
    }
}
