package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.UpdateEntity
import kotlinx.coroutines.flow.Flow

interface UpdateRepository {
    fun getAllUpdates(): Flow<List<UpdateEntity>>
    fun getUnreadUpdates(): Flow<List<UpdateEntity>>
    fun getUpdatesByType(contentType: String): Flow<List<UpdateEntity>>
    fun getUnreadUpdateCount(): Flow<Int>
    suspend fun getUpdateForContent(contentId: Long, contentType: String): UpdateEntity?
    suspend fun insertUpdate(update: UpdateEntity): Long
    suspend fun insertUpdates(updates: List<UpdateEntity>)
    suspend fun updateUpdate(update: UpdateEntity)
    suspend fun markAsRead(updateId: Long)
    suspend fun markAllAsRead()
    suspend fun deleteUpdate(update: UpdateEntity)
    suspend fun deleteOldUpdates(timestamp: Long)
    suspend fun deleteAllUpdates()
}
