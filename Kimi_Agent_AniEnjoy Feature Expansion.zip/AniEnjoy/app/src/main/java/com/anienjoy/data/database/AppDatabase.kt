package com.anienjoy.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.anienjoy.data.database.dao.*
import com.anienjoy.data.database.entity.*

@Database(
    entities = [
        AnimeEntity::class,
        EpisodeEntity::class,
        MangaEntity::class,
        ChapterEntity::class,
        NovelEntity::class,
        NovelChapterEntity::class,
        CategoryEntity::class,
        AnimeCategoryEntity::class,
        MangaCategoryEntity::class,
        NovelCategoryEntity::class,
        ExtensionEntity::class,
        ExtensionRepoEntity::class,
        UpdateEntity::class,
        DownloadEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun animeDao(): AnimeDao
    abstract fun episodeDao(): EpisodeDao
    abstract fun mangaDao(): MangaDao
    abstract fun chapterDao(): ChapterDao
    abstract fun novelDao(): NovelDao
    abstract fun novelChapterDao(): NovelChapterDao
    abstract fun categoryDao(): CategoryDao
    abstract fun extensionDao(): ExtensionDao
    abstract fun updateDao(): UpdateDao
    abstract fun downloadDao(): DownloadDao
}
