package com.anienjoy.presentation.screens.reader

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovelReaderScreen(
    navController: NavController,
    chapterId: Long?,
    viewModel: NovelReaderViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    LaunchedEffect(chapterId) {
        chapterId?.let { viewModel.loadChapter(it) }
    }

    // Save scroll position when leaving
    DisposableEffect(Unit) {
        onDispose {
            viewModel.saveScrollPosition(scrollState.value)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = (uiState as? NovelReaderUiState.Success)?.chapter?.name ?: "Reader",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.increaseFontSize() }) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Increase font size")
                    }
                    IconButton(onClick = { viewModel.decreaseFontSize() }) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Decrease font size")
                    }
                    IconButton(onClick = { viewModel.toggleTheme() }) {
                        Icon(Icons.Default.BrightnessMedium, contentDescription = "Toggle theme")
                    }
                }
            )
        },
        bottomBar = {
            NovelReaderBottomBar(
                onPreviousClick = { viewModel.loadPreviousChapter() },
                onNextClick = { viewModel.loadNextChapter() },
                hasPrevious = (uiState as? NovelReaderUiState.Success)?.hasPreviousChapter ?: false,
                hasNext = (uiState as? NovelReaderUiState.Success)?.hasNextChapter ?: false
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = uiState) {
                is NovelReaderUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is NovelReaderUiState.Success -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                            .padding(16.dp)
                    ) {
                        // Chapter title
                        Text(
                            text = state.chapter.name,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // Chapter content
                        Text(
                            text = state.content,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = state.fontSize
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                is NovelReaderUiState.Error -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Error: ${state.message}")
                    }
                }
            }
        }
    }
}

@Composable
fun NovelReaderBottomBar(
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    hasPrevious: Boolean,
    hasNext: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Button(
            onClick = onPreviousClick,
            enabled = hasPrevious
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = null)
            Spacer(modifier = Modifier.width(4.dp))
            Text("Previous")
        }

        Button(
            onClick = onNextClick,
            enabled = hasNext
        ) {
            Text("Next")
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.Default.ArrowForward, contentDescription = null)
        }
    }
}
