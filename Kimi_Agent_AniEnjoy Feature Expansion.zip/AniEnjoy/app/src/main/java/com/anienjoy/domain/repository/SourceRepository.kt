package com.anienjoy.domain.repository

import com.anienjoy.extension.api.*
import com.anienjoy.extension.api.model.*
import kotlinx.coroutines.flow.StateFlow

interface SourceRepository {
    val animeSources: StateFlow<List<AnimeSource>>
    val mangaSources: StateFlow<List<MangaSource>>
    val manhwaSources: StateFlow<List<MangaSource>>
    val manhuaSources: StateFlow<List<MangaSource>>
    val novelSources: StateFlow<List<NovelSource>>

    fun loadSources()
    fun getAnimeSourceById(id: Long): AnimeSource?
    fun getMangaSourceById(id: Long): MangaSource?
    fun getManhwaSourceById(id: Long): MangaSource?
    fun getManhuaSourceById(id: Long): MangaSource?
    fun getNovelSourceById(id: Long): NovelSource?
    fun getSourcesByLanguage(language: String): List<Source>
    fun getAllSources(): List<Source>

    // Anime operations
    suspend fun getPopularAnime(sourceId: Long, page: Int): AnimePage
    suspend fun getLatestAnime(sourceId: Long, page: Int): AnimePage
    suspend fun searchAnime(sourceId: Long, query: String, page: Int, filters: FilterList = FilterList()): AnimePage
    suspend fun getAnimeDetails(sourceId: Long, anime: Anime): Anime
    suspend fun getEpisodeList(sourceId: Long, anime: Anime): List<Episode>
    suspend fun getVideoList(sourceId: Long, episode: Episode): List<Video>

    // Manga operations
    suspend fun getPopularManga(sourceId: Long, page: Int): MangaPage
    suspend fun getLatestManga(sourceId: Long, page: Int): MangaPage
    suspend fun searchManga(sourceId: Long, query: String, page: Int, filters: FilterList = FilterList()): MangaPage
    suspend fun getMangaDetails(sourceId: Long, manga: Manga): Manga
    suspend fun getChapterList(sourceId: Long, manga: Manga): List<Chapter>
    suspend fun getPageList(sourceId: Long, chapter: Chapter): List<Page>

    // Novel operations
    suspend fun getPopularNovels(sourceId: Long, page: Int): NovelPage
    suspend fun getLatestNovels(sourceId: Long, page: Int): NovelPage
    suspend fun searchNovels(sourceId: Long, query: String, page: Int, filters: FilterList = FilterList()): NovelPage
    suspend fun getNovelDetails(sourceId: Long, novel: Novel): Novel
    suspend fun getNovelChapterList(sourceId: Long, novel: Novel): List<NovelChapter>
    suspend fun getNovelChapterContent(sourceId: Long, chapter: NovelChapter): String
}
