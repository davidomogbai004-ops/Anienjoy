package com.anienjoy.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.anienjoy.data.preferences.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Appearance section
            item {
                SettingsSectionTitle("Appearance")
            }

            item {
                ThemeSetting(
                    currentTheme = uiState.themeMode,
                    onThemeChange = viewModel::setThemeMode
                )
            }

            // Language section
            item {
                SettingsSectionTitle("Languages")
            }

            item {
                LanguageSettings(
                    enabledLanguages = uiState.enabledLanguages,
                    onLanguagesChange = viewModel::setEnabledLanguages
                )
            }

            // Library section
            item {
                SettingsSectionTitle("Library")
            }

            item {
                LibrarySettings(
                    columnsPortrait = uiState.libraryColumnsPortrait,
                    columnsLandscape = uiState.libraryColumnsLandscape,
                    onColumnsPortraitChange = viewModel::setLibraryColumnsPortrait,
                    onColumnsLandscapeChange = viewModel::setLibraryColumnsLandscape
                )
            }

            // Player section
            item {
                SettingsSectionTitle("Player")
            }

            item {
                PlayerSettings(
                    doubleTapSeekDuration = uiState.doubleTapSeekDuration,
                    onDoubleTapSeekChange = viewModel::setDoubleTapSeekDuration
                )
            }

            // Reader section
            item {
                SettingsSectionTitle("Reader")
            }

            item {
                ReaderSettings(
                    defaultReadingMode = uiState.defaultReadingMode,
                    onReadingModeChange = viewModel::setDefaultReadingMode
                )
            }

            // Downloads section
            item {
                SettingsSectionTitle("Downloads")
            }

            item {
                DownloadSettings(
                    onlyOverWifi = uiState.downloadOnlyOverWifi,
                    onOnlyOverWifiChange = viewModel::setDownloadOnlyOverWifi
                )
            }

            // Content section
            item {
                SettingsSectionTitle("Content")
            }

            item {
                ContentSettings(
                    showNsfw = uiState.showNsfw,
                    onShowNsfwChange = viewModel::setShowNsfw
                )
            }

            // Trackers section
            item {
                SettingsSectionTitle("Trackers")
            }

            item {
                ListItem(
                    headlineContent = { Text("Tracker Services") },
                    supportingContent = { Text("Manage AniList, MyAnimeList, etc.") },
                    leadingContent = {
                        Icon(Icons.Default.Sync, contentDescription = null)
                    },
                    trailingContent = {
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    },
                    modifier = Modifier.clickable { navController.navigate("trackers") }
                )
            }

            // Backup section
            item {
                SettingsSectionTitle("Backup")
            }

            item {
                BackupSettings(
                    onBackupClick = viewModel::createBackup,
                    onRestoreClick = viewModel::restoreBackup
                )
            }

            // About section
            item {
                SettingsSectionTitle("About")
            }

            item {
                AboutSettings()
            }
        }
    }
}

@Composable
fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun ThemeSetting(
    currentTheme: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ListItem(
        headlineContent = { Text("Theme") },
        supportingContent = { Text(currentTheme.name) },
        leadingContent = {
            Icon(Icons.Default.DarkMode, contentDescription = null)
        },
        trailingContent = {
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        },
        modifier = Modifier.clickable { expanded = true }
    )

    DropdownMenu(
        expanded = expanded,
        onDismissRequest = { expanded = false }
    ) {
        ThemeMode.values().forEach { theme ->
            DropdownMenuItem(
                text = { Text(theme.name) },
                onClick = {
                    onThemeChange(theme)
                    expanded = false
                }
            )
        }
    }
}

@Composable
fun LanguageSettings(
    enabledLanguages: Set<String>,
    onLanguagesChange: (Set<String>) -> Unit
) {
    val allLanguages = mapOf(
        "en" to "English",
        "ja" to "Japanese",
        "ko" to "Korean",
        "zh" to "Chinese",
        "fr" to "French",
        "de" to "German",
        "it" to "Italian",
        "es" to "Spanish",
        "pt" to "Portuguese",
        "ru" to "Russian",
        "ar" to "Arabic",
        "hi" to "Hindi",
        "id" to "Indonesian",
        "vi" to "Vietnamese",
        "th" to "Thai",
        "tr" to "Turkish",
        "pl" to "Polish"
    )

    var showDialog by remember { mutableStateOf(false) }

    ListItem(
        headlineContent = { Text("Enabled Languages") },
        supportingContent = { 
            Text("${enabledLanguages.size} languages selected") 
        },
        leadingContent = {
            Icon(Icons.Default.Language, contentDescription = null)
        },
        trailingContent = {
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        },
        modifier = Modifier.clickable { showDialog = true }
    )

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Select Languages") },
            text = {
                Column {
                    allLanguages.forEach { (code, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newSet = enabledLanguages.toMutableSet()
                                    if (code in newSet) {
                                        newSet.remove(code)
                                    } else {
                                        newSet.add(code)
                                    }
                                    onLanguagesChange(newSet)
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(name)
                            Checkbox(
                                checked = code in enabledLanguages,
                                onCheckedChange = null
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
fun LibrarySettings(
    columnsPortrait: Int,
    columnsLandscape: Int,
    onColumnsPortraitChange: (Int) -> Unit,
    onColumnsLandscapeChange: (Int) -> Unit
) {
    ListItem(
        headlineContent = { Text("Grid Columns (Portrait)") },
        supportingContent = { Text(columnsPortrait.toString()) },
        leadingContent = {
            Icon(Icons.Default.GridView, contentDescription = null)
        }
    )

    Slider(
        value = columnsPortrait.toFloat(),
        onValueChange = { onColumnsPortraitChange(it.toInt()) },
        valueRange = 2f..6f,
        steps = 3,
        modifier = Modifier.padding(horizontal = 16.dp)
    )

    ListItem(
        headlineContent = { Text("Grid Columns (Landscape)") },
        supportingContent = { Text(columnsLandscape.toString()) },
        leadingContent = {
            Icon(Icons.Default.GridView, contentDescription = null)
        }
    )

    Slider(
        value = columnsLandscape.toFloat(),
        onValueChange = { onColumnsLandscapeChange(it.toInt()) },
        valueRange = 4f..10f,
        steps = 5,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
fun PlayerSettings(
    doubleTapSeekDuration: Int,
    onDoubleTapSeekChange: (Int) -> Unit
) {
    ListItem(
        headlineContent = { Text("Double Tap Seek Duration") },
        supportingContent = { Text("$doubleTapSeekDuration seconds") },
        leadingContent = {
            Icon(Icons.Default.Timer, contentDescription = null)
        }
    )

    Slider(
        value = doubleTapSeekDuration.toFloat(),
        onValueChange = { onDoubleTapSeekChange(it.toInt()) },
        valueRange = 5f..30f,
        steps = 4,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
fun ReaderSettings(
    defaultReadingMode: Int,
    onReadingModeChange: (Int) -> Unit
) {
    val readingModes = listOf(
        "Default",
        "Left to Right",
        "Right to Left",
        "Vertical",
        "Webtoon",
        "Continuous Vertical"
    )

    var expanded by remember { mutableStateOf(false) }

    ListItem(
        headlineContent = { Text("Default Reading Mode") },
        supportingContent = { Text(readingModes.getOrElse(defaultReadingMode) { "Default" }) },
        leadingContent = {
            Icon(Icons.Default.MenuBook, contentDescription = null)
        },
        trailingContent = {
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        },
        modifier = Modifier.clickable { expanded = true }
    )

    DropdownMenu(
        expanded = expanded,
        onDismissRequest = { expanded = false }
    ) {
        readingModes.forEachIndexed { index, mode ->
            DropdownMenuItem(
                text = { Text(mode) },
                onClick = {
                    onReadingModeChange(index)
                    expanded = false
                }
            )
        }
    }
}

@Composable
fun DownloadSettings(
    onlyOverWifi: Boolean,
    onOnlyOverWifiChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text("Download only over Wi-Fi") },
        supportingContent = { Text("Save mobile data") },
        leadingContent = {
            Icon(Icons.Default.Wifi, contentDescription = null)
        },
        trailingContent = {
            Switch(
                checked = onlyOverWifi,
                onCheckedChange = onOnlyOverWifiChange
            )
        }
    )
}

@Composable
fun ContentSettings(
    showNsfw: Boolean,
    onShowNsfwChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text("Show NSFW content") },
        supportingContent = { Text("Display adult content in sources") },
        leadingContent = {
            Icon(Icons.Default.Warning, contentDescription = null)
        },
        trailingContent = {
            Switch(
                checked = showNsfw,
                onCheckedChange = onShowNsfwChange
            )
        }
    )
}

@Composable
fun BackupSettings(
    onBackupClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text("Create Backup") },
        supportingContent = { Text("Backup your library and settings") },
        leadingContent = {
            Icon(Icons.Default.Backup, contentDescription = null)
        },
        modifier = Modifier.clickable(onClick = onBackupClick)
    )

    ListItem(
        headlineContent = { Text("Restore Backup") },
        supportingContent = { Text("Restore from a backup file") },
        leadingContent = {
            Icon(Icons.Default.Restore, contentDescription = null)
        },
        modifier = Modifier.clickable(onClick = onRestoreClick)
    )
}

@Composable
fun AboutSettings() {
    ListItem(
        headlineContent = { Text("Version") },
        supportingContent = { Text("1.0.0") },
        leadingContent = {
            Icon(Icons.Default.Info, contentDescription = null)
        }
    )

    ListItem(
        headlineContent = { Text("GitHub") },
        supportingContent = { Text("github.com/anienjoy/anienjoy") },
        leadingContent = {
            Icon(Icons.Default.Code, contentDescription = null)
        }
    )

    ListItem(
        headlineContent = { Text("License") },
        supportingContent = { Text("Apache License 2.0") },
        leadingContent = {
            Icon(Icons.Default.Description, contentDescription = null)
        }
    )
}
