package com.anienjoy.data.database.dao

import androidx.paging.PagingSource
import androidx.room.*
import com.anienjoy.data.database.entity.NovelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NovelDao {

    @Query("SELECT * FROM novels WHERE favorite = 1 ORDER BY dateAdded DESC")
    fun getFavoriteNovels(): Flow<List<NovelEntity>>

    @Query("SELECT * FROM novels WHERE favorite = 1 ORDER BY dateAdded DESC")
    fun getFavoriteNovelsPaging(): PagingSource<Int, NovelEntity>

    @Query("SELECT * FROM novels WHERE id = :id")
    suspend fun getNovelById(id: Long): NovelEntity?

    @Query("SELECT * FROM novels WHERE source = :source AND url = :url")
    suspend fun getNovelBySourceAndUrl(source: String, url: String): NovelEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(novel: NovelEntity): Long

    @Update
    suspend fun update(novel: NovelEntity)

    @Delete
    suspend fun delete(novel: NovelEntity)

    @Query("UPDATE novels SET favorite = :favorite WHERE id = :novelId")
    suspend fun updateFavorite(novelId: Long, favorite: Boolean)

    @Query("UPDATE novels SET thumbnailUrl = :thumbnailUrl WHERE id = :novelId")
    suspend fun updateThumbnail(novelId: Long, thumbnailUrl: String?)

    @Query("SELECT EXISTS(SELECT 1 FROM novels WHERE source = :source AND url = :url AND favorite = 1)")
    suspend fun isNovelFavorite(source: String, url: String): Boolean

    @Query("SELECT * FROM novels WHERE favorite = 1 AND title LIKE '%' || :query || '%'")
    fun searchFavoriteNovels(query: String): Flow<List<NovelEntity>>

    @Query("SELECT COUNT(*) FROM novels WHERE favorite = 1")
    fun getFavoriteNovelsCount(): Flow<Int>
}
