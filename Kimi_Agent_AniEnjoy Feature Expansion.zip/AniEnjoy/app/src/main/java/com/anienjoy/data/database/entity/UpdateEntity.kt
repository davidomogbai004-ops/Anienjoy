package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "updates",
    indices = [
        Index(value = ["contentId", "contentType"], unique = true)
    ]
)
data class UpdateEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentId: Long,
    val contentType: String, // ANIME, MANGA, NOVEL
    val title: String,
    val thumbnailUrl: String? = null,
    val updateType: String, // NEW_EPISODE, NEW_CHAPTER, NEW_VERSION
    val updateInfo: String, // e.g., "Episode 12", "Chapter 45"
    val source: String,
    val dateFetched: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
