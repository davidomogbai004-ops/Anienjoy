package com.anienjoy.presentation.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.tracker.TrackerManager
import com.anienjoy.data.tracker.TrackerService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TrackerSettingsViewModel @Inject constructor(
    private val trackerManager: TrackerManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(TrackerSettingsUiState())
    val uiState: StateFlow<TrackerSettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                trackerManager.activeTrackers,
                trackerManager.syncEnabled
            ) { activeTrackers, syncEnabled ->
                val allTrackers = trackerManager.getAllTrackers()
                val loginStatus = allTrackers.associate { 
                    it.name to activeTrackers.contains(it)
                }
                
                TrackerSettingsUiState(
                    trackers = allTrackers,
                    loginStatus = loginStatus,
                    syncEnabled = syncEnabled
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun setSyncEnabled(enabled: Boolean) {
        trackerManager.setSyncEnabled(enabled)
    }

    fun login(trackerName: String) {
        viewModelScope.launch {
            // Open OAuth login flow
            // This would typically open a web browser or WebView
            // For now, we'll just trigger the login process
            val tracker = trackerManager.getAllTrackers().find { it.name == trackerName }
            tracker?.let {
                // Show login dialog or open browser
                // Implementation depends on OAuth flow
            }
        }
    }

    fun logout(trackerName: String) {
        viewModelScope.launch {
            when (trackerName) {
                "AniList" -> trackerManager.anilist.logout()
                "MyAnimeList" -> trackerManager.myanimelist.logout()
            }
            trackerManager.refreshActiveTrackers()
        }
    }

    fun refreshTrackers() {
        trackerManager.refreshActiveTrackers()
    }
}

data class TrackerSettingsUiState(
    val trackers: List<TrackerService> = emptyList(),
    val loginStatus: Map<String, Boolean> = emptyMap(),
    val syncEnabled: Boolean = true
)
