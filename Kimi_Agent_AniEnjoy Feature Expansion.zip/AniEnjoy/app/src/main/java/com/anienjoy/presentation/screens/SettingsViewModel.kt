package com.anienjoy.presentation.screens

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.backup.BackupManager
import com.anienjoy.data.preferences.SettingsPreferences
import com.anienjoy.data.preferences.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsPreferences: SettingsPreferences,
    private val backupManager: BackupManager
) : ViewModel() {

    private val _backupRestoreState = MutableStateFlow<BackupRestoreState?>(null)
    val backupRestoreState: StateFlow<BackupRestoreState?> = _backupRestoreState.asStateFlow()

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                settingsPreferences.themeMode,
                settingsPreferences.enabledLanguages,
                settingsPreferences.libraryColumnsPortrait,
                settingsPreferences.libraryColumnsLandscape,
                settingsPreferences.doubleTapSeekDuration,
                settingsPreferences.defaultReadingMode,
                settingsPreferences.downloadOnlyOverWifi,
                settingsPreferences.showNsfw
            ) { values ->
                SettingsUiState(
                    themeMode = values[0] as ThemeMode,
                    enabledLanguages = values[1] as Set<String>,
                    libraryColumnsPortrait = values[2] as Int,
                    libraryColumnsLandscape = values[3] as Int,
                    doubleTapSeekDuration = values[4] as Int,
                    defaultReadingMode = values[5] as Int,
                    downloadOnlyOverWifi = values[6] as Boolean,
                    showNsfw = values[7] as Boolean
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            settingsPreferences.setThemeMode(mode)
        }
    }

    fun setEnabledLanguages(languages: Set<String>) {
        viewModelScope.launch {
            settingsPreferences.setEnabledLanguages(languages)
        }
    }

    fun setLibraryColumnsPortrait(columns: Int) {
        viewModelScope.launch {
            settingsPreferences.setLibraryColumnsPortrait(columns)
        }
    }

    fun setLibraryColumnsLandscape(columns: Int) {
        viewModelScope.launch {
            settingsPreferences.setLibraryColumnsLandscape(columns)
        }
    }

    fun setDoubleTapSeekDuration(seconds: Int) {
        viewModelScope.launch {
            settingsPreferences.setDoubleTapSeekDuration(seconds)
        }
    }

    fun setDefaultReadingMode(mode: Int) {
        viewModelScope.launch {
            settingsPreferences.setDefaultReadingMode(mode)
        }
    }

    fun setDownloadOnlyOverWifi(onlyWifi: Boolean) {
        viewModelScope.launch {
            settingsPreferences.setDownloadOnlyOverWifi(onlyWifi)
        }
    }

    fun setShowNsfw(show: Boolean) {
        viewModelScope.launch {
            settingsPreferences.setShowNsfw(show)
        }
    }

    fun createBackup(uri: Uri) {
        viewModelScope.launch {
            _backupRestoreState.value = BackupRestoreState.Loading
            
            backupManager.createBackup(uri)
                .onSuccess { message ->
                    _backupRestoreState.value = BackupRestoreState.Success(message)
                }
                .onFailure { error ->
                    _backupRestoreState.value = BackupRestoreState.Error(error.message ?: "Backup failed")
                }
        }
    }

    fun restoreBackup(uri: Uri) {
        viewModelScope.launch {
            _backupRestoreState.value = BackupRestoreState.Loading
            
            backupManager.restoreBackup(uri)
                .onSuccess { message ->
                    _backupRestoreState.value = BackupRestoreState.Success(message)
                }
                .onFailure { error ->
                    _backupRestoreState.value = BackupRestoreState.Error(error.message ?: "Restore failed")
                }
        }
    }

    fun clearBackupRestoreState() {
        _backupRestoreState.value = null
    }
}

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val enabledLanguages: Set<String> = emptySet(),
    val libraryColumnsPortrait: Int = 3,
    val libraryColumnsLandscape: Int = 5,
    val doubleTapSeekDuration: Int = 10,
    val defaultReadingMode: Int = 0,
    val downloadOnlyOverWifi: Boolean = true,
    val showNsfw: Boolean = false
)

sealed class BackupRestoreState {
    object Loading : BackupRestoreState()
    data class Success(val message: String) : BackupRestoreState()
    data class Error(val message: String) : BackupRestoreState()
}
