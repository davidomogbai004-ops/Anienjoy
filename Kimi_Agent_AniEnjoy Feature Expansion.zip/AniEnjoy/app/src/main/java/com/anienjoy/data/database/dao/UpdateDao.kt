package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.UpdateEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UpdateDao {

    @Query("SELECT * FROM updates ORDER BY dateFetched DESC")
    fun getAllUpdates(): Flow<List<UpdateEntity>>

    @Query("SELECT * FROM updates WHERE isRead = 0 ORDER BY dateFetched DESC")
    fun getUnreadUpdates(): Flow<List<UpdateEntity>>

    @Query("SELECT * FROM updates WHERE contentType = :contentType ORDER BY dateFetched DESC")
    fun getUpdatesByType(contentType: String): Flow<List<UpdateEntity>>

    @Query("SELECT COUNT(*) FROM updates WHERE isRead = 0")
    fun getUnreadUpdateCount(): Flow<Int>

    @Query("SELECT * FROM updates WHERE contentId = :contentId AND contentType = :contentType")
    suspend fun getUpdateForContent(contentId: Long, contentType: String): UpdateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUpdate(update: UpdateEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUpdates(updates: List<UpdateEntity>)

    @Update
    suspend fun updateUpdate(update: UpdateEntity)

    @Query("UPDATE updates SET isRead = 1 WHERE id = :updateId")
    suspend fun markAsRead(updateId: Long)

    @Query("UPDATE updates SET isRead = 1")
    suspend fun markAllAsRead()

    @Delete
    suspend fun deleteUpdate(update: UpdateEntity)

    @Query("DELETE FROM updates WHERE dateFetched < :timestamp")
    suspend fun deleteOldUpdates(timestamp: Long)

    @Query("DELETE FROM updates")
    suspend fun deleteAllUpdates()
}
