package com.anienjoy.presentation.screens.details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.NovelChapterEntity
import com.anienjoy.data.database.entity.NovelEntity
import com.anienjoy.domain.repository.NovelRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NovelDetailsViewModel @Inject constructor(
    private val novelRepository: NovelRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<NovelDetailsUiState>(NovelDetailsUiState.Loading)
    val uiState: StateFlow<NovelDetailsUiState> = _uiState.asStateFlow()

    private var currentNovelId: Long? = null

    fun loadNovel(novelId: Long) {
        currentNovelId = novelId
        viewModelScope.launch {
            _uiState.value = NovelDetailsUiState.Loading

            try {
                val novel = novelRepository.getNovelById(novelId)
                if (novel != null) {
                    novelRepository.getChaptersByNovelId(novelId)
                        .collect { chapters ->
                            _uiState.value = NovelDetailsUiState.Success(
                                novel = novel,
                                chapters = chapters,
                                isFavorite = novel.favorite
                            )
                        }
                } else {
                    _uiState.value = NovelDetailsUiState.Error("Novel not found")
                }
            } catch (e: Exception) {
                _uiState.value = NovelDetailsUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            val state = _uiState.value as? NovelDetailsUiState.Success ?: return@launch
            val newFavoriteState = !state.isFavorite
            novelRepository.updateFavorite(state.novel.id, newFavoriteState)
            _uiState.value = state.copy(isFavorite = newFavoriteState)
        }
    }

    fun refreshChapters() {
        viewModelScope.launch {
            // Implementation to refresh chapters from source
        }
    }

    fun updateChapterRead(chapterId: Long, read: Boolean) {
        viewModelScope.launch {
            novelRepository.updateChapterRead(chapterId, read)
        }
    }

    fun updateLastReadPosition(chapterId: Long, position: Int) {
        viewModelScope.launch {
            novelRepository.updateLastReadPosition(chapterId, position)
        }
    }
}

sealed class NovelDetailsUiState {
    object Loading : NovelDetailsUiState()
    data class Success(
        val novel: NovelEntity,
        val chapters: List<NovelChapterEntity>,
        val isFavorite: Boolean
    ) : NovelDetailsUiState()
    data class Error(val message: String) : NovelDetailsUiState()
}
