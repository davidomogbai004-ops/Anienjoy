package com.anienjoy.data.repository

import com.anienjoy.data.database.dao.CategoryDao
import com.anienjoy.data.database.entity.*
import com.anienjoy.domain.repository.CategoryRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CategoryRepositoryImpl @Inject constructor(
    private val categoryDao: CategoryDao
) : CategoryRepository {

    override fun getAllCategories(): Flow<List<CategoryEntity>> {
        return categoryDao.getAllCategories()
    }

    override suspend fun getAllCategoriesSync(): List<CategoryEntity> {
        return categoryDao.getAllCategoriesSync()
    }

    override suspend fun getCategoryById(id: Int): CategoryEntity? {
        return categoryDao.getCategoryById(id)
    }

    override suspend fun insertCategory(category: CategoryEntity): Long {
        return categoryDao.insert(category)
    }

    override suspend fun updateCategory(category: CategoryEntity) {
        categoryDao.update(category)
    }

    override suspend fun deleteCategory(category: CategoryEntity) {
        categoryDao.delete(category)
    }

    override suspend fun getMaxOrder(): Int {
        return categoryDao.getMaxOrder() ?: 0
    }

    // Anime categories
    override suspend fun getAnimeCategoryIds(animeId: Long): List<Int> {
        return categoryDao.getAnimeCategoryIds(animeId)
    }

    override suspend fun addAnimeToCategory(animeId: Long, categoryId: Int) {
        categoryDao.insertAnimeCategory(AnimeCategoryEntity(animeId, categoryId))
    }

    override suspend fun removeAnimeFromCategory(animeId: Long, categoryId: Int) {
        categoryDao.deleteAnimeCategory(AnimeCategoryEntity(animeId, categoryId))
    }

    override suspend fun removeAnimeFromAllCategories(animeId: Long) {
        categoryDao.deleteAllAnimeCategories(animeId)
    }

    // Manga categories
    override suspend fun getMangaCategoryIds(mangaId: Long): List<Int> {
        return categoryDao.getMangaCategoryIds(mangaId)
    }

    override suspend fun addMangaToCategory(mangaId: Long, categoryId: Int) {
        categoryDao.insertMangaCategory(MangaCategoryEntity(mangaId, categoryId))
    }

    override suspend fun removeMangaFromCategory(mangaId: Long, categoryId: Int) {
        categoryDao.deleteMangaCategory(MangaCategoryEntity(mangaId, categoryId))
    }

    override suspend fun removeMangaFromAllCategories(mangaId: Long) {
        categoryDao.deleteAllMangaCategories(mangaId)
    }

    // Novel categories
    override suspend fun getNovelCategoryIds(novelId: Long): List<Int> {
        return categoryDao.getNovelCategoryIds(novelId)
    }

    override suspend fun addNovelToCategory(novelId: Long, categoryId: Int) {
        categoryDao.insertNovelCategory(NovelCategoryEntity(novelId, categoryId))
    }

    override suspend fun removeNovelFromCategory(novelId: Long, categoryId: Int) {
        categoryDao.deleteNovelCategory(NovelCategoryEntity(novelId, categoryId))
    }

    override suspend fun removeNovelFromAllCategories(novelId: Long) {
        categoryDao.deleteAllNovelCategories(novelId)
    }
}
