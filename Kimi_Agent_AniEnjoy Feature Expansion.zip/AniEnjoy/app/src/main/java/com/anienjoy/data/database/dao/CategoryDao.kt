package com.anienjoy.data.database.dao

import androidx.room.*
import com.anienjoy.data.database.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {

    @Query("SELECT * FROM categories ORDER BY `order` ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories ORDER BY `order` ASC")
    suspend fun getAllCategoriesSync(): List<CategoryEntity>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getCategoryById(id: Int): CategoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity): Long

    @Update
    suspend fun update(category: CategoryEntity)

    @Delete
    suspend fun delete(category: CategoryEntity)

    @Query("SELECT MAX(`order`) FROM categories")
    suspend fun getMaxOrder(): Int?

    // Anime categories
    @Query("SELECT categoryId FROM anime_categories WHERE animeId = :animeId")
    suspend fun getAnimeCategoryIds(animeId: Long): List<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimeCategory(animeCategory: AnimeCategoryEntity)

    @Delete
    suspend fun deleteAnimeCategory(animeCategory: AnimeCategoryEntity)

    @Query("DELETE FROM anime_categories WHERE animeId = :animeId")
    suspend fun deleteAllAnimeCategories(animeId: Long)

    // Manga categories
    @Query("SELECT categoryId FROM manga_categories WHERE mangaId = :mangaId")
    suspend fun getMangaCategoryIds(mangaId: Long): List<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMangaCategory(mangaCategory: MangaCategoryEntity)

    @Delete
    suspend fun deleteMangaCategory(mangaCategory: MangaCategoryEntity)

    @Query("DELETE FROM manga_categories WHERE mangaId = :mangaId")
    suspend fun deleteAllMangaCategories(mangaId: Long)

    // Novel categories
    @Query("SELECT categoryId FROM novel_categories WHERE novelId = :novelId")
    suspend fun getNovelCategoryIds(novelId: Long): List<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNovelCategory(novelCategory: NovelCategoryEntity)

    @Delete
    suspend fun deleteNovelCategory(novelCategory: NovelCategoryEntity)

    @Query("DELETE FROM novel_categories WHERE novelId = :novelId")
    suspend fun deleteAllNovelCategories(novelId: Long)
}
