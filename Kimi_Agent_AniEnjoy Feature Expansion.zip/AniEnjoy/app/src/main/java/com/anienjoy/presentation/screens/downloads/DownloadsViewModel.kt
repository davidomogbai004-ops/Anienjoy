package com.anienjoy.presentation.screens.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.DownloadEntity
import com.anienjoy.data.download.DownloadManager
import com.anienjoy.domain.repository.DownloadRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloadRepository: DownloadRepository,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(DownloadsUiState())
    val uiState: StateFlow<DownloadsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                downloadRepository.getAllDownloads(),
                downloadRepository.getActiveDownloadCount(),
                downloadRepository.getPendingDownloadCount(),
                downloadRepository.getCompletedDownloadCount()
            ) { downloads, active, pending, completed ->
                DownloadsUiState(
                    downloads = downloads,
                    activeCount = active,
                    pendingCount = pending,
                    completedCount = completed
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun pauseDownload(downloadId: Long) {
        downloadManager.pauseDownload(downloadId)
    }

    fun resumeDownload(downloadId: Long) {
        downloadManager.resumeDownload(downloadId)
    }

    fun cancelDownload(downloadId: Long) {
        downloadManager.cancelDownload(downloadId)
    }

    fun retryDownload(downloadId: Long) {
        downloadManager.retryDownload(downloadId)
    }

    fun deleteDownload(downloadId: Long) {
        downloadManager.deleteDownload(downloadId)
    }

    fun clearCompletedDownloads() {
        viewModelScope.launch {
            downloadRepository.deleteCompletedDownloads()
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            downloadRepository.deleteAllDownloads()
        }
    }
}

data class DownloadsUiState(
    val downloads: List<DownloadEntity> = emptyList(),
    val activeCount: Int = 0,
    val pendingCount: Int = 0,
    val completedCount: Int = 0
)
