package com.anienjoy.presentation.screens.details

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.anienjoy.data.database.entity.EpisodeEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimeDetailsScreen(
    navController: NavController,
    animeId: Long?,
    viewModel: AnimeDetailsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(animeId) {
        animeId?.let { viewModel.loadAnime(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = (uiState as? AnimeDetailsUiState.Success)?.anime?.title ?: "Anime Details",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    val state = uiState as? AnimeDetailsUiState.Success
                    state?.let {
                        IconButton(onClick = { viewModel.toggleFavorite() }) {
                            Icon(
                                imageVector = if (it.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite"
                            )
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = uiState) {
                is AnimeDetailsUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is AnimeDetailsUiState.Success -> {
                    AnimeDetailsContent(
                        state = state,
                        onEpisodeClick = { episode ->
                            navController.navigate("player/${episode.id}")
                        },
                        onRefresh = { viewModel.refreshEpisodes() }
                    )
                }
                is AnimeDetailsUiState.Error -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Error: ${state.message}")
                    }
                }
            }
        }
    }
}

@Composable
fun AnimeDetailsContent(
    state: AnimeDetailsUiState.Success,
    onEpisodeClick: (EpisodeEntity) -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn {
        // Header with cover and info
        item {
            AnimeHeader(state)
        }

        // Description
        item {
            state.anime.description?.let { description ->
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        // Genres
        item {
            if (state.anime.genre.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    state.anime.genre.split(",").forEach { genre ->
                        AssistChip(
                            onClick = { },
                            label = { Text(genre.trim()) }
                        )
                    }
                }
            }
        }

        // Episodes section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Episodes (${state.episodes.size})",
                    style = MaterialTheme.typography.titleMedium
                )
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                }
            }
        }

        items(state.episodes) { episode ->
            EpisodeListItem(
                episode = episode,
                onClick = { onEpisodeClick(episode) }
            )
        }
    }
}

@Composable
fun AnimeHeader(state: AnimeDetailsUiState.Success) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Cover image
        AsyncImage(
            model = state.anime.thumbnailUrl,
            contentDescription = null,
            modifier = Modifier
                .width(120.dp)
                .aspectRatio(2f / 3f),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.width(16.dp))

        // Info
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = state.anime.title,
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Status
            val statusText = when (state.anime.status) {
                1 -> "Ongoing"
                2 -> "Completed"
                3 -> "Licensed"
                4 -> "Publishing Finished"
                5 -> "Cancelled"
                6 -> "On Hiatus"
                else -> "Unknown"
            }
            Text(
                text = "Status: $statusText",
                style = MaterialTheme.typography.bodyMedium
            )

            // Author
            state.anime.author?.let {
                Text(
                    text = "Author: $it",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Source
            Text(
                text = "Source: ${state.anime.source}",
                style = MaterialTheme.typography.bodyMedium
            )

            // Episode count
            Text(
                text = "Episodes: ${state.episodes.size}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun EpisodeListItem(
    episode: EpisodeEntity,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(episode.name) },
        supportingContent = {
            Row {
                if (episode.seen) {
                    Text(
                        text = "Watched",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (episode.bookmark) {
                    Text(
                        text = if (episode.seen) " • Bookmarked" else "Bookmarked",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        },
        leadingContent = {
            Icon(
                imageVector = if (episode.seen) Icons.Default.CheckCircle else Icons.Default.PlayCircle,
                contentDescription = null,
                tint = if (episode.seen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
        },
        trailingContent = {
            if (episode.lastSecondSeen > 0 && episode.totalSeconds > 0) {
                val progress = (episode.lastSecondSeen * 100 / episode.totalSeconds).toInt()
                Text("$progress%")
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
