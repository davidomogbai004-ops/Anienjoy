package com.anienjoy.presentation.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.anienjoy.data.tracker.TrackerService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackerSettingsScreen(
    navController: NavController,
    viewModel: TrackerSettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trackers") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Sync toggle
            item {
                ListItem(
                    headlineContent = { Text("Auto Sync") },
                    supportingContent = { Text("Automatically sync progress with trackers") },
                    leadingContent = {
                        Icon(Icons.Default.Sync, contentDescription = null)
                    },
                    trailingContent = {
                        Switch(
                            checked = uiState.syncEnabled,
                            onCheckedChange = { viewModel.setSyncEnabled(it) }
                        )
                    }
                )
            }

            item {
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // Tracker list
            items(uiState.trackers.size) { index ->
                val tracker = uiState.trackers[index]
                TrackerItem(
                    tracker = tracker,
                    isLoggedIn = uiState.loginStatus[tracker.name] ?: false,
                    onLogin = { viewModel.login(tracker.name) },
                    onLogout = { viewModel.logout(tracker.name) }
                )
            }

            // Info section
            item {
                Divider(modifier = Modifier.padding(vertical = 8.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "About Trackers",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Trackers allow you to sync your anime and manga progress with external services like AniList and MyAnimeList. Your progress will be automatically updated when you watch episodes or read chapters.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrackerItem(
    tracker: TrackerService,
    isLoggedIn: Boolean,
    onLogin: () -> Unit,
    onLogout: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tracker icon
            AsyncImage(
                model = tracker.iconUrl,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Tracker info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = tracker.name,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = if (isLoggedIn) "Connected" else "Not connected",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isLoggedIn) 
                        MaterialTheme.colorScheme.primary 
                    else 
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Login/Logout button
            if (isLoggedIn) {
                OutlinedButton(onClick = onLogout) {
                    Text("Disconnect")
                }
            } else {
                Button(onClick = onLogin) {
                    Text("Connect")
                }
            }
        }
    }
}
