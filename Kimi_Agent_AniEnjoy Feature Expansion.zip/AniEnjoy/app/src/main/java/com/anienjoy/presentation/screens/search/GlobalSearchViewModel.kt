package com.anienjoy.presentation.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.domain.repository.SourceRepository
import com.anienjoy.extension.api.model.Anime
import com.anienjoy.extension.api.model.Manga
import com.anienjoy.extension.api.model.Novel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class GlobalSearchViewModel @Inject constructor(
    private val sourceRepository: SourceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Initial)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null

    fun search(query: String) {
        if (query.isBlank()) {
            _uiState.value = SearchUiState.Initial
            return
        }

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _uiState.value = SearchUiState.Loading

            try {
                val results = SearchResults()

                // Search anime sources
                sourceRepository.animeSources.value.forEach { source ->
                    try {
                        val page = withTimeoutOrNull(5000) {
                            source.searchAnime(query, 1)
                        }
                        page?.animes?.let { results.anime.addAll(it) }
                    } catch (e: Exception) {
                        // Ignore source errors
                    }
                }

                // Search manga sources
                sourceRepository.mangaSources.value.forEach { source ->
                    try {
                        val page = withTimeoutOrNull(5000) {
                            source.searchManga(query, 1)
                        }
                        page?.mangas?.let { results.manga.addAll(it) }
                    } catch (e: Exception) {
                        // Ignore source errors
                    }
                }

                // Search manhwa sources
                sourceRepository.manhwaSources.value.forEach { source ->
                    try {
                        val page = withTimeoutOrNull(5000) {
                            source.searchManga(query, 1)
                        }
                        page?.mangas?.let { results.manhwa.addAll(it) }
                    } catch (e: Exception) {
                        // Ignore source errors
                    }
                }

                // Search manhua sources
                sourceRepository.manhuaSources.value.forEach { source ->
                    try {
                        val page = withTimeoutOrNull(5000) {
                            source.searchManga(query, 1)
                        }
                        page?.mangas?.let { results.manhua.addAll(it) }
                    } catch (e: Exception) {
                        // Ignore source errors
                    }
                }

                // Search novel sources
                sourceRepository.novelSources.value.forEach { source ->
                    try {
                        val page = withTimeoutOrNull(5000) {
                            source.searchNovels(query, 1)
                        }
                        page?.novels?.let { results.novels.addAll(it) }
                    } catch (e: Exception) {
                        // Ignore source errors
                    }
                }

                _uiState.value = SearchUiState.Success(results)
            } catch (e: Exception) {
                _uiState.value = SearchUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        _uiState.value = SearchUiState.Initial
    }

    override fun onCleared() {
        super.onCleared()
        searchJob?.cancel()
    }
}

sealed class SearchUiState {
    object Initial : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val results: SearchResults) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}

data class SearchResults(
    val anime: MutableList<Anime> = mutableListOf(),
    val manga: MutableList<Manga> = mutableListOf(),
    val manhwa: MutableList<Manga> = mutableListOf(),
    val manhua: MutableList<Manga> = mutableListOf(),
    val novels: MutableList<Novel> = mutableListOf()
) {
    fun isEmpty(): Boolean {
        return anime.isEmpty() && manga.isEmpty() && manhwa.isEmpty() && 
               manhua.isEmpty() && novels.isEmpty()
    }
}
