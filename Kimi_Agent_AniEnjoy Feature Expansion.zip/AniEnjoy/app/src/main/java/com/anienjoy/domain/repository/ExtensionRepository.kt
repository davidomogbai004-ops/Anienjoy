package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.ExtensionEntity
import com.anienjoy.data.database.entity.ExtensionRepoEntity
import com.anienjoy.extension.api.ExtensionInfo
import com.anienjoy.extension.api.loader.ExtensionLoader
import kotlinx.coroutines.flow.Flow

interface ExtensionRepository {
    fun getInstalledExtensions(): Flow<List<ExtensionEntity>>
    fun getExtensionsWithUpdate(): Flow<List<ExtensionEntity>>
    fun getExtensionRepos(): Flow<List<ExtensionRepoEntity>>
    fun getEnabledRepos(): Flow<List<ExtensionRepoEntity>>
    suspend fun addRepo(repo: ExtensionRepoEntity)
    suspend fun removeRepo(repo: ExtensionRepoEntity)
    suspend fun setRepoEnabled(repoId: Long, enabled: Boolean)
    suspend fun loadInstalledExtensions(): List<ExtensionLoader.LoadResult>
    suspend fun fetchExtensionsFromRepo(repoUrl: String): List<ExtensionInfo>
    suspend fun installExtension(extensionInfo: ExtensionInfo): Boolean
    suspend fun uninstallExtension(pkgName: String)
    suspend fun checkForUpdates()
    suspend fun saveExtensionEntity(extension: ExtensionEntity)
    suspend fun getExtensionByPkgName(pkgName: String): ExtensionEntity?
}
