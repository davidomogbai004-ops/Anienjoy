package com.anienjoy.presentation.screens.details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.ChapterEntity
import com.anienjoy.data.database.entity.MangaEntity
import com.anienjoy.domain.repository.MangaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MangaDetailsViewModel @Inject constructor(
    private val mangaRepository: MangaRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<MangaDetailsUiState>(MangaDetailsUiState.Loading)
    val uiState: StateFlow<MangaDetailsUiState> = _uiState.asStateFlow()

    private var currentMangaId: Long? = null

    fun loadManga(mangaId: Long) {
        currentMangaId = mangaId
        viewModelScope.launch {
            _uiState.value = MangaDetailsUiState.Loading

            try {
                val manga = mangaRepository.getMangaById(mangaId)
                if (manga != null) {
                    mangaRepository.getChaptersByMangaId(mangaId)
                        .collect { chapters ->
                            _uiState.value = MangaDetailsUiState.Success(
                                manga = manga,
                                chapters = chapters,
                                isFavorite = manga.favorite
                            )
                        }
                } else {
                    _uiState.value = MangaDetailsUiState.Error("Manga not found")
                }
            } catch (e: Exception) {
                _uiState.value = MangaDetailsUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            val state = _uiState.value as? MangaDetailsUiState.Success ?: return@launch
            val newFavoriteState = !state.isFavorite
            mangaRepository.updateFavorite(state.manga.id, newFavoriteState)
            _uiState.value = state.copy(isFavorite = newFavoriteState)
        }
    }

    fun refreshChapters() {
        viewModelScope.launch {
            // Implementation to refresh chapters from source
        }
    }

    fun updateChapterRead(chapterId: Long, read: Boolean) {
        viewModelScope.launch {
            mangaRepository.updateChapterRead(chapterId, read)
        }
    }

    fun updateLastPageRead(chapterId: Long, lastPageRead: Int) {
        viewModelScope.launch {
            mangaRepository.updateLastPageRead(chapterId, lastPageRead)
        }
    }
}

sealed class MangaDetailsUiState {
    object Loading : MangaDetailsUiState()
    data class Success(
        val manga: MangaEntity,
        val chapters: List<ChapterEntity>,
        val isFavorite: Boolean
    ) : MangaDetailsUiState()
    data class Error(val message: String) : MangaDetailsUiState()
}
