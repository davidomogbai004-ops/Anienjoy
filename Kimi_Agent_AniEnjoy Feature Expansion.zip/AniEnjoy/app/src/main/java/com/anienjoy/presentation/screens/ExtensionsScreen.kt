package com.anienjoy.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.anienjoy.data.database.entity.ExtensionRepoEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionsScreen(
    navController: NavController,
    viewModel: ExtensionsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddRepoDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Extensions") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddRepoDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Repository")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Extension repositories section
            Text(
                text = "Extension Repositories",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )

            LazyColumn {
                items(uiState.repos) { repo ->
                    RepoListItem(
                        repo = repo,
                        onToggleEnabled = { viewModel.toggleRepoEnabled(repo.id, !repo.enabled) },
                        onDelete = { viewModel.deleteRepo(repo) }
                    )
                }
            }

            Divider(modifier = Modifier.padding(vertical = 16.dp))

            // Installed extensions section
            Text(
                text = "Installed Extensions",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )

            LazyColumn {
                items(uiState.installedExtensions) { extension ->
                    InstalledExtensionItem(
                        extension = extension,
                        onUninstall = { viewModel.uninstallExtension(extension.pkgName) }
                    )
                }
            }
        }
    }

    if (showAddRepoDialog) {
        AddRepoDialog(
            onDismiss = { showAddRepoDialog = false },
            onAdd = { name, url ->
                viewModel.addRepo(name, url)
                showAddRepoDialog = false
            }
        )
    }
}

@Composable
fun RepoListItem(
    repo: ExtensionRepoEntity,
    onToggleEnabled: () -> Unit,
    onDelete: () -> Unit
) {
    ListItem(
        headlineContent = { Text(repo.name) },
        supportingContent = { Text(repo.url) },
        leadingContent = {
            Icon(
                imageVector = Icons.Default.Storage,
                contentDescription = null
            )
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = repo.enabled,
                    onCheckedChange = { onToggleEnabled() }
                )
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete"
                    )
                }
            }
        }
    )
}

@Composable
fun InstalledExtensionItem(
    extension: com.anienjoy.data.database.entity.ExtensionEntity,
    onUninstall: () -> Unit
) {
    ListItem(
        headlineContent = { Text(extension.name) },
        supportingContent = {
            Text("${extension.version} • ${extension.lang.uppercase()}")
        },
        leadingContent = {
            Icon(
                imageVector = Icons.Default.Extension,
                contentDescription = null
            )
        },
        trailingContent = {
            if (extension.hasUpdate) {
                Button(onClick = { /* Update extension */ }) {
                    Text("Update")
                }
            } else {
                IconButton(onClick = onUninstall) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Uninstall"
                    )
                }
            }
        }
    )
}

@Composable
fun AddRepoDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Repository") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL") },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://example.com/repo/index.min.json") }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onAdd(name, url) },
                enabled = name.isNotBlank() && url.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
