package com.anienjoy.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.anienjoy.presentation.screens.*
import com.anienjoy.presentation.screens.downloads.DownloadsScreen
import com.anienjoy.presentation.screens.settings.TrackerSettingsScreen
import com.anienjoy.presentation.theme.AniEnjoyTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        
        setContent {
            AniEnjoyTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    
                    NavHost(
                        navController = navController,
                        startDestination = "main"
                    ) {
                        composable("main") {
                            MainScreen(navController = navController)
                        }
                        composable("browse") {
                            BrowseScreen(navController = navController)
                        }
                        composable("extensions") {
                            ExtensionsScreen(navController = navController)
                        }
                        composable("settings") {
                            SettingsScreen(navController = navController)
                        }
                        composable("search") {
                            GlobalSearchScreen(navController = navController)
                        }
                        composable("anime_details/{animeId}") { backStackEntry ->
                            val animeId = backStackEntry.arguments?.getString("animeId")?.toLongOrNull()
                            AnimeDetailsScreen(navController = navController, animeId = animeId)
                        }
                        composable("manga_details/{mangaId}") { backStackEntry ->
                            val mangaId = backStackEntry.arguments?.getString("mangaId")?.toLongOrNull()
                            MangaDetailsScreen(navController = navController, mangaId = mangaId)
                        }
                        composable("novel_details/{novelId}") { backStackEntry ->
                            val novelId = backStackEntry.arguments?.getString("novelId")?.toLongOrNull()
                            NovelDetailsScreen(navController = navController, novelId = novelId)
                        }
                        composable("player/{episodeId}") { backStackEntry ->
                            val episodeId = backStackEntry.arguments?.getString("episodeId")?.toLongOrNull()
                            PlayerScreen(navController = navController, episodeId = episodeId)
                        }
                        composable("reader/{chapterId}") { backStackEntry ->
                            val chapterId = backStackEntry.arguments?.getString("chapterId")?.toLongOrNull()
                            ReaderScreen(navController = navController, chapterId = chapterId)
                        }
                        composable("novel_reader/{chapterId}") { backStackEntry ->
                            val chapterId = backStackEntry.arguments?.getString("chapterId")?.toLongOrNull()
                            NovelReaderScreen(navController = navController, chapterId = chapterId)
                        }
                        composable("downloads") {
                            DownloadsScreen(navController = navController)
                        }
                        composable("trackers") {
                            TrackerSettingsScreen(navController = navController)
                        }
                    }
                }
            }
        }
    }
}
