package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "novel_chapters",
    foreignKeys = [
        ForeignKey(
            entity = NovelEntity::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["novelId", "url"], unique = true),
        Index(value = ["novelId"])
    ]
)
data class NovelChapterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val novelId: Long,
    val url: String,
    val name: String,
    val scanlator: String? = null,
    val read: Boolean = false,
    val bookmark: Boolean = false,
    val chapterNumber: Float = -1f,
    val sourceOrder: Int = -1,
    val dateUpload: Long = 0,
    val dateFetch: Long = 0,
    val lastReadPosition: Int = 0
)
