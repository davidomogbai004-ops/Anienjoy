package com.anienjoy.data.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "downloads",
    indices = [
        Index(value = ["contentId", "contentType", "chapterId"], unique = true),
        Index(value = ["status"])
    ]
)
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentId: Long, // Anime/Manga/Novel ID
    val contentType: String, // ANIME, MANGA, NOVEL
    val chapterId: Long?, // Episode/Chapter ID (null for anime)
    val title: String,
    val chapterName: String?,
    val thumbnailUrl: String? = null,
    val source: String,
    val url: String, // URL to download
    val localPath: String? = null, // Local file path after download
    val status: Int = STATUS_PENDING,
    val totalBytes: Long = 0,
    val downloadedBytes: Long = 0,
    val errorMessage: String? = null,
    val priority: Int = 0,
    val dateAdded: Long = System.currentTimeMillis(),
    val dateCompleted: Long? = null
) {
    companion object {
        const val STATUS_PENDING = 0
        const val STATUS_QUEUED = 1
        const val STATUS_DOWNLOADING = 2
        const val STATUS_PAUSED = 3
        const val STATUS_COMPLETED = 4
        const val STATUS_FAILED = 5
        const val STATUS_CANCELLED = 6
    }

    val progress: Float
        get() = if (totalBytes > 0) downloadedBytes.toFloat() / totalBytes else 0f

    val statusText: String
        get() = when (status) {
            STATUS_PENDING -> "Pending"
            STATUS_QUEUED -> "Queued"
            STATUS_DOWNLOADING -> "Downloading"
            STATUS_PAUSED -> "Paused"
            STATUS_COMPLETED -> "Completed"
            STATUS_FAILED -> "Failed"
            STATUS_CANCELLED -> "Cancelled"
            else -> "Unknown"
        }
}
