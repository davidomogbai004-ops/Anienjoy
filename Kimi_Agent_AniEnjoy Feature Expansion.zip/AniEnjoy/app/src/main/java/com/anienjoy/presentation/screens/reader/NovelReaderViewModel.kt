package com.anienjoy.presentation.screens.reader

import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anienjoy.data.database.entity.NovelChapterEntity
import com.anienjoy.domain.repository.NovelRepository
import com.anienjoy.domain.repository.SourceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NovelReaderViewModel @Inject constructor(
    private val novelRepository: NovelRepository,
    private val sourceRepository: SourceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<NovelReaderUiState>(NovelReaderUiState.Loading)
    val uiState: StateFlow<NovelReaderUiState> = _uiState.asStateFlow()

    private var currentChapterId: Long? = null
    private var currentNovelId: Long? = null

    private val _fontSize = MutableStateFlow(18.sp)
    val fontSize: StateFlow<TextUnit> = _fontSize.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun loadChapter(chapterId: Long) {
        currentChapterId = chapterId
        viewModelScope.launch {
            _uiState.value = NovelReaderUiState.Loading

            try {
                val chapter = novelRepository.getChapterById(chapterId)
                if (chapter != null) {
                    currentNovelId = chapter.novelId
                    
                    // Get chapter content from source
                    val source = sourceRepository.getNovelSourceById(chapter.novelId)
                    val content = source?.getChapterContent(
                        com.anienjoy.extension.api.model.NovelChapter(
                            id = chapter.id,
                            novelId = chapter.novelId,
                            url = chapter.url,
                            name = chapter.name
                        )
                    ) ?: "Content not available"

                    // Check for previous/next chapters
                    val allChapters = novelRepository.getChaptersByNovelIdSync(chapter.novelId)
                    val currentIndex = allChapters.indexOfFirst { it.id == chapterId }

                    _uiState.value = NovelReaderUiState.Success(
                        chapter = chapter,
                        content = content,
                        fontSize = _fontSize.value,
                        hasPreviousChapter = currentIndex > 0,
                        hasNextChapter = currentIndex < allChapters.size - 1
                    )

                    // Mark as read
                    novelRepository.updateChapterRead(chapterId, true)
                } else {
                    _uiState.value = NovelReaderUiState.Error("Chapter not found")
                }
            } catch (e: Exception) {
                _uiState.value = NovelReaderUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun saveScrollPosition(position: Int) {
        viewModelScope.launch {
            currentChapterId?.let { chapterId ->
                novelRepository.updateLastReadPosition(chapterId, position)
            }
        }
    }

    fun loadPreviousChapter() {
        viewModelScope.launch {
            val state = _uiState.value as? NovelReaderUiState.Success ?: return@launch
            val allChapters = currentNovelId?.let { novelRepository.getChaptersByNovelIdSync(it) } ?: return@launch
            val currentIndex = allChapters.indexOfFirst { it.id == state.chapter.id }
            
            if (currentIndex > 0) {
                loadChapter(allChapters[currentIndex - 1].id)
            }
        }
    }

    fun loadNextChapter() {
        viewModelScope.launch {
            val state = _uiState.value as? NovelReaderUiState.Success ?: return@launch
            val allChapters = currentNovelId?.let { novelRepository.getChaptersByNovelIdSync(it) } ?: return@launch
            val currentIndex = allChapters.indexOfFirst { it.id == state.chapter.id }
            
            if (currentIndex < allChapters.size - 1) {
                loadChapter(allChapters[currentIndex + 1].id)
            }
        }
    }

    fun increaseFontSize() {
        _fontSize.value = (_fontSize.value.value + 2).sp
        updateFontSize()
    }

    fun decreaseFontSize() {
        if (_fontSize.value.value > 12) {
            _fontSize.value = (_fontSize.value.value - 2).sp
            updateFontSize()
        }
    }

    private fun updateFontSize() {
        val state = _uiState.value as? NovelReaderUiState.Success ?: return
        _uiState.value = state.copy(fontSize = _fontSize.value)
    }

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }
}

sealed class NovelReaderUiState {
    object Loading : NovelReaderUiState()
    data class Success(
        val chapter: NovelChapterEntity,
        val content: String,
        val fontSize: TextUnit,
        val hasPreviousChapter: Boolean,
        val hasNextChapter: Boolean
    ) : NovelReaderUiState()
    data class Error(val message: String) : NovelReaderUiState()
}
