package com.anienjoy.domain.repository

import com.anienjoy.data.database.entity.AnimeEntity
import com.anienjoy.data.database.entity.EpisodeEntity
import kotlinx.coroutines.flow.Flow

interface AnimeRepository {
    fun getFavoriteAnime(): Flow<List<AnimeEntity>>
    fun getFavoriteAnimePaging(): androidx.paging.PagingSource<Int, AnimeEntity>
    suspend fun getAnimeById(id: Long): AnimeEntity?
    suspend fun getAnimeBySourceAndUrl(source: String, url: String): AnimeEntity?
    suspend fun insertAnime(anime: AnimeEntity): Long
    suspend fun updateAnime(anime: AnimeEntity)
    suspend fun deleteAnime(anime: AnimeEntity)
    suspend fun updateFavorite(animeId: Long, favorite: Boolean)
    suspend fun updateThumbnail(animeId: Long, thumbnailUrl: String?)
    suspend fun isAnimeFavorite(source: String, url: String): Boolean
    fun searchFavoriteAnime(query: String): Flow<List<AnimeEntity>>
    fun getFavoriteAnimeCount(): Flow<Int>

    // Episode operations
    fun getEpisodesByAnimeId(animeId: Long): Flow<List<EpisodeEntity>>
    suspend fun getEpisodesByAnimeIdSync(animeId: Long): List<EpisodeEntity>
    suspend fun getEpisodeById(id: Long): EpisodeEntity?
    suspend fun insertEpisode(episode: EpisodeEntity): Long
    suspend fun insertEpisodes(episodes: List<EpisodeEntity>)
    suspend fun updateEpisode(episode: EpisodeEntity)
    suspend fun deleteEpisode(episode: EpisodeEntity)
    suspend fun updateEpisodeSeen(episodeId: Long, seen: Boolean)
    suspend fun updateEpisodeBookmark(episodeId: Long, bookmark: Boolean)
    suspend fun updateEpisodeProgress(episodeId: Long, lastSecondSeen: Long, totalSeconds: Long)
    fun getSeenEpisodeCount(animeId: Long): Flow<Int>
    fun getTotalEpisodeCount(animeId: Long): Flow<Int>
    suspend fun getNextUnseenEpisode(animeId: Long): EpisodeEntity?
    suspend fun deleteAllEpisodesByAnimeId(animeId: Long)
}
