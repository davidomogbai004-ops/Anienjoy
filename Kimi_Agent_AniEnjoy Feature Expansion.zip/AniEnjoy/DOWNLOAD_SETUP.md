# Download Setup Guide

This guide explains how to set up the download functionality for AniEnjoy.

## Quick Links for Users

### 🌐 Website
**URL:** https://anienjoy.app

The website is hosted on GitHub Pages from the `docs/` folder.

### 📱 Direct APK Download
**URL:** https://github.com/anienjoy/anienjoy/releases/latest/download/app-release.apk

### 💻 Download Script
```bash
curl -sSL https://raw.githubusercontent.com/anienjoy/anienjoy/main/download.sh | bash
```

---

## For Developers: Setting Up GitHub Actions

The GitHub Actions workflow (`.github/workflows/build.yml`) automatically builds the APK on every push to the main branch.

### Setup Steps:

1. **Push this repository to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/anienjoy.git
   git push -u origin main
   ```

2. **Enable GitHub Actions**
   - Go to your repository on GitHub
   - Click on "Actions" tab
   - Click "I understand my workflows, go ahead and enable them"

3. **Set up GitHub Pages**
   - Go to Settings > Pages
   - Source: Deploy from a branch
   - Branch: Select "main" and "/docs" folder
   - Click Save
   - Your site will be available at `https://YOUR_USERNAME.github.io/anienjoy`

4. **Configure Custom Domain (Optional)**
   - Add your domain to `docs/CNAME`
   - Configure DNS to point to GitHub Pages

---

## Download Methods

### Method 1: GitHub Releases (Recommended)
The APK is automatically uploaded to GitHub Releases when you push to main.

**User URL:**
```
https://github.com/anienjoy/anienjoy/releases/latest
```

### Method 2: GitHub Pages Website
A beautiful landing page with download button.

**Files:**
- `docs/index.html` - Landing page
- `docs/CNAME` - Custom domain config

### Method 3: Direct Download Script
A bash script that downloads and optionally installs the APK.

**Usage:**
```bash
# Download and run
curl -sSL https://raw.githubusercontent.com/anienjoy/anienjoy/main/download.sh | bash

# Or download script first
wget https://raw.githubusercontent.com/anienjoy/anienjoy/main/download.sh
chmod +x download.sh
./download.sh
```

---

## Build Process

### Automatic Build (GitHub Actions)
Every push to `main` branch triggers:
1. Build Debug APK
2. Build Release APK
3. Upload artifacts
4. Create GitHub Release (if on main branch)

### Manual Build
```bash
# Debug APK
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Release APK (requires signing config)
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release.apk
```

---

## APK Signing (For Release)

To create signed release APKs, add to `app/build.gradle.kts`:

```kotlin
android {
    signingConfigs {
        create("release") {
            storeFile = file("keystore.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD")
            keyAlias = System.getenv("KEY_ALIAS")
            keyPassword = System.getenv("KEY_PASSWORD")
        }
    }
    
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}
```

Add secrets to GitHub:
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`
- `KEYSTORE_BASE64` (base64 encoded keystore)

---

## File Structure

```
AniEnjoy/
├── .github/
│   └── workflows/
│       └── build.yml          # GitHub Actions workflow
├── docs/
│   ├── index.html             # Download website
│   └── CNAME                  # Custom domain
├── download.sh                # Download script
├── README.md                  # Main readme with download badge
├── INSTALL.md                 # Installation instructions
└── DOWNLOAD_SETUP.md          # This file
```

---

## Customization

### Change Download URL
Edit `docs/index.html`:
```javascript
document.getElementById('downloadBtn').href = 'YOUR_CUSTOM_URL';
```

### Change Colors
Edit CSS in `docs/index.html`:
```css
:root {
    --primary-color: #6B4EE6;
    --secondary-color: #9B59B6;
}
```

### Add More Features
The website is a simple HTML file - customize it as needed!

---

## Troubleshooting

### GitHub Actions Not Running
- Check if Actions are enabled in repository settings
- Verify the workflow file syntax
- Check Actions tab for error logs

### GitHub Pages Not Working
- Ensure Pages source is set to `/docs` folder
- Check if `index.html` exists in `docs/`
- Custom domain DNS may take time to propagate

### APK Not Downloading
- Check if releases exist in GitHub Releases
- Verify artifact upload in Actions logs
- Check artifact retention settings

---

## Support

For help with downloads:
- 📧 Email: support@anienjoy.app
- 💬 Discord: https://discord.gg/anienjoy
- 🐛 Issues: https://github.com/anienjoy/anienjoy/issues
