# Installation Guide

## Quick Download

### [📱 Click Here to Download AniEnjoy APK](https://github.com/anienjoy/anienjoy/releases/latest/download/app-release.apk)

---

## Installation Steps

### Step 1: Download the APK
Click the download button above or visit [anienjoy.app](https://anienjoy.app) to download the latest APK file.

### Step 2: Enable Unknown Sources
Before installing, you need to allow installation from unknown sources:

**For Android 8.0+:**
1. Open **Settings**
2. Go to **Apps & Notifications** (or **Applications**)
3. Tap **Special app access** (or **Advanced**)
4. Select **Install unknown apps**
5. Find your browser (Chrome, Firefox, etc.) and enable **Allow from this source**

**For older Android versions:**
1. Open **Settings**
2. Go to **Security**
3. Enable **Unknown sources**

### Step 3: Install the App
1. Open your **Downloads** folder or notification
2. Tap on the downloaded APK file (`anienjoy-v1.0.0.apk`)
3. Tap **Install** when prompted
4. Wait for the installation to complete
5. Tap **Open** to launch AniEnjoy

### Step 4: Initial Setup
1. Grant necessary permissions when prompted
2. Go to **Settings > Extensions**
3. Add extension repositories (default ones are pre-configured)
4. Install your preferred extensions
5. Start browsing and adding content to your library!

---

## Alternative Installation Methods

### Using ADB (For Developers)
```bash
# Connect your device via USB with USB debugging enabled
adb install anienjoy-v1.0.0.apk
```

### Building from Source
```bash
# Clone the repository
git clone https://github.com/anienjoy/anienjoy.git
cd anienjoy

# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Install to connected device
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Troubleshooting

### "App not installed" Error
- Uninstall any previous version of AniEnjoy
- Make sure you have enough storage space
- Try downloading the APK again

### "Parse error" Message
- Your Android version might be too old (requires Android 8.0+)
- The APK file may be corrupted, try downloading again

### App Crashes on Launch
- Clear app data: Settings > Apps > AniEnjoy > Storage > Clear Data
- Reinstall the app
- Check if your device meets the minimum requirements

### Can't Install Extensions
- Make sure you have a stable internet connection
- Check that extension repositories are added in Settings > Extensions
- Try refreshing the extension list

---

## Updating the App

### Automatic Updates
AniEnjoy will notify you when a new version is available. Simply download and install the new APK over the existing installation.

### Manual Update
1. Download the latest APK from the releases page
2. Install it (your data will be preserved)
3. The app will automatically migrate your data

---

## System Requirements

| Requirement | Minimum | Recommended |
|------------|---------|-------------|
| Android Version | 8.0 (API 26) | 10+ (API 29+) |
| RAM | 2 GB | 4 GB+ |
| Storage | 100 MB | 500 MB+ |
| Internet | 2 Mbps | 10 Mbps+ |

---

## Safety & Privacy

✅ **AniEnjoy is safe to use:**
- Open source code - anyone can audit it
- No malware or spyware
- No account required
- Minimal permissions needed

🔒 **Permissions required:**
- **Internet** - For streaming and downloading content
- **Storage** - For downloading episodes/chapters for offline viewing
- **Notification** - For update notifications

---

## Need Help?

- 📖 [Full Documentation](https://github.com/anienjoy/anienjoy/wiki)
- 🐛 [Report Issues](https://github.com/anienjoy/anienjoy/issues)
- 💬 [Join Discord](https://discord.gg/anienjoy)

---

**Enjoy your anime and manga with AniEnjoy! 🎉**
