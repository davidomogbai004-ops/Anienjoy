package com.anienjoy.extension.api.loader

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import com.anienjoy.extension.api.Extension
import com.anienjoy.extension.api.Source
import dalvik.system.PathClassLoader

/**
 * Extension loader for loading extensions from APK files
 */
class ExtensionLoader(private val context: Context) {

    companion object {
        const val EXTENSION_FEATURE = "anienjoy.extension"
        const val METADATA_SOURCE_CLASS = "anienjoy.extension.class"
        const val METADATA_SOURCE_FACTORY = "anienomi.extension.factory"
        const val LIB_VERSION_MIN = 1
        const val LIB_VERSION_MAX = 100
    }

    /**
     * Load all installed extensions
     */
    fun loadExtensions(): List<LoadResult> {
        val extensions = mutableListOf<LoadResult>()
        val packageManager = context.packageManager

        val installedPackages = packageManager.getInstalledPackages(
            PackageManager.GET_CONFIGURATIONS or PackageManager.GET_META_DATA
        )

        installedPackages.forEach { pkgInfo ->
            val result = loadExtension(pkgInfo.packageName)
            if (result != null) {
                extensions.add(result)
            }
        }

        return extensions
    }

    /**
     * Load a single extension by package name
     */
    fun loadExtension(packageName: String): LoadResult? {
        return try {
            val packageManager = context.packageManager
            val pkgInfo = packageManager.getPackageInfo(
                packageName,
                PackageManager.GET_CONFIGURATIONS or PackageManager.GET_META_DATA
            )

            val appInfo = pkgInfo.applicationInfo ?: return null

            // Check if this is an AniEnjoy extension
            if (!hasExtensionFeature(pkgInfo)) {
                return null
            }

            val metadata = appInfo.metaData
            val sourceClassName = metadata?.getString(METADATA_SOURCE_CLASS)
                ?: return LoadResult.Error(packageName, "Missing source class metadata")

            // Load the extension class
            val classLoader = PathClassLoader(appInfo.sourceDir, context.classLoader)
            val sourceClass = Class.forName(sourceClassName, false, classLoader)

            val extension = when {
                Extension::class.java.isAssignableFrom(sourceClass) -> {
                    sourceClass.getDeclaredConstructor().newInstance() as Extension
                }
                else -> {
                    return LoadResult.Error(packageName, "Unknown source class type")
                }
            }

            LoadResult.Success(
                packageName = packageName,
                extension = extension,
                sources = extension.getSources(),
                pkgInfo = pkgInfo
            )
        } catch (e: Exception) {
            LoadResult.Error(packageName, e.message ?: "Unknown error")
        }
    }

    /**
     * Check if package has extension feature
     */
    private fun hasExtensionFeature(pkgInfo: PackageInfo): Boolean {
        return pkgInfo.reqFeatures?.any { it.name == EXTENSION_FEATURE } == true
    }

    /**
     * Load result sealed class
     */
    sealed class LoadResult {
        abstract val packageName: String

        data class Success(
            override val packageName: String,
            val extension: Extension,
            val sources: List<Source>,
            val pkgInfo: PackageInfo
        ) : LoadResult()

        data class Error(
            override val packageName: String,
            val error: String
        ) : LoadResult()
    }
}
