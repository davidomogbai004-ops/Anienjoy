package com.anienjoy.extension.api.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Manga model class (also used for Manhwa and Manhua)
 */
@Parcelize
data class Manga(
    val source: String,
    val url: String,
    val title: String,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val genre: List<String> = emptyList(),
    val status: Int = UNKNOWN,
    val author: String? = null,
    val artist: String? = null,
    val updateStrategy: UpdateStrategy = UpdateStrategy.ALWAYS_UPDATE,
    val initialized: Boolean = false,
    val chapterFlags: Int = 0,
    val coverLastModified: Long = 0,
    val dateAdded: Long = 0,
    val viewers: Int = 0,
    val chapters: List<Chapter> = emptyList(),
    val id: Long = -1,
    val contentType: ContentType = ContentType.MANGA
) : Parcelable {
    companion object {
        const val UNKNOWN = 0
        const val ONGOING = 1
        const val COMPLETED = 2
        const val LICENSED = 3
        const val PUBLISHING_FINISHED = 4
        const val CANCELLED = 5
        const val ON_HIATUS = 6
    }
}

/**
 * Chapter model class
 */
@Parcelize
data class Chapter(
    val id: Long = -1,
    val mangaId: Long = -1,
    val url: String,
    val name: String,
    val scanlator: String? = null,
    val read: Boolean = false,
    val bookmark: Boolean = false,
    val chapterNumber: Float = -1f,
    val sourceOrder: Int = -1,
    val dateUpload: Long = 0,
    val dateFetch: Long = 0,
    val lastPageRead: Int = 0,
    val pagesLeft: Int = 0
) : Parcelable

/**
 * Page model class for manga reader
 */
@Parcelize
data class Page(
    val index: Int,
    val url: String,
    val imageUrl: String? = null,
    val chapter: Chapter? = null
) : Parcelable {
    val number: Int
        get() = index + 1
    var status: State = State.QUEUE
        set(value) {
            field = value
            statusListener?.invoke(this)
        }
    var progress: Int = 0
        set(value) {
            field = value
            progressListener?.invoke(this)
        }

    @Transient
    var statusListener: ((Page) -> Unit)? = null

    @Transient
    var progressListener: ((Page) -> Unit)? = null

    enum class State {
        QUEUE,
        LOAD_PAGE,
        DOWNLOAD_IMAGE,
        READY,
        ERROR
    }
}

/**
 * Manga page result
 */
data class MangaPage(
    val mangas: List<Manga>,
    val hasNextPage: Boolean
)

/**
 * Content type for manga variants
 */
enum class ContentType {
    MANGA,
    MANHWA,
    MANHUA
}
