package com.anienjoy.extension.api.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Anime model class
 */
@Parcelize
data class Anime(
    val source: String,
    val url: String,
    val title: String,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val genre: List<String> = emptyList(),
    val status: Int = UNKNOWN,
    val author: String? = null,
    val artist: String? = null,
    val updateStrategy: UpdateStrategy = UpdateStrategy.ALWAYS_UPDATE,
    val initialized: Boolean = false,
    val episodeFlags: Int = 0,
    val coverLastModified: Long = 0,
    val dateAdded: Long = 0,
    val viewers: Int = 0,
    val episodes: List<Episode> = emptyList(),
    val id: Long = -1
) : Parcelable {
    companion object {
        const val UNKNOWN = 0
        const val ONGOING = 1
        const val COMPLETED = 2
        const val LICENSED = 3
        const val PUBLISHING_FINISHED = 4
        const val CANCELLED = 5
        const val ON_HIATUS = 6
    }
}

/**
 * Episode model class
 */
@Parcelize
data class Episode(
    val id: Long = -1,
    val animeId: Long = -1,
    val url: String,
    val name: String,
    val scanlator: String? = null,
    val seen: Boolean = false,
    val bookmark: Boolean = false,
    val episodeNumber: Float = -1f,
    val sourceOrder: Int = -1,
    val dateUpload: Long = 0,
    val dateFetch: Long = 0,
    val lastSecondSeen: Long = 0,
    val totalSeconds: Long = 0,
    val videoUrl: String? = null
) : Parcelable

/**
 * Video model class for anime streaming
 */
data class Video(
    val url: String,
    val quality: String,
    val videoUrl: String,
    val headers: Map<String, String> = emptyMap(),
    val subtitleTracks: List<SubtitleTrack> = emptyList(),
    val audioTracks: List<AudioTrack> = emptyList()
) {
    override fun toString(): String = quality
}

/**
 * Subtitle track
 */
data class SubtitleTrack(
    val url: String,
    val lang: String,
    val label: String
)

/**
 * Audio track
 */
data class AudioTrack(
    val url: String,
    val lang: String,
    val label: String
)

/**
 * Anime page result
 */
data class AnimePage(
    val animes: List<Anime>,
    val hasNextPage: Boolean
)

/**
 * Update strategy for library updates
 */
enum class UpdateStrategy {
    ALWAYS_UPDATE,
    ONLY_FETCH_ONCE
}
