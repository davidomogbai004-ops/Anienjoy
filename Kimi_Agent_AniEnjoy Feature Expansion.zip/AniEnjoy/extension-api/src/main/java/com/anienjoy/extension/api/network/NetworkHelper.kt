package com.anienjoy.extension.api.network

import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Network helper for making HTTP requests
 */
class NetworkHelper {
    private val cookieJar = object : CookieJar {
        private val cookieStore = mutableMapOf<String, MutableList<Cookie>>()

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            cookieStore[url.host] = cookies.toMutableList()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            return cookieStore[url.host] ?: emptyList()
        }
    }

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .cookieJar(cookieJar)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", DEFAULT_USER_AGENT)
                    .build()
                chain.proceed(request)
            }
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .build()
    }

    /**
     * Make a GET request
     */
    fun get(url: String, headers: Headers? = null): Request {
        return Request.Builder()
            .apply { headers?.let { headers(it) } }
            .url(url)
            .build()
    }

    /**
     * Make a POST request
     */
    fun post(url: String, body: RequestBody, headers: Headers? = null): Request {
        return Request.Builder()
            .apply { headers?.let { headers(it) } }
            .url(url)
            .post(body)
            .build()
    }

    /**
     * Execute a request and return the response
     */
    @Throws(IOException::class)
    fun execute(request: Request): Response {
        return client.newCall(request).execute()
    }

    /**
     * Execute a request asynchronously
     */
    fun executeAsync(request: Request, callback: Callback) {
        client.newCall(request).enqueue(callback)
    }

    companion object {
        const val DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
}

/**
 * Extension function to parse HTML response
 */
fun Response.parseHtml(): org.jsoup.nodes.Document {
    return org.jsoup.Jsoup.parse(body?.string() ?: "")
}

/**
 * Extension function to parse JSON response
 */
inline fun <reified T> Response.parseJson(): T {
    return com.google.gson.Gson().fromJson(body?.string(), T::class.java)
}
