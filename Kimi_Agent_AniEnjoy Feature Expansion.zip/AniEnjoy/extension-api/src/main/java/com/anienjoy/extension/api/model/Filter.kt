package com.anienjoy.extension.api.model

/**
 * Base filter class
 */
sealed class Filter<T>(val name: String, var state: T) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Filter<*>) return false
        return name == other.name && state == other.state
    }

    override fun hashCode(): Int {
        return name.hashCode() * 31 + (state?.hashCode() ?: 0)
    }

    /**
     * Header filter - just displays text
     */
    class Header(name: String) : Filter<Unit>(name, Unit)

    /**
     * Separator filter - displays a line separator
     */
    class Separator(name: String = "") : Filter<Unit>(name, Unit)

    /**
     * Text filter - single line text input
     */
    class Text(name: String, state: String = "") : Filter<String>(name, state)

    /**
     * Checkbox filter
     */
    class CheckBox(name: String, state: Boolean = false) : Filter<Boolean>(name, state)

    /**
     * Tri-state filter - can be include, exclude, or ignore
     */
    class TriState(name: String, state: Int = STATE_IGNORE) : Filter<Int>(name, state) {
        companion object {
            const val STATE_IGNORE = 0
            const val STATE_INCLUDE = 1
            const val STATE_EXCLUDE = 2
        }
    }

    /**
     * Select filter - dropdown selection
     */
    class Select(
        name: String,
        val values: Array<String>,
        state: Int = 0
    ) : Filter<Int>(name, state) {
        val selected: String
            get() = values[state]
    }

    /**
     * Group filter - contains multiple filters
     */
    class Group<T>(name: String, state: List<T>) : Filter<List<T>>(name, state)
        where T : Filter<*>

    /**
     * Sort filter - for sorting options
     */
    class Sort(
        name: String,
        val values: Array<String>,
        state: Selection? = null
    ) : Filter<Sort.Selection?>(name, state) {
        data class Selection(val index: Int, val ascending: Boolean)
    }

    /**
     * Part filter - for partial filtering
     */
    class Part(
        name: String,
        val filters: List<Filter<*>>,
        state: Int = 0
    ) : Filter<Int>(name, state)
}

/**
 * Filter list - collection of filters
 */
class FilterList(vararg filters: Filter<*>) : List<Filter<*>> by filters.toList() {
    constructor(filters: List<Filter<*>>) : this(*filters.toTypedArray())
}

/**
 * Language filter helper
 */
class LanguageFilter(
    name: String = "Language",
    languages: List<Language> = Language.getAllLanguages()
) : Filter.Group<Filter.CheckBox>(
    name,
    languages.map { Filter.CheckBox(it.displayName, it.defaultSelected) }
) {
    data class Language(
        val code: String,
        val displayName: String,
        val defaultSelected: Boolean = false
    ) {
        companion object {
            fun getAllLanguages(): List<Language> = listOf(
                Language("all", "All", true),
                Language("en", "English", true),
                Language("ja", "Japanese"),
                Language("ko", "Korean"),
                Language("zh", "Chinese"),
                Language("zh-hk", "Chinese (Traditional)"),
                Language("fr", "French"),
                Language("de", "German"),
                Language("it", "Italian"),
                Language("es", "Spanish"),
                Language("es-419", "Spanish (Latin America)"),
                Language("pt", "Portuguese"),
                Language("pt-br", "Portuguese (Brazil)", true),
                Language("ru", "Russian"),
                Language("pl", "Polish"),
                Language("tr", "Turkish"),
                Language("ar", "Arabic"),
                Language("hi", "Hindi"),
                Language("id", "Indonesian"),
                Language("vi", "Vietnamese"),
                Language("th", "Thai"),
                Language("ms", "Malay")
            )
        }
    }

    fun getSelectedLanguages(): List<String> {
        return state.filter { it.state }
            .mapNotNull { checkbox ->
                Language.getAllLanguages()
                    .find { it.displayName == checkbox.name }
                    ?.code
            }
    }
}

/**
 * Content type filter
 */
class ContentTypeFilter(
    name: String = "Content Type"
) : Filter.Select(
    name,
    arrayOf("All", "Anime", "Manga", "Manhwa", "Manhua", "Novel"),
    0
) {
    fun getSelectedType(): com.anienjoy.extension.api.ContentType? {
        return when (state) {
            1 -> com.anienjoy.extension.api.ContentType.ANIME
            2 -> com.anienjoy.extension.api.ContentType.MANGA
            3 -> com.anienjoy.extension.api.ContentType.MANHWA
            4 -> com.anienjoy.extension.api.ContentType.MANHUA
            5 -> com.anienjoy.extension.api.ContentType.NOVEL
            else -> null
        }
    }
}

/**
 * Status filter
 */
class StatusFilter(
    name: String = "Status"
) : Filter.Select(
    name,
    arrayOf("All", "Ongoing", "Completed", "Licensed", "Publishing Finished", "Cancelled", "On Hiatus"),
    0
)

/**
 * Genre filter
 */
class GenreFilter(
    name: String = "Genres",
    genres: List<String> = emptyList()
) : Filter.Group<Filter.TriState>(
    name,
    genres.map { Filter.TriState(it) }
)
