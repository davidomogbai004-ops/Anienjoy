package com.anienjoy.extension.api.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Novel model class
 */
@Parcelize
data class Novel(
    val source: String,
    val url: String,
    val title: String,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val genre: List<String> = emptyList(),
    val status: Int = UNKNOWN,
    val author: String? = null,
    val artist: String? = null,
    val updateStrategy: UpdateStrategy = UpdateStrategy.ALWAYS_UPDATE,
    val initialized: Boolean = false,
    val chapterFlags: Int = 0,
    val coverLastModified: Long = 0,
    val dateAdded: Long = 0,
    val viewers: Int = 0,
    val chapters: List<NovelChapter> = emptyList(),
    val id: Long = -1
) : Parcelable {
    companion object {
        const val UNKNOWN = 0
        const val ONGOING = 1
        const val COMPLETED = 2
        const val LICENSED = 3
        const val PUBLISHING_FINISHED = 4
        const val CANCELLED = 5
        const val ON_HIATUS = 6
    }
}

/**
 * Novel chapter model class
 */
@Parcelize
data class NovelChapter(
    val id: Long = -1,
    val novelId: Long = -1,
    val url: String,
    val name: String,
    val scanlator: String? = null,
    val read: Boolean = false,
    val bookmark: Boolean = false,
    val chapterNumber: Float = -1f,
    val sourceOrder: Int = -1,
    val dateUpload: Long = 0,
    val dateFetch: Long = 0,
    val lastReadPosition: Int = 0
) : Parcelable

/**
 * Novel page result
 */
data class NovelPage(
    val novels: List<Novel>,
    val hasNextPage: Boolean
)

/**
 * Novel content with formatting
 */
data class NovelContent(
    val chapter: NovelChapter,
    val content: String,
    val title: String? = null,
    val prevChapterUrl: String? = null,
    val nextChapterUrl: String? = null
)
