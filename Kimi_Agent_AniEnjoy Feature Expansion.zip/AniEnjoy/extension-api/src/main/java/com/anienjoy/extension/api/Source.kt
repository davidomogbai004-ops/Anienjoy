package com.anienjoy.extension.api

import android.content.Context
import android.graphics.drawable.Drawable
import com.anienjoy.extension.api.model.*

/**
 * Base interface for all content sources (Anime, Manga, Novels)
 */
interface Source {
    /**
     * Unique identifier for this source
     */
    val id: Long

    /**
     * Name of the source (e.g., "Gogoanime", "MangaDex")
     */
    val name: String

    /**
     * Base URL of the source
     */
    val baseUrl: String

    /**
     * Language code (e.g., "en", "ja", "ko", "zh")
     */
    val lang: String

    /**
     * Whether this source supports NSFW content
     */
    val supportsNsfw: Boolean

    /**
     * Icon for the source
     */
    fun getIcon(): Drawable? = null
}

/**
 * Interface for Anime sources
 */
interface AnimeSource : Source {
    /**
     * Fetch popular anime list
     */
    suspend fun getPopularAnime(page: Int): AnimePage

    /**
     * Fetch latest updated anime
     */
    suspend fun getLatestUpdates(page: Int): AnimePage

    /**
     * Search anime
     */
    suspend fun searchAnime(query: String, page: Int, filters: FilterList = FilterList()): AnimePage

    /**
     * Get anime details
     */
    suspend fun getAnimeDetails(anime: Anime): Anime

    /**
     * Get episode list for an anime
     */
    suspend fun getEpisodeList(anime: Anime): List<Episode>

    /**
     * Get video sources for an episode
     */
    suspend fun getVideoList(episode: Episode): List<Video>

    /**
     * Get available filters
     */
    fun getFilterList(): FilterList
}

/**
 * Interface for Manga sources (includes Manhwa, Manhua)
 */
interface MangaSource : Source {
    /**
     * Fetch popular manga list
     */
    suspend fun getPopularManga(page: Int): MangaPage

    /**
     * Fetch latest updated manga
     */
    suspend fun getLatestUpdates(page: Int): MangaPage

    /**
     * Search manga
     */
    suspend fun searchManga(query: String, page: Int, filters: FilterList = FilterList()): MangaPage

    /**
     * Get manga details
     */
    suspend fun getMangaDetails(manga: Manga): Manga

    /**
     * Get chapter list for a manga
     */
    suspend fun getChapterList(manga: Manga): List<Chapter>

    /**
     * Get page list for a chapter
     */
    suspend fun getPageList(chapter: Chapter): List<Page>

    /**
     * Get available filters
     */
    fun getFilterList(): FilterList
}

/**
 * Interface for Novel sources
 */
interface NovelSource : Source {
    /**
     * Fetch popular novels
     */
    suspend fun getPopularNovels(page: Int): NovelPage

    /**
     * Fetch latest updated novels
     */
    suspend fun getLatestUpdates(page: Int): NovelPage

    /**
     * Search novels
     */
    suspend fun searchNovels(query: String, page: Int, filters: FilterList = FilterList()): NovelPage

    /**
     * Get novel details
     */
    suspend fun getNovelDetails(novel: Novel): Novel

    /**
     * Get chapter list for a novel
     */
    suspend fun getChapterList(novel: Novel): List<NovelChapter>

    /**
     * Get chapter content
     */
    suspend fun getChapterContent(chapter: NovelChapter): String

    /**
     * Get available filters
     */
    fun getFilterList(): FilterList
}

/**
 * Source factory for creating sources with different configurations
 */
interface SourceFactory {
    fun createSources(): List<Source>
}

/**
 * Extension interface that provides sources
 */
interface Extension {
    val name: String
    val version: String
    val versionCode: Int
    val libVersion: String
    val nsfw: Boolean
    
    fun getSources(): List<Source>
}

/**
 * Content type enum
 */
enum class ContentType {
    ANIME,
    MANGA,
    MANHWA,
    MANHUA,
    NOVEL
}

/**
 * Extension metadata
 */
data class ExtensionInfo(
    val name: String,
    val pkgName: String,
    val version: String,
    val versionCode: Int,
    val libVersion: String,
    val lang: String,
    val isNsfw: Boolean,
    val hasUpdate: Boolean = false,
    val isInstalled: Boolean = false,
    val hasReadme: Boolean = false,
    val hasChangelog: Boolean = false,
    val sources: List<SourceInfo> = emptyList(),
    val icon: Drawable? = null,
    val repoUrl: String? = null
)

data class SourceInfo(
    val id: Long,
    val name: String,
    val baseUrl: String,
    val lang: String,
    val contentType: ContentType
)

/**
 * Repository information
 */
data class ExtensionRepo(
    val name: String,
    val url: String,
    val enabled: Boolean = true
)
